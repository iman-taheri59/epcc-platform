@if(isset($screenings[$row->id]))
@php $screen=$screenings[$row->id]; $s=fn($key)=>__('material_screening.'.$key,[],$lang); @endphp
<section class="spec-card" data-screening="{{ $row->id }}" aria-label="{{ $s('title') }}">
<h4>{{ $s('title') }} · {{ $s($screen['status']) }}</h4>
<p class="spec-help">{{ $s('notice') }}</p>
<ul>@foreach($screen['findings'] as $finding)
<li data-finding="{{ $finding['code'] }}"><strong>{{ $s($finding['severity']) }}</strong>: {{ $finding['message'][$lang] }}
<br><small><bdi>{{ $finding['field'] }}</bdi></small></li>
@endforeach</ul>
<details><summary>{{ $s('evidence') }}</summary>
<p class="spec-source"><bdi>{{ $screen['ruleset'] }}</bdi><br><bdi>{{ $screen['input_sha256'] }}</bdi></p>
@foreach($screen['references'] as $reference)
<p class="spec-source"><bdi>{{ $reference['ref_id'] }} · {{ $reference['version'] }}</bdi><br>{{ $reference['source'] }}<br><bdi>{{ $reference['sha256'] }}</bdi></p>
@endforeach
</details></section>
@endif
