<?php
return [
    'title' => 'Technical screening',
    'notice' => 'Read-only automated findings, separate from project review status. This is not engineering approval or a submission gate. Check actual Spec, applicability and tolerances; source values are unchanged.',
    'evidence' => 'Rule version, source fingerprint and references',
    'DISCREPANCY' => 'Discrepancy',
    'INCOMPLETE' => 'Incomplete',
    'REVIEW_REQUIRED' => 'Source review required',
];
