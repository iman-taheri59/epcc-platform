{{-- Shared chrome for the multi-project screens. --}}
{{--
  Applied before the first paint.

  The sidebar's collapsed state is restored from localStorage, but the script
  that does it lives at the end of the sidebar partial - by which point the
  expanded sidebar has already painted, so a user who collapsed it sees it flash
  open on every single navigation. This app is server-rendered, so that is every
  click. Setting the class on <html> here, before any CSS is parsed, kills the
  flash; the main script keeps <body> in sync afterwards.

  html.no-js is removed immediately so the no-JS fallback only applies when the
  script genuinely did not run.
--}}
<script>
(function () {
  var d = document.documentElement;
  d.classList.add('no-js');
  try { if (localStorage.getItem('epcc.sb.rail') === '1') d.classList.add('rail'); } catch (e) {}
  d.classList.remove('no-js');
})();
</script>
@php
    $fa = $lang === 'fa';
@endphp
<style>
  :root { --bg:#0f172a; --card:#1e293b; --line:#334155; --muted:#94a3b8; --ok:#10b981; --bad:#ef4444; --warn:#f59e0b; --accent:#8b5cf6; }
  * { box-sizing:border-box; }
  body { margin:0; background:var(--bg); color:#e2e8f0; font-family:{{ $fa ? "Vazirmatn, Tahoma, sans-serif" : "ui-sans-serif, system-ui, sans-serif" }}; line-height:1.7; padding:24px; }
  .wrap { max-width:1080px; margin:0 auto; }
  h1 { font-size:22px; margin:0 0 4px; }
  .sub { color:var(--muted); font-size:14px; margin-bottom:18px; }
  a { color:var(--accent); }
  .topnav { display:flex; gap:16px; margin-bottom:12px; font-size:13px; font-weight:600; }
  .topnav a { text-decoration:none; }
  .bar { display:flex; flex-wrap:wrap; gap:10px; align-items:center; background:var(--card); border:1px solid var(--line); border-radius:12px; padding:14px 16px; margin-bottom:14px; }
  .bar label { font-size:13px; color:var(--muted); }
  select { background:#0b1220; color:#e2e8f0; border:1px solid var(--line); border-radius:8px; padding:8px 12px; font-size:14px; font-family:inherit; }
  .count { margin-{{ $fa ? 'right' : 'left' }}:auto; font-size:13px; color:var(--muted); }
  .count b { color:#fff; font-size:16px; }
  .note { font-size:12.5px; color:var(--muted); background:rgba(139,92,246,.08); border:1px solid rgba(139,92,246,.3); border-radius:10px; padding:11px 14px; margin-bottom:18px; }
  table { width:100%; border-collapse:collapse; background:var(--card); border:1px solid var(--line); border-radius:12px; overflow:hidden; }
  th { background:#0b1220; font-size:12px; text-transform:uppercase; letter-spacing:.05em; color:var(--muted); text-align:{{ $fa ? 'right' : 'left' }}; padding:11px 14px; font-weight:600; }
  td { padding:13px 14px; border-top:1px solid var(--line); font-size:14px; vertical-align:top; }
  /*
   * `inline-block` is what makes `direction:ltr` actually contain a Latin
   * identifier inside an RTL sentence - without it the bidi algorithm reorders
   * neighbouring punctuation. But on a <td> it REPLACES `display:table-cell`,
   * so the cell drops out of the column layout and every following column
   * shifts by one: the header "Subsystem" ends up over the category data.
   * Table cells therefore keep their table display and only take the LTR run.
   */
  .mono { font-family:ui-monospace,monospace; font-size:13px; direction:ltr; display:inline-block; }
  td.mono, th.mono { display:table-cell; }
  .amt { font-variant-numeric:tabular-nums; font-weight:600; white-space:nowrap; }
  .pill { display:inline-block; font-size:12px; font-weight:700; padding:3px 11px; border-radius:999px; white-space:nowrap; }
  .pill.ok { background:rgba(16,185,129,.16); color:#6ee7b7; border:1px solid rgba(16,185,129,.35); }
  .pill.bad { background:rgba(239,68,68,.16); color:#fca5a5; border:1px solid rgba(239,68,68,.35); }
  .pill.abs { background:rgba(239,68,68,.3); color:#fecaca; border:1px solid rgba(239,68,68,.5); margin-{{ $fa ? 'right' : 'left' }}:6px; }
  .pill.none { background:rgba(148,163,184,.14); color:#cbd5e1; border:1px dashed rgba(148,163,184,.5); }
  .whynot { font-size:12px; color:var(--muted); margin-top:7px; max-width:46ch; }
  .pill.pack { background:rgba(139,92,246,.16); color:#c4b5fd; border:1px solid rgba(139,92,246,.4); font-family:ui-monospace,monospace; font-size:11px; }
  ul.rs { list-style:none; margin:9px 0 0; padding:0; }
  ul.rs li { font-size:12.5px; color:#fca5a5; padding:3px 0; }
  ul.rs code { color:#f87171; font-size:11px; direction:ltr; display:inline-block; margin-{{ $fa ? 'left' : 'right' }}:6px; }
  .empty { text-align:center; padding:38px; color:var(--muted); font-size:14px; }
  .foot { margin-top:18px; font-size:12.5px; color:var(--muted); border-top:1px solid var(--line); padding-top:14px; }
  .grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(320px,1fr)); gap:14px; }
  .pcard { background:var(--card); border:1px solid var(--line); border-radius:12px; padding:16px; text-decoration:none; color:inherit; display:block; transition:border-color .15s; }
  .pcard:hover { border-color:var(--accent); }
  .pcard h3 { margin:0 0 4px; font-size:15.5px; }
  .pcard .code { font-family:ui-monospace,monospace; font-size:11.5px; color:var(--muted); direction:ltr; display:inline-block; }
  .stats { display:flex; gap:18px; margin-top:12px; padding-top:12px; border-top:1px solid var(--line); }
  .stat .k { font-size:11px; color:var(--muted); text-transform:uppercase; letter-spacing:.04em; }
  .stat .v { font-size:17px; font-weight:700; font-variant-numeric:tabular-nums; }
  .v.bad { color:#fca5a5; } .v.ok { color:#6ee7b7; }
  @media (max-width:640px){ .grid{grid-template-columns:1fr;} }

  /* ---------- App shell: sidebar + content ----------
     The sidebar is a sibling of .wrap, so body becomes the layout container.
     Logical properties (inline-start/end) do the RTL work: the sidebar sits on
     the right in Farsi and the left in English with no duplicated rules. */
  body { padding:0; }
  .app { display:flex; min-height:100vh; align-items:stretch; }
  /*
   * min-width:0 is load-bearing, not tidiness.
   *
   * A flex item's default min-width is `auto`, which means "never shrink below
   * my content's intrinsic width". A wide table therefore widens .wrap past
   * the viewport instead of overflowing inside it. In LTR that merely clips on
   * the right and the page still reads; in RTL the block is laid out from the
   * right edge, so the overflow pushes the ENTIRE document off-screen to the
   * left and the page renders as a blank rectangle.
   *
   * That is exactly what happened: /projects/{p}/documents?lang=fa at 430px
   * wide rendered ONE unique colour - the background - while the same page in
   * English at the same width was fine. The documents table is 1032px of
   * intrinsic width; the phone viewport was 485px.
   */
  /* Wide registers also overflow on desktop (not only below 860px).
     Keep every column reachable inside the content pane instead of widening
     the document behind the sidebar. Pinned by the live browser matrix. */
  .app > .wrap { flex:1; min-width:0; padding:24px; margin:0 auto; overflow-x:auto; }

  .sb {
    flex:0 0 252px; width:252px; background:#0b1220;
    border-inline-end:1px solid var(--line);
    display:flex; flex-direction:column; position:sticky; top:0;
    height:100vh; overflow-y:auto;
  }
  .sb-brand { display:flex; gap:10px; align-items:center; padding:16px 16px 14px; border-bottom:1px solid var(--line); }
  .sb-logo {
    width:32px; height:32px; border-radius:9px; flex:0 0 32px;
    background:linear-gradient(135deg,var(--accent),#6366f1);
    color:#fff; font-size:12.5px; font-weight:800; letter-spacing:.02em;
    display:flex; align-items:center; justify-content:center; direction:ltr;
  }
  .sb-brand-t { display:flex; flex-direction:column; line-height:1.35; min-width:0; }
  .sb-brand-t b { font-size:13.5px; color:#f1f5f9; }
  .sb-brand-t small { font-size:11px; color:var(--muted); font-family:ui-monospace,monospace; direction:ltr; }

  .sb-nav { padding:10px 8px; flex:1; }
  .sb-sec { font-size:10.5px; text-transform:uppercase; letter-spacing:.07em; color:#64748b; font-weight:700; padding:12px 10px 6px; }
  .sb-i {
    display:flex; align-items:center; gap:10px; padding:8px 10px; margin-bottom:2px;
    border-radius:9px; font-size:13.5px; font-weight:500; color:#cbd5e1;
    text-decoration:none; border:1px solid transparent; transition:background .13s,color .13s;
  }
  .sb-i:hover { background:rgba(148,163,184,.09); color:#f1f5f9; }
  .sb-i.on { background:rgba(139,92,246,.15); border-color:rgba(139,92,246,.4); color:#ddd6fe; font-weight:650; }
  /* The active marker must flip with the writing direction, hence a logical
     border rather than border-left. */
  .sb-i.on .sb-ic { color:var(--accent); }
  .sb-ic { width:17px; height:17px; flex:0 0 17px; display:block; color:#94a3b8; }
  .sb-ic svg { width:100%; height:100%; display:block; }

  /* Inert items: dimmed, not hidden. A locked module is the upsell surface. */
  .sb-i.off { cursor:not-allowed; color:#64748b; }
  .sb-i.off:hover { background:transparent; color:#64748b; }
  .sb-i.off .sb-ic { color:#475569; }
  .sb-i.off > span { flex:1; min-width:0; }
  .sb-b { font-size:9.5px; font-style:normal; font-weight:700; padding:2px 6px; border-radius:5px; white-space:nowrap; letter-spacing:.02em; }
  .sb-b.locked { background:rgba(245,158,11,.16); color:#fcd34d; border:1px solid rgba(245,158,11,.32); }
  .sb-b.planned { background:rgba(148,163,184,.13); color:#94a3b8; border:1px solid rgba(148,163,184,.28); }

  .sb-foot { border-top:1px solid var(--line); padding:12px; }
  .sb-user { display:flex; gap:9px; align-items:center; margin-bottom:10px; }
  .sb-av {
    width:29px; height:29px; flex:0 0 29px; border-radius:50%;
    background:rgba(139,92,246,.2); border:1px solid rgba(139,92,246,.4);
    color:#c4b5fd; font-size:12.5px; font-weight:700;
    display:flex; align-items:center; justify-content:center;
  }
  .sb-user-t { display:flex; flex-direction:column; line-height:1.35; min-width:0; }
  .sb-user-t b { font-size:12.5px; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
  .sb-user-t small { font-size:10.5px; color:var(--muted); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
  .sb-plan { display:flex; align-items:center; gap:7px; font-size:11px; color:var(--muted); margin-bottom:10px; }
  .sb-acts { display:flex; align-items:center; gap:10px; font-size:12px; }
  .sb-acts a { color:var(--muted); text-decoration:none; font-weight:600; }
  .sb-acts a:hover { color:#e2e8f0; }
  .sb-acts form { margin-inline-start:auto; }
  .sb-acts button { background:none; border:0; color:#fca5a5; font:inherit; font-size:12px; font-weight:600; cursor:pointer; padding:0; }
  .sb-acts button:hover { color:#f87171; }

  /* ---------- Collapsible: icon rail on desktop, off-canvas drawer on mobile
     Mirrors prototype/index.html, whose behaviour is pinned by 19 jsdom
     assertions in prototype/test/sidebar.test.js. Same class names (`rail`,
     `drawer`) so the two cannot drift apart. */
  .sb-burger {
    background:var(--card); border:1px solid var(--line); border-radius:8px;
    color:#cbd5e1; width:34px; height:32px; font-size:15px; line-height:1;
    cursor:pointer; display:flex; align-items:center; justify-content:center;
    flex:0 0 auto; padding:0; transition:border-color .15s ease, color .15s ease;
  }
  .sb-burger:hover { border-color:var(--accent); color:var(--accent); }
  /* The toggle lives in a bar above the page content, not inside the sidebar:
     a control that collapses the sidebar must stay reachable once it has. */
  .topbar { display:flex; align-items:center; gap:10px; margin-bottom:14px; }
  .topbar .tb-t { font-size:12.5px; color:var(--muted); font-weight:600; }
  .scrim { display:none; position:fixed; inset:0; background:rgba(4,9,18,.6); z-index:40; }

  /* ---- Animation ----
     Collapsing used to be instantaneous and jarring for two independent
     reasons, and fixing only one leaves it still broken:

       1. `.sb` had NO transition on desktop - the only one in the file lived
          inside the mobile media query, on `transform`. Width simply snapped.
       2. The labels were hidden with `display:none`, which is a discrete
          property: it cannot be interpolated, so text vanished in one frame
          however smooth the container was.

     So the width animates here, and the labels collapse via `max-width` +
     `opacity`, both of which ARE animatable. `overflow-x:hidden` on the panel
     clips the text as the rail closes instead of showing a scrollbar. */
  .sb {
    transition: flex-basis .24s cubic-bezier(.4,0,.2,1),
                width .24s cubic-bezier(.4,0,.2,1);
    overflow-x: hidden;
  }
  /* Labels: inline pieces collapse horizontally... */
  /* display:inline-block is LOAD-BEARING, not cosmetic.
     `max-width` and `overflow` have NO effect on a non-replaced inline box, so
     an inline element given `max-width:220px; overflow:hidden` is sized purely
     by its content - and when the rail sets `max-width:0` it is simply ignored
     too. The language switch is an <a>, i.e. inline by default: it inherited
     these rules, laid out at zero usable width inside the flex footer, and
     vanished from the expanded sidebar entirely. Every element collapsed this
     way must be inline-block (or block) for the animation to apply at all. */
  .sb-brand-t, .sb-i > span, .sb-b, .sb-user-t, .sb-acts a {
    display: inline-block; vertical-align: middle;
    max-width: 220px; overflow: hidden; white-space: nowrap;
    transition: max-width .24s cubic-bezier(.4,0,.2,1), opacity .14s ease;
  }
  /* .sb-brand-t and .sb-user-t are flex columns; inline-block above would
     destroy their internal stacking, so restore it. They are already sized by
     the flex parent, and max-width still applies to a flex container. */
  .sb-brand-t, .sb-user-t { display: flex; }
  /* ...block-level pieces collapse vertically. max-width would leave their
     line box behind and the rail would keep a row of blank gaps. */
  .sb-sec, .sb-plan {
    overflow: hidden;
    transition: height .2s cubic-bezier(.4,0,.2,1),
                padding .2s cubic-bezier(.4,0,.2,1),
                margin .2s cubic-bezier(.4,0,.2,1),
                opacity .14s ease;
  }
  .sb-i {
    transition: background .13s, color .13s,
                padding .24s cubic-bezier(.4,0,.2,1),
                gap .24s cubic-bezier(.4,0,.2,1);
  }
  .sb-brand { transition: padding .24s cubic-bezier(.4,0,.2,1); }

  /* Desktop: collapse to a 60px icon rail. Icons stay, labels go. */
  body.rail .sb, html.rail .sb { flex-basis:60px; width:60px; }
  body.rail .sb-brand, html.rail .sb-brand { padding-inline:0; justify-content:center; }
  /* Zero max-width rather than display:none, so it can actually animate.
     pointer-events + visibility keep the collapsed text unclickable and out
     of the accessibility tree. */
  body.rail .sb-brand-t, html.rail .sb-brand-t,
  body.rail .sb-i > span, html.rail .sb-i > span,
  body.rail .sb-b, html.rail .sb-b,
  body.rail .sb-user-t, html.rail .sb-user-t,
  body.rail .sb-acts a, html.rail .sb-acts a {
    max-width:0; opacity:0; pointer-events:none;
  }
  body.rail .sb-sec, html.rail .sb-sec,
  body.rail .sb-plan, html.rail .sb-plan {
    height:0; padding-top:0; padding-bottom:0; margin:0; opacity:0; pointer-events:none;
  }
  body.rail .sb-i, html.rail .sb-i { justify-content:center; padding-inline:0; gap:0; }
  body.rail .sb-user, html.rail .sb-user { justify-content:center; }
  body.rail .sb-acts, html.rail .sb-acts { justify-content:center; }
  body.rail .sb-acts form, html.rail .sb-acts form { margin-inline-start:0; }
  body.rail .sb-foot, html.rail .sb-foot { padding-inline:6px; }

  @media (max-width:860px) {
    /*
     * min-width:0 above stops the overflow escaping the viewport; this is what
     * makes the overflowing part reachable. Without it a wide table is simply
     * clipped and the columns past the fold are unreadable on a phone - which
     * on a document register means the state and the revision, i.e. the two
     * fields somebody is actually looking for.
     */
    .app > .wrap { padding:16px; overflow-x:auto; }
    /* Off-canvas. inset-inline-start + a direction-aware transform means RTL
       slides in from the right with no duplicated rules. */
    .sb {
      position:fixed; inset-block:0; inset-inline-start:0; z-index:50;
      width:250px; flex-basis:250px; height:100vh;
      transform:translateX(-105%);
      transition:transform .24s cubic-bezier(.4,0,.2,1);
      box-shadow:0 0 30px rgba(0,0,0,.5);
    }
    html[dir="rtl"] .sb { transform:translateX(105%); }
    body.drawer .sb, html[dir="rtl"] body.drawer .sb { transform:translateX(0); }
    body.drawer .scrim { display:block; }
    /* The desktop rail state must NOT leak into mobile: a 60px off-canvas
       panel would slide in showing icons and nothing else. Every rail
       collapse is undone here, including the animated ones. */
    body.rail .sb, html.rail .sb { width:250px; flex-basis:250px; }
    body.rail .sb-brand, html.rail .sb-brand { padding-inline:16px; justify-content:flex-start; }
    body.rail .sb-brand-t, html.rail .sb-brand-t,
    body.rail .sb-i > span, html.rail .sb-i > span,
    body.rail .sb-b, html.rail .sb-b,
    body.rail .sb-user-t, html.rail .sb-user-t,
    body.rail .sb-acts a, html.rail .sb-acts a {
      max-width:220px; opacity:1; pointer-events:auto;
    }
    body.rail .sb-sec, html.rail .sb-sec {
      height:auto; padding:12px 10px 6px; opacity:1; pointer-events:auto;
    }
    body.rail .sb-plan, html.rail .sb-plan {
      height:auto; padding:0; margin-bottom:10px; opacity:1; pointer-events:auto;
    }
    body.rail .sb-i, html.rail .sb-i { justify-content:flex-start; padding-inline:10px; gap:10px; }
    body.rail .sb-acts form, html.rail .sb-acts form { margin-inline-start:auto; }
  }

  /* No-JS / pre-hydration safety: never leave the page with an unreachable
     sidebar if the script fails to run. */
  @media (max-width:860px) { html.no-js .sb { position:static; transform:none; height:auto; box-shadow:none; } }

  /* Motion is a vestibular accessibility issue, not a preference. Honour the
     OS setting: the sidebar still collapses, it just does not animate. */
  @media (prefers-reduced-motion: reduce) {
    .sb, .sb *, .scrim, .sb-burger { transition:none !important; }
  }
</style>
