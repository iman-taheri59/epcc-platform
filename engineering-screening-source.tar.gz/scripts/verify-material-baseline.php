<?php
// Non-destructive preflight. Documentation/test artifacts are not proof of deployed source.
$root=dirname(__DIR__);$missing=[];
foreach ([
 'app/app/Services/ProjectMaterialSchema.php',
 'app/database/migrations/2026_09_29_150000_extend_project_material_declarations.php',
 'app/resources/views/piping/partials/project-material-fields.blade.php',
 'app/lang/fa/project_materials.php','app/lang/en/project_materials.php',
 'app/tests/Feature/MaterialReviewTest.php','app/tests/Feature/MaterialMigrationTest.php',
] as $path) { if (!is_file($root.'/'.$path)) {$missing[]=$path;} }
foreach ([
 'app/app/Services/FittingReviewService.php'=>'material_family',
 'app/app/Services/ProjectFittingDefinitionService.php'=>'ProjectMaterialSchema',
 'app/app/Http/Controllers/ProjectFittingDefinitionController.php'=>'ProjectMaterialSchema',
] as $path=>$marker) {
 if (!is_file($root.'/'.$path) || !str_contains(file_get_contents($root.'/'.$path),$marker)) {$missing[]=$path.' [missing '.$marker.']';}
}
echo json_encode(['status'=>$missing?'INCOMPLETE_BASELINE':'SOURCE_FILES_PRESENT_NOT_RUNTIME_VERIFIED','missing'=>$missing],JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES)."\n";
exit($missing?1:0);
