# ADR-016 — The library of codes and standards

Status: **ACCEPTED AND PARTLY BUILT**
Date: 2026-09-20
Supersedes: nothing. Extends ADR-015 §2.8 (the standard-vs-project-spec split).

---

## 1. Context

Every module that needed to name a standard named it as prose. An ITP row said
`'EN 10204 · ASME B31.3 §323'` in a `varchar`. A grep across the codebase found
`ASME B31.3`, `ASME B31.3.` and `API RP` as three different strings, and
`API 5L` written fourteen times in four files.

Three things are impossible against prose:

1. **"Which inspections cite B31.3?"** — the question asked on the day a project
   moves to a new edition, and the list of what must be re-checked. Unanswerable
   without parsing text that nobody validated on the way in.
2. **Consistent naming.** `ASME B31.3` and `ASME B 31.3` are one standard to an
   engineer and two rows to a database. Nothing stopped either spelling.
3. **A contractual edition.** A project is bound to a specific issue of a code.
   Prose has no place to record that, so the year lived in people's heads.

The user's instruction: the system must hold a library of the standards and
codes used on a project, usable from the various modules — the ITP standards
column among them.

## 2. Decision

### 2.1 Two tiers: a global catalogue and a per-project applicability list

```
standards          the catalogue - global, no project_id, no RLS
project_standards  "this project works to this code, at this edition" - RLS
standard_citations "this object cites that standard at that clause" - RLS
```

The split is not bureaucracy; the two tiers answer different questions.
*"Does ASME B31.3 exist, and what is it called in Persian?"* has the same
answer for every customer. *"Is this project bound to the 2020 or the 2022
edition?"* is specific, contractual, and must not change because a platform
administrator tidied the catalogue.

Per-project-only was rejected: every project would retype `ASME B31.3` and the
spellings would diverge again, which is the defect being fixed. Global-only was
rejected: it has nowhere to record the contractual edition.

### 2.2 The catalogue is reference data, like the packs

No `project_id`, no `company_id`, no RLS — the same call as `itp_templates` and
the engineering reference packs. The protection reference data needs is *no
tenant may write it*, which is given by not exposing a tenant-facing writer, not
by a permissive row policy that only looks like protection.

### 2.3 `normalised` is the uniqueness key

`body + designation`, uppercased, with everything non-alphanumeric stripped:
`ASME B31.3` → `ASMEB313`. Case, spaces, dots and dashes are exactly what humans
vary, so they cannot participate in identity. `define()` is idempotent on this
key, which is the entire defence against the free-text problem.

The body is stored separately from the designation so that "all API standards"
is an indexed query rather than a `LIKE`, and so the body cannot drift out of
sync with a designation that embeds it.

### 2.4 The edition is pinned on the ADOPTION, not the catalogue entry

The user asked for a simple edition field rather than a full edition entity.
Taken literally — a `year` column on `standards` — that has a defect: the day
somebody updates the catalogue from 2020 to 2022, **every project's acceptance
criteria change at once**, including a project whose contract names the 2020
text and whose inspections were signed against it.

So the catalogue carries the edition it currently describes, and
`project_standards.edition` carries what *this* project signed up to. Null means
"follow the catalogue", which is the honest answer for the many standards nobody
has taken a contractual position on. One extra column, no extra table, and
`isPinnedBehindCatalogue()` puts a visible marker on a project that has
deliberately frozen an older issue.

### 2.5 Citations are polymorphic

`standard_citations` carries `citable_type` + `citable_id`. `ITP_STAGE` is the
only host today; piping classes, weld procedures and datasheets will reuse it.
A table per consumer would be the same three columns, the same model and the
same RLS policy written five times — the call the ITP module already made for
`itp_stage_documents`.

`citable_type` holds our own short constant, **not** a fully-qualified class
name. A namespace rename must not silently orphan every citation in the
database.

### 2.6 Citing is adopting

`cite()` adopts the standard for the project on its way through. Requiring a
separate adoption step first would mean an engineer writing an ITP is refused
and sent to a settings page — so instead the applicability list is true by
construction, assembled from what the project's documents actually reference.

### 2.7 The free-text column survives

`itp_stages.reference` stays, and this is the user's explicit ruling. On a live
project there is always a code the library has not caught up with, and refusing
the row until an administrator adds it would stop inspection work to satisfy a
database.

`structureStandards()` runs as each stage is created: what resolves becomes a
citation, what does not stays in `reference`, and `printedStandards()`
concatenates both. The engineer sees exactly the column they always saw —
`'EN 10204 · ASME B31.3 §323'` — while the structured half is now queryable.

Parsing accepts the way engineers actually write: `·`, `;`, `,` and ` / ` as
separators, and a carried issuing body, so `ASME B36.10M · B16.9 · B16.5` means
ASME three times.

### 2.8 Withdrawal is a flag, never a delete

A record signed in 1998 cites what it cites. `is_active = false` keeps a
superseded standard out of the picker while leaving history readable, and both
foreign keys into `standards` are `restrictOnDelete` so nobody can orphan a
signed citation.

## 3. Schema

```
standards           body, designation, normalised (unique), title_en/fa,
                    edition, category, is_active
project_standards   (project, standard) unique -> edition, remarks, is_active
standard_citations  (citable_type, citable_id, standard) unique
                    -> clause, sequence
```

## 4. Consequences

**Good.** "Which rows cite B31.3?" is an indexed query and a screen. The
applicability list builds itself. One spelling per standard, enforced by a
unique index rather than by discipline. A project's contractual edition is
recorded where it is contractually true.

**Costs.** A citation is two rows where it used to be a substring. The parser
is a heuristic and will mis-split something eventually — which is why nothing
it fails to match is ever discarded.

**Not built yet.** Only ITP rows cite the library. Piping classes, weld
procedures and datasheets still carry their own strings; they adopt
`standard_citations` as each is touched. There is no admin UI for editing the
catalogue itself — it is seeded, and `define()` is the API.

## 5. Alternatives rejected

### Keeping the catalogue in a JSON file instead of a table

Asked directly (user, 2026-09-20): could the standards library be a JSON file
so the database is not involved?

**Considered and not taken — but the reasoning is narrower than it looks, and
this should be revisited if the constraint below ever changes.**

The question only ever applied to **one** of the three tables. `standards` is a
global catalogue: no RLS, not per-project, not user-edited, changes between
releases of the software rather than between customers. That profile is exactly
`standards-packs/reference/*.ref.json`, so the instinct was sound.
`project_standards` (which edition THIS project pinned) and
`standard_citations` (which clause governs THIS ITP row) are customer data and
were never candidates.

What blocks it is referential integrity, not performance:

```php
$table->foreignUuid('standard_id')->constrained('standards')->restrictOnDelete();
```

Both project-scoped tables hold a real foreign key to `standards`. Postgres
cannot reference a file. Move the catalogue out and `restrictOnDelete` goes
with it, so a standard disappearing from the file would silently orphan the
editions projects have pinned and the clauses cited on ITP rows. On a project
where the ITP is a contractual document, an acceptance criterion pointing at a
reference that no longer resolves is a real defect, and nothing would report it.

Performance is not an argument either way: 59 rows sit entirely in Postgres's
cache. The genuine benefit would have been maintenance — adding a standard
without touching code or writing a migration.

**If this is picked up later, the shape to build is the one the units module
already uses: file as source, table as mirror** — `standards.ref.json` in git
(reviewable, diffable, validated by `standards-packs/validate_packs.py`),
imported by an idempotent seeder keyed on `normalised`, with the table kept as
a read-only mirror so the foreign keys and joins survive. That keeps both
properties. It was deferred only because the maintenance pain is theoretical
today, and `StandardsLibrary::resolve()` does longest-prefix matching plus
catalogue search from SQL, which would have to be rewritten by hand.


- **A standards *document* in the register.** Standards are not project
  deliverables: they are external, shared and not revision-controlled by us.
  Putting ASME B31.3 in the document register would mean one copy per project
  and would confuse "we issued this" with "we comply with this".
- **Free text plus a validation regex.** Catches shape, not identity: `ASME
  B31.3` and `ASME B 31.3` both pass and remain two things.
- **A full edition entity** (`standard_editions` with dates and supersession
  chains). Correct for a standards publisher, disproportionate here. The
  project's pinned year answers the question the projects actually ask.
