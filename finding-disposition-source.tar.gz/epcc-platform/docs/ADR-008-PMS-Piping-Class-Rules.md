# ADR-EPCC-008 — PMS piping classes: size-dependent rules and the branch table

**Status:** **ACCEPTED — phases 1, 2 and 3 BUILT (2026-09-23)**, then **AMENDED the same day: size rules are stored PER SIZE, not as bands (§10)**. **§11 (2026-09-24) records an agreed re-analysis against real PMS documents: the body axis, the P-T table, the header and SP items all change before phase 4. §11.13 amends it further: a rating is `(standard, class)`, not a string, and some classes (800) are computed rather than tabulated. **§11.16 then corrects §11.13's B16.11 paragraph.** **§11.17 adds wellhead scope (API 6A) and introduces the PIPING TYPE as a standards profile — the largest scope change here.** **§11.18 then corrects §11.17: the pipe stays NPS, and the wellhead work is much smaller than §11.17 claims.** **§11.19 audits API 5L, fixes a rotted cross-reference, and establishes that a PSL is a pair.** **§11.20 records that a piping MTO is often split into sub-MTOs, and the live reconciliation defect that follows — deferred by the user.** **§11.21 records build order steps 1, 2 and 2b as BUILT.** **§11.22 corrects §11.21's account of where the B16.5 numbers came from.** Read §9, §10 and §11 together; §1–§3 are superseded.** Phases 4 and 5 open.
**Date:** 2026-09-14
**Depends on:** ADR-007 (reference data: NPS/DN/OD, schedules) — PROPOSED
**Consumed by:** ADR-006 (piping lines, components, ports, joints) — PROPOSED

**Trigger (user):** «مدرک PMS مشخص می‌کنه که برای هر پایپینگ کلاس چه متریالی رو باید استفاده کرد.
مثلاً لوله ۱/۲ تا ۴ اینچ SCH80، ۴ تا ۱۰ اینچ SCH40. این رو چطور پیاده می‌کنی؟ و همین‌طور نوع
کامپوننت انشعاب در قطرهای مختلف.»

Also confirmed: **ASME is the governing dimensional standard** (ADR-007 §9 closed).

---

## 1. The question behind the question

"1/2 to 4 inch SCH80, 4 to 10 inch SCH40" contains a **boundary ambiguity that will cause a
real defect** if copied literally: 4" appears in both bands. On paper a piping engineer reads
the intent instantly; a database cannot. Ask ten engineers and the usual reading is
*"up to and including 3½", then 4" and above"* — but the *usual* reading is not good enough
when a wrong answer specifies the wrong wall thickness on a pressure line.

So the first design decision is not about tables at all:

> **Size bands are stored as half-open DN ranges `[from, to)`, never as inclusive text.**

`[15, 100)` and `[100, 250)` are unambiguous, tile perfectly with no gap and no overlap, and
make 4" (DN100) resolve to exactly one rule. The UI can still *display* "½"–3½"" and "4"–10"";
storage and display are different problems.

Everything below follows from that one choice.

---

## 2. Why DN and not inches

The ranges are keyed on **DN integers**, not NPS strings or inch decimals:

- NPS is a *label*, not a number: `1 1/4`, `1.25`, `1-1/4` and `1¼` are the same size written
  four ways, and Persian input adds `۱¼`. Range logic on strings is not possible; range logic on
  floats invites `3.5 == 3.4999999`.
- DN is a **small integer** (15, 20, 25, 32, 40, 50, 65, 80, 100…), so `int4range` applies
  directly and PostgreSQL's own range machinery does the work.
- ADR-007's reference pack already carries the NPS ↔ DN ↔ OD mapping, so converting the user's
  "4 inch" into DN100 at entry time is a lookup, not a guess.

This also fixes the fold problem: `fold()` already normalises Persian digits for search, and now
size entry does not depend on how someone typed the fraction.

---

## 3. Rule kind 1 — one-dimensional bands (pipe schedule, and much else)

The user's example is one instance of a general pattern. The same shape covers:

| Rule kind | Resolves to | Typical PMS wording |
|---|---|---|
| `PIPE_SCHEDULE` | schedule / wall | ½"–3½" SCH 80, 4"–10" SCH 40 |
| `END_PREPARATION` | end type | ≤1½" socket weld, ≥2" butt weld |
| `VALVE_TYPE` | component spec | ≤2" ball valve, >2" gate valve |
| `FLANGE_TYPE` | component spec | ≤1½" SW flange, ≥2" WN flange |
| `GASKET_TYPE`, `BOLT_SPEC`, `CORROSION_ALLOWANCE` | … | same shape |

So **one table, discriminated by `rule_kind`** — not a separate table per rule type. The same
reasoning as `MovementType` (one ledger, four document types) and `FacilityKind` (one table, a
kind discriminator) already proven twice in this codebase.

```sql
CREATE TABLE piping_class_rules (
  id              uuid PRIMARY KEY,
  project_id      uuid NOT NULL,
  company_id      uuid NOT NULL,
  piping_class_id uuid NOT NULL REFERENCES piping_classes(id) ON DELETE CASCADE,
  rule_kind       text NOT NULL,          -- CHECK against PipingRuleKind::all()
  dn_range        int4range NOT NULL,     -- half-open [from, to)
  value           jsonb NOT NULL,         -- {"schedule":"80"} / {"end_type":"SW"} / ...
  note_en         text, note_fa text,
  source_ref      text                    -- PMS section/table this came from
);

CREATE EXTENSION IF NOT EXISTS btree_gist;

ALTER TABLE piping_class_rules ADD CONSTRAINT piping_class_rules_no_overlap
  EXCLUDE USING gist (
    piping_class_id WITH =,
    rule_kind       WITH =,
    dn_range        WITH &&
  );
```

**The exclusion constraint is the load-bearing part.** Two rules of the same kind on the same
class cannot overlap — the database refuses. This is the same philosophy as the composite FK in
ADR-004: make the corrupt state *unrepresentable*, rather than trusting a service-layer check
that the next developer will bypass with a bulk import.

**Verified on this PostgreSQL 17.11 before proposing:**

| Test | Result |
|---|---|
| `[15,100)` SCH80 + `[100,250)` SCH40 inserted | accepted |
| DN100 (4") resolved | **exactly one rule → SCH 40** |
| DN80 (3") resolved | SCH 80 |
| Same bands written inclusive (`[15,100]` + `[100,250]`) | **rejected**, `exclusion_violation` at DN100 |

That fourth row is the point: had someone entered the user's sentence literally as two inclusive
bands, **the database would have stopped them**, with an error naming the conflicting size.

### 3.1 Gaps are legal to the database but wrong in engineering

Overlap is impossible; a **gap** is not — `[15,100)` + `[150,250)` leaves 5" (DN125) with no
rule, and the DB accepts it happily (confirmed). That is correct behaviour while a class is
being entered, and a defect once it is published.

Detected with PostgreSQL 17's multirange support rather than application looping:

```sql
SELECT range_agg(dn_range) FROM piping_class_rules
WHERE piping_class_id = ? AND rule_kind = 'PIPE_SCHEDULE';
--  complete → {[15,600)}                one fragment
--  gapped   → {[15,100),[150,250)}      two fragments  ⇒ incomplete
```

A coverage check is therefore "does `range_agg` return exactly one contiguous range covering the
class's declared span?" — cheap, exact, and expressible as a single query. This becomes a
**publication gate** on the piping class, in the same spirit as open A-items blocking an MC
certificate: a class with holes may exist as a draft and may not be used by a line.

### 3.2 Resolution is a lookup, not a calculation

```php
$dn  = $reference->size($line->nominal_size)->dn;   // "4" → 100  (ADR-007)
$rule = $class->ruleFor(PipingRuleKind::PIPE_SCHEDULE, $dn);  // ← @> operator, GiST index
$schedule = $rule?->value['schedule'] ?? throw new NoRuleForSize($class, $dn);
```

**Throws rather than returns null.** A missing rule means the PMS does not cover this size for
this class, which is an engineering error worth surfacing loudly — the same reasoning as
ADR-007's reference lookups throwing on `1/2" SCH 30`. A silent null here becomes a silent
default schedule, which becomes a wrong wall thickness on a pressure line.

---

## 4. Rule kind 2 — the branch table is **two-dimensional and legitimately overlapping**

The user's second question is a different shape, and assuming otherwise would have produced a
broken design. A PMS branch table is a matrix:

|  header ↓ / branch → | 1" | 2" | 4" | 6" |
|---|---|---|---|---|
| **6"** | SOCKOLET | WELDOLET | TEE(red.) | TEE |
| **4"** | WELDOLET | WELDOLET | TEE | — |
| **2"** | SOCKOLET | TEE | — | — |

So a rule is `(header_range × branch_range) → component_type`.

### 4.1 The spike that changed the design

My first instinct was to reuse the exclusion constraint in two dimensions:

```sql
EXCLUDE USING gist (piping_class_id WITH =, header_range WITH &&, branch_range WITH &&)
```

**It failed, and the failure was informative.** Inserting two perfectly normal PMS rules —

```
header [15,600)  branch [15,600)  → TEE        (the general case)
header [50,600)  branch [15,50)   → WELDOLET   (small branch off a large header)
```

— was **rejected** with `exclusion_violation`. The second rule's footprint sits *inside* the
first, and `&&` in both dimensions is true.

But both rules are correct, and every real branch table is written this way: **a general rule
plus more specific exceptions**. Forbidding overlap would force the engineer to enumerate every
cell of the matrix explicitly — dozens of rows where the PMS has three, and a fresh chance to
mistype each one.

**Conclusion: for the branch table, overlap is a feature, not corruption.** Resolution is by
**specificity — the narrowest matching rule wins.**

### 4.2 What is actually constrained

```sql
CREATE TABLE piping_class_branch_rules (
  id              uuid PRIMARY KEY,
  project_id      uuid NOT NULL,
  company_id      uuid NOT NULL,
  piping_class_id uuid NOT NULL REFERENCES piping_classes(id) ON DELETE CASCADE,
  header_range    int4range NOT NULL,
  branch_range    int4range NOT NULL,
  component_type  text NOT NULL,        -- TEE / REDUCING_TEE / WELDOLET / SOCKOLET / STUB_IN …
  value           jsonb,                -- rating, schedule override, reinforcement pad …
  source_ref      text,
  UNIQUE (piping_class_id, header_range, branch_range)   -- the same footprint twice is a typo
);
```

The `UNIQUE` on the exact footprint still catches genuine duplicates; overlap is allowed.

### 4.3 Resolution, verified

```sql
SELECT component_type
FROM piping_class_branch_rules
WHERE piping_class_id = ?
  AND header_range @> :header_dn
  AND branch_range @> :branch_dn
ORDER BY (upper(header_range) - lower(header_range))
       + (upper(branch_range) - lower(branch_range)) ASC   -- narrowest footprint first
LIMIT 1;
```

Tested against the three-rule fixture above:

| Header | Branch | Rules matching | Chosen | Correct? |
|---|---|---|---|---|
| 6" (DN150) | 6" (DN150) | TEE | **TEE** | yes — equal size |
| 6" (DN150) | 1" (DN25) | TEE, WELDOLET, SOCKOLET | **SOCKOLET** | yes — tightest footprint |
| 8" (DN200) | 1" (DN25) | TEE, WELDOLET, SOCKOLET | **SOCKOLET** | yes |

Three rules match a single cell, which is exactly why specificity has to be explicit. The
narrowness metric is `header span + branch span`; an `ORDER BY` tiebreak on an explicit
`priority` column handles the rare case where two rules are equally narrow.

### 4.4 A constraint the database cannot express

`branch_dn ≤ header_dn` — a 6" branch off a 2" header is nonsense. This cannot be a row-level
CHECK because it is a property of the *query*, not of the rule. It belongs in the resolver, and
it is worth a distinct exception (`BranchLargerThanHeader`) rather than a generic "no rule
found", because the two have completely different causes: one is a data-entry error in the
model, the other a gap in the PMS.

---

## 5. Where this plugs into ADR-006

| ADR-006 element | What ADR-008 gives it |
|---|---|
| `piping_lines.piping_class` | FK into `piping_classes` — the per-project register (ADR-006 §11.5) |
| `component_ports.wall_thickness` | **derived**: class rule → schedule, then ADR-007 → wall for (DN, schedule) |
| `components` at a branch | the expected `component_type`, so the model can be *checked* rather than trusted |
| `PortCompatibility` (§5.4) | a third verdict source: "legal per ASME, but **not what this class specifies**" |
| PCF / 3D import | every imported component can be validated against the class — the single highest-value automated check in the whole ingestion story |

That last row is worth emphasising. Once the PMS is data, importing a 3D model stops being a
transcription exercise and becomes an **audit**: 4,000 lines checked against their class in
seconds, with a report of every deviation. That is the «خیلی از اشتباهات کم شده» the user is
after — not faster typing, but a machine that disagrees with the designer when the designer is
wrong.

---

## 6. Two-layer validation, and why both layers are needed

| Layer | Question | Source | Verdict on failure |
|---|---|---|---|
| **Physical** (ADR-007) | does this size/schedule *exist* in ASME? | reference packs | **INVALID** — unbuildable |
| **Contractual** (ADR-008) | is it what the **PMS** specifies for this class? | project piping classes | **DEVIATION** — buildable, but not per spec |

Keeping them separate matters. A 6" SCH 60 pipe is perfectly real (ASME lists it) and perfectly
wrong on a class that says SCH 40 — reporting that as "invalid" would be false, and reporting it
as "fine" would miss the actual problem. This mirrors the **advisory inspection** decision in
the procurement module: the system reports, it does not silently block.

---

## 7. Open questions — all answered (2026-09-14), see ADR-009 §4

| # | Question | Answer | Effect |
|---|---|---|---|
| 1 | Do branch rules depend on more than the two sizes? | **No, two sizes only** | resolver stays 2-D; no speculative third axis |
| 2 | Are reducing tees a distinct component type? | **No — one `TEE`**, labelled Eq./Red. | reduction **derived from port sizes**, never stored; a stored type could contradict its own ports |
| 3 | Class inheritance? | **No — each class written out in full** | `parent_class_id` **dropped** from the design |
| 4 | Lock published classes? | **Yes** | `DRAFT → PUBLISHED`; published is read-only, edits create a new **revision**, lines keep pointing at the revision they were issued against |

The user also corrected the size-band example: no size ever falls in two bands. **The half-open
`[from, to)` encoding and the exclusion constraint stay** — they are now simply the correct
encoding of that intent, and the constraint guards it against transcription error rather than
against the user.

---

## 8. Build order

| Phase | Content |
|---|---|
| 0 | **ADR-007 reference packs** (sizes, schedules, end types) — prerequisite for DN conversion |
| 1 | `piping_classes` register + `piping_class_rules` + exclusion constraint + coverage gate + resolver with `NoRuleForSize` |
| 2 | `piping_class_branch_rules` + specificity resolver + `BranchLargerThanHeader` |
| 3 | Wire into ADR-006: derive `wall_thickness`, validate components against their class |
| 4 | Deviation reporting on import (the audit described in §5) |
| 5 | Class revisions and the publication lock (§7 #4 — confirmed required) |

## 9. What was actually built (2026-09-23)

**Phases 1, 2 and 3 are implemented and green: 39 tests.** The spikes of §3 and
§4.1 were re-run against this PostgreSQL 17 before any code was written, and all
four rows of the §3 table reproduced exactly — including the important one,
where the user's sentence transcribed literally as two inclusive bands is
rejected with a message naming DN100.

| Artefact | Contents |
|---|---|
| `…2026_09_23_100000_create_piping_class_rules.php` | both tables, the EXCLUDE constraint, the UNIQUE footprint, RLS, archive freeze |
| `Support/Piping/DnRange.php` | the half-open convention, in one place |
| `Support/Piping/PipingRuleKind.php` | 6 kinds, each declaring its payload key |
| `Support/Piping/Exceptions/{NoRuleForSize,BranchLargerThanHeader}Exception.php` | two faults, deliberately not one |
| `Models/PipingClass{Rule,BranchRule}.php` | + `rules()` / `branchRules()` on `PipingClass` |
| `Services/PipingClassRuleService.php` | write + resolve + coverage |
| `Services/PipingClassComplianceService.php` | phase 3: the audit |
| `tests/Feature/PipingClassRuleTest.php` | 29 tests |
| `tests/Feature/PipingClassComplianceTest.php` | 10 tests |

### Decisions taken during the build that this ADR did not anticipate

**`DnRange` exists because the convention must not live only in comments.**
PostgreSQL normalises whatever it is given — write `[15,100]` and it silently
becomes `[15,101)`. The boundary is therefore decided in exactly one class, and
`label()` prints the *inclusive* bound (`DN15–DN99`) because showing the stored
exclusive bound on screen would re-create the ambiguity the design removes.

**Write-time validation beyond what §3 described.** Three refusals were added
because each would otherwise produce a rule that looks stored and resolves to
nothing:
1. a payload that does not match its kind (`{"end_type":…}` on a schedule rule);
2. a band bounded by a DN that is not an ASME size (`DN17` to `DN63`);
3. **a schedule that does not exist across the whole band.** This is §6's
   two-layer check applied at write time, and the example is real and inside
   the user's own band: **SCH 160 is not made at 3½″ (DN90)**, so
   "½″ to 4″ SCH 160" is impossible even though it reads perfectly on paper.

**A rating and a schedule are alternative ways of stating strength.** The
compliance check asks the schedule question only of components whose wall is set
by one; a valve carries a pressure class instead. Read from the template pack
(`requiresRating`), not from a second hard-coded list that would drift. Without
this, every valve on every line would report a deviation, and a report full of
those is a report nobody reads.

**Four outcomes, not two.** `schedule.deviates` (designer to fix),
`piping_class.no_rule` (specification to fix), `piping_class.not_set`
(unjudgeable — saying VALID would imply an approval nobody gave) and
`schedule.unknown` (INVALID, physically unbuildable). Collapsing any pair sends
someone to read the wrong document.

**`STUB_IN` is a legal branch answer with no component behind it** — the branch
pipe is welded straight into the header. The component-type check allows it
explicitly rather than treating it as an unknown template.

### Still open

- **Phase 4** — deviation reporting wired into PCF/MTO import. `auditLine()` is
  the engine; nothing calls it during ingestion yet.
- **Phase 5** — class revisions and the publication lock (§7 #4). `coverage()`
  is the gate the lock needs, and it is built and tested; the state machine is
  not.
- **No screen.** Rules can only be created programmatically. The PMS arrives as
  a consultant PDF, so a transcription screen — with `uncoveredSizes()` shown
  live — is the natural next piece.
- `piping_classes.material` is still free text, unlinked to the material
  library. A `MATERIAL` rule kind is the obvious bridge and was deliberately
  not invented ahead of the user naming it.


---

## 10. AMENDMENT (2026-09-23) — no bands; one row per size

**User instruction:** «برای هر سایز لوله که در کلاس مورد نظر وجود دارند اسکجوئل
به صورت مجزا ثبت شود و از بازه استفاده نشود» — and, on how it is used: *the
user picks the pipe diameter, then picks its schedule.*

**This supersedes §1, §2 and §3 for `piping_class_rules`.** §4 (the branch
table) is unchanged.

### Why the original design was answering the wrong question

§1 opened with the four-inch ambiguity and built half-open ranges to resolve it.
That was a correct solution to a problem **the user does not have**, because a
PMS is not read as bands — it is read one diameter at a time. Storing bands made
the software's model disagree with the way the document is used.

The correction **removes the problem rather than solving it**:

| | bands (§3) | per size (this amendment) |
|---|---|---|
| four-inch ambiguity | solved by half-open encoding | **cannot arise** — no boundary exists |
| uniqueness | `EXCLUDE USING gist` + `btree_gist` | plain `UNIQUE (class, kind, dn)` |
| what a class covers | implied by band arithmetic | **exactly the rows it lists** |
| narrowing a class | rewrite boundaries, risk a gap | delete a row |
| revising one size | split a band into three | overwrite one row |
| schedule validity | checked across a whole band | checked **against its own size** |

That last row is a real improvement, not a wash. Under bands, "SCH 160 from ½″
to 4″" was refused because *somewhere* in the band a size failed. Now the
refusal says **SCH 160 is not made at 3½″** — the actual fact.

Notably, the **gap-detection machinery is gone entirely**: `range_agg`,
multirange parsing, the "is it contiguous" publication gate. There are no gaps
when a class simply lists its sizes. `coverage()` now answers the question that
is actually useful — *does this class cover the sizes the project uses?* — which
only the caller knows, so the required list is a parameter.

### Schema

`dn_range int4range` → `dn integer` + `nps varchar(16)`, both NOT NULL.

Both are stored on purpose: `dn` is the integer the lookup keys on, `nps` is the
label the engineer typed. `1 1/4` cannot be reconstructed from `32` without a
lookup, and a rule should be readable without one.

### API

| before | after |
|---|---|
| `addRule($class, $kind, DnRange, $value)` | `setRule($class, $kind, $nps, $value)` — upserts |
| — | `setRules($class, $kind, [$nps…], $value)` — transcription convenience |
| — | `sizesCovered($class, $kind)` — ascending by DN |
| — | `removeRule($class, $kind, $nps)` |
| `coverage()` → contiguity | `coverage($class, $kind, $requiredNps)` → what is missing |
| `uncoveredSizes()` | `uncoveredSizesInUse()` — sizes actually modelled but unspecified |

`setRules()` is **explicitly not a band**: it writes one independent row per
size, each correctable on its own afterwards. A PMS does often say "2 to 6 inch
SCH 40", and making someone type that six times is six chances to mistype it —
but what is *stored* is six rows. There is a test that changes one of them and
asserts the others do not move.

`setRule()` upserts, so re-stating a size is a **correction**, not a collision.
The `UNIQUE` index still stops two rows existing, and a test bypasses the
service with a raw insert to prove it — because a bulk import is exactly what
would.

### Test count unchanged: 39

The suites were **rewritten to the new intent, not deleted** — the fourth time
this rule has earned its place. `test_four_inch_resolves_to_exactly_one_schedule`
became `test_the_boundary_problem_cannot_arise`, which asserts that exactly one
row can speak for DN100.

`DnRange` survives, used **only** by the branch table, with its docblock
narrowed to say so.

---

## 11. ANALYSIS (2026-09-24) — what a real PMS is, and the four things we got wrong

**Status: agreed, NOT BUILT.** This section records a design conversation, not
code. Everything in §9 and §10 still describes what actually runs today. Read
this before writing phase 4.

The trigger was a question — "what do you actually know about PMS in the real
world?" — answered by reading three complete PMS documents (EIL 293 pp, GAIL
`SP-01`, Assam Gas `VCS-PL-PI-PMS-001`) rather than from memory. The comparison
was uncomfortable: the engine in §9/§10 is correct for the slice it covers, and
the slice is much narrower than the document it claims to model.

### 11.1 What a class sheet actually contains

```
PIPE CLASS      : A1A
RATING          : 150
BASE MATERIAL   : CARBON STEEL
CORROSION ALLOW : 1.5 MM
SPECIAL REQ     : Non IBR / Low Temp / NACE / Stress Relieved
SERVICE         : (free prose - which fluids this class is for)

TEMP  (degC)    -29    38    93   149   204   260   316   343   371
PRESS (kg/cm2)  19.33 19.33 16.17 14.41 13.35 11.95  9.84  8.78  7.73

BRANCH TABLE    (triangular matrix, letter codes)
NOTES           (numbered, referenced by row)
ITEM | SIZE | DESCRIPTION      <- the body
```

We model the branch table and a fragment of the body. We model none of the
header beyond three free-text columns.

### 11.2 The class code is a label, not data

The user's correction: the code is assigned by the design engineer, differs
between projects, and each segment carries project-specific meaning.

Therefore **nothing may be derived by parsing it.** `A1A` on one project and
`A1A` on another are not the same class. The truth lives in the header fields;
the code is an identifier in the project's namespace — which
`UNIQUE(project_id, code)` already gets right.

Because the segments do mean something, a per-project *code grammar* (segments
and their meanings) is worth holding in `project_piping_config` so the UI and
MTO can **explain** a code. Explaining is not deriving.

#### 11.2.1 ASME B31.3 slice 1 - a condition is not a service (2026-09-25)

**The user supplied ASME B31.3-2024.** The platform had leaned on it in four
places since step 4 - the material grouping, the fluid service category, the
wall thickness and the NDT percentages - without anyone having read it. This is
**slice 1 of 3**, chosen because it unblocks the PMS to ITP path the user named.

**`SEVERE_CYCLIC` WAS NEVER A FLUID SERVICE.** Clause 300.2 defines *"severe
cyclic conditions"* separately: *conditions applying to specific piping
components or joints for which the owner or the designer determines that design
and construction to better resist fatigue loading is warranted.* It sits
**alongside** the service, not inside it - a Category M line can be under severe
cyclic conditions and so can a Normal one. Holding it as a sixth value of one
enum made that ordinary combination **unrecordable**.

**And two real services were missing:** Elevated Temperature (300.2(c)) and
High Purity (300.2(e)). A class in either could not be stated at all.

So `piping_classes.fluid_service_category` now takes the **six** services B31.3
lists, and `severe_cyclic_conditions` is a boolean of its own. Rows already
carrying the old value are migrated rather than rejected: the service becomes
NULL - the sheet never said what it was - and the flag is set, which is exactly
what the sheet did say.

**CATEGORY D IS THE ONLY SERVICE THE PLATFORM CAN CONTRADICT.** It is the one
B31.3 defines with numbers: nonflammable, nontoxic, not damaging to tissue,
design gauge pressure **<= 1 035 kPa (150 psi)**, design temperature
**<= 186 C (366 F)**, fluid temperature **>= -29 C**. Every other service is a
judgement - *the owner determines*, *the engineering design specifies* - and
this engine has no standing to second-guess one. `CATEGORY_D_BOUNDS_EXCEEDED`
fires when a class calls itself Category D and its own design conditions say
otherwise; for every other service `categoryDViolations()` returns **null**,
which is a different answer from "checked and fine".

**The examination extent, from the Code instead of from habit.** 341.4.1 gives
Normal Fluid Service **at least 5 %** random radiography of circumferential butt
and miter groove welds per designated lot; 341.4.2 gives Category D **visual
examination only** - no percentage at all, and a percentage there is a Normal
figure that has wandered; 341.4.3 gives severe cyclic conditions **100 %**. The
extent is a **minimum**: 341.4.1 says "or to any greater extent specified in the
engineering design", so a stricter project specification is never in conflict.

Splitting the axis is what makes `examinationFor('CATEGORY_M', severeCyclic: true)`
answerable - 100 % radiography on a Category M line - which the old enum could
not express.

`fluid-service.ref.json` - `FluidService` - `FluidServiceTest` **10** -
`PipingClassHeaderTest` **26**.

**Not in this slice:** Table A-1 material groupings, the 304.1.2 wall thickness
equation, Table 341.3.2-1 acceptance criteria (the A-to-M letter matrix),
Chapter VIII (Category M), Chapter IX (High Pressure), and Tcr from Table
302.3.5-1. The pack says so itself, so the next reader does not assume B31.3 is
done.

### 11.2.2 ASME B31.3 slice 2 - the equation, and where the Code withdraws it (2026-09-25)

`PipingClassHeader` has been saying *"no B31.3 wall thickness can be
calculated"* since step 4 without anyone having read the clause. Slice 2 reads
it.

**The equation, clause 304.1.2:**

    t  = P*D / (2*(S*E*W + P*Y))     eq. (3a)
    tm = t + c

with every symbol defined in the pack, because an undefined symbol is an
invitation to guess. `tm = t + c` is an addition: a corrosion allowance is
metal permitted to disappear, not a factor on the design thickness.

**Table 304.1.1-1, coefficient Y** - five material families over eight
temperature bands, transcribed whole. Three things about it are easy to get
wrong and are now tested:

- the first column is **"482 C and below"** and the last **"677 C and above"** -
  open bands, not points. Read as points, an ordinary line at 20 C has no
  coefficient at all.
- Y **may be interpolated** for intermediate temperatures (the 304.1.2 symbol
  list says so). Ferritic steel at 524 C is 0.6.
- **gray iron is 0.0 and then blank.** The blank is the fact that gray iron is
  not used above 482 C, not a gap to fill.

**WHAT THE CALCULATOR REFUSES IS THE POINT OF IT.**

`WallThickness::calculate()` returns a refusal rather than a number in four
situations, and two of them are the Code withdrawing its own formula:

| refusal | why |
| --- | --- |
| `ALLOWABLE_STRESS_NOT_SUPPLIED` | Table A-1 is slice 3. S must arrive from a source the caller can cite. |
| `P_OVER_SE_ABOVE_0_385` | 304.1.2(b) withdraws the thin-wall equation there. |
| `THICK_WALL_T_AT_OR_ABOVE_D_OVER_6` | Same clause, other direction - and Y itself changes form. |
| `COEFFICIENT_Y_NOT_TABULATED` | Gray iron above 482 C, or a family the table does not list. |

**A pleasing result that fell out of testing it:** the two limits in 304.1.2(b)
are **one limit**. With Y = 0.4, `t/D = (P/SE) / (2(1 + 0.4·P/SE))`, and at
P/SE = 0.385 that is 0.1668 - which is 1/6. The Code states the same edge twice
because a designer may arrive at it from either direction.

**A claim checked in passing.** `materials.ref.json` has cited *"ASME B31.3
Table A-1 material groupings"* as its source since it was built, and the
library is keyed by **product form** rather than by metallurgy. Table A-1 is
indeed organised that way, in fourteen forms. The library's groups are a
coarser cut - it has `PIPE` where the Code separates "Pipe", "Pipe & tube",
"Smls. pipe" and "Wld. pipe" - because the distinction that matters to a
purchase order is not the one that matters to a stress table.

**WHY TABLE A-1 IS NOT HERE.** Its identification rows and its stress values
are printed in *separate page blocks* - thirty-five of them in the SI table
alone - joined only by a line number. A first parse recovered 55 of some 600
materials and mis-joined several. A wrong S produces a wrong wall thickness and
**nothing downstream can tell**. That is the most consequential number in the
Code, so it waits for slice 3 and a parse that asserts every line number
resolves to exactly one material and one contiguous temperature series.

`fluid-service.ref.json` v1.1.0 - `WallThickness` - `WallThicknessTest` **12**.

### 11.2.3 ASME B31.3 slice 3 - the allowable stress, and two gates (2026-09-25)

The last slice, and the number the other two were waiting for: **S**, the basic
allowable stress from Table A-1.

**THE TABLE IS A TRAP, AND THE FIRST TWO PARSES FELL INTO IT.** Table A-1
prints a material's identity and its stresses in *separate page blocks*, joined
only by a line number - and **that line number restarts in every material
section**. There is a line 1 in the iron section, another in carbon steel,
another in stainless. Joining on the number alone merged cast iron's 13.8 MPa
with carbon steel's 43.2 and produced stress curves that *rise* with
temperature.

Three faults were found by assertions rather than by reading:

| fault | symptom | fix |
| --- | --- | --- |
| line numbers restart per section | 40 duplicate lines, 29 rising curves | join on **(section, line)**, section advancing when an identification number goes backwards |
| the identification header changes between sections (carbon steel adds *Size* and *P-No.*) | 126 rows read of some 1 120 | anchor on the **spec number** instead of column position |
| stress values are printed as integers as well as decimals, and the header reads `No. to 40` | 194 stress rows read of 1 120, with a **stale temperature list** silently applied | accept integers; clear `temps` at every page break so a header that fails to parse yields **no** rows rather than wrong ones |

**TWO GATES BEFORE A VALUE MAY BE CITED.** Parsing is not verification, so a
value is `verified: true` only if

1. **the structural join held** - one identity per line per section, no
   conflicting value for a temperature, and a series that never rises; and
2. **it independently agrees with the Code's own basis**, para. 302.3.2,
   `S = min(UTS/3, two-thirds of yield)`, computed from tensile and yield
   figures held in `materials.ref.json` that came from the **ASTM
   specifications**, not from this table.

**77 of 798 materials clear both and are citable. 721 are held**, and
`stressAt()` returns null for them with `HELD_NOT_INDEPENDENTLY_CONFIRMED`.

**The strongest evidence that the join held is an absence.** Of the materials
with an independent check, **21 sit below the basis and none sits above it**. A
value below is ordinary - a class, a weld joint efficiency or a time-dependent
criterion governs instead. A value above would be impossible under the Code.
**A mis-join scatters in both directions**, so an all-below distribution is the
signature of a sound join and a stricter criterion, not of a parse error.

**The chain the three slices built now runs end to end.** NPS 6 A106 Gr B at
100 C, Class 150, 3 mm corrosion allowance:

    S  = 138.0 MPa      (slice 3, Table A-1)
    Y  = 0.4            (slice 2, Table 304.1.1-1)
    t  = 1.188 mm       (slice 2, eq. 3a)
    tm = 4.188 mm

Schedule 40 at NPS 6 is 7.11 mm, so an ordinary class is comfortable - which is
exactly the answer a reviewer expects, and exactly why a wrong S would have
been so hard to notice.

And when the material is held, **the chain stops rather than bending**: no S,
no thickness, and a refusal that names the missing input.

`allowable-stress.ref.json` - `AllowableStress` - `AllowableStressTest` **11**.

## 11.3 The P-T table is derived, not stored

The user's correction: the pressure-temperature rating is adapted from ASME
B16.5. So it must never be typed into a project.

B16.5 keys its rating tables on a **material group number** (Table 1A), not on
the specification: A105, A216 WCB and A350 LF2 are all Group 1.1; F304 is 2.1.
Table 2-<group> then gives pressure against temperature per class. Two hops:

```
grade  ->  B16.5 material group  ->  (group x class)  ->  P-T curve
           property of the grade      new reference pack
           (materials.ref.json)       (flange-pt-ratings.ref.json)
```

Hop one belongs beside `pNumber`, which grades already carry. Hop two is a pack
in the same shape as `pipe-schedules`.

Three constraints on that pack:

- **B16.5 stops at NPS 24.** 26" and above is B16.47 Series A or Series B, with
  different numbers. Our size pack runs to 48", so the pack needs a *standard*
  axis or it will answer confidently and wrongly above 24".
- **The flange table is a ceiling, not the answer.** Under B31.3 the weakest
  component governs; a class may be derated by a valve (B16.34), by an IBR
  restriction or by the wall calculation. The Assam Gas sheet shows a 150# CS
  class at 16.17 where Group 1.1 gives more. So: derive by default, allow an
  explicit override carrying a mandatory reason.
- **The numbers are not citable.** Public sources contradict each other on group
  membership — one places F316 in 2.2, another in 2.3. Every value enters with
  `verified: false`, per the standing rule for allowable stress.

Canonical pressure stays `kPa`; the published tables are bar and psi.

### 11.4 The body axis is (component type x qualifier x size)

The six `rule_kind` values are not one axis. They are a mixture:

| kind | what it really is |
| --- | --- |
| `PIPE_SCHEDULE` | an attribute of one component |
| `FLANGE_TYPE` | a qualifier on the flange component |
| `GASKET_TYPE` | a qualifier on the gasket component |
| `VALVE_TYPE` | a qualifier on the valve component |
| `END_PREPARATION` | a class-level policy affecting every component |
| `CORROSION_ALLOWANCE` | not a rule at all — a header field |

`component-templates.ref.json` already holds the correct axis: 22 codes with
qualifiers (`FLANGE` -> WN/SO/BL/SW/THD/LJ, `VALVE` -> GATE/GLOBE/BALL/...,
`ELBOW` -> 90LR/90SR/45/180LR). That list *is* a PMS item list. We built the
axis and then did not use it — the same failure as the material library.

A body row becomes:

```
(class, FLANGE, WN,   6") -> {spec:A105, form:FORGED, dimStandard:B16.5,
                              rating:150, end:BW, facing:RF}
(class, PIPE,   null, 6") -> {spec:A106, grade:B, form:SMLS,
                              dimStandard:B36.10M, schedule:40, end:BE}
```

`spec/grade/form` resolve against `MaterialLibrary` — the gasket pattern.

**`VALVE_TYPE` is a misreading.** Its docblock says "which valve the class wants
at this size (ball small, gate large)". A PMS does not choose valve function;
the P&ID does. A PMS states which valve types are *permitted* in the class
(absence from the sheet means not permitted) and, for each, its construction per
size. Both fall out of the new axis for free.

**`END_PREPARATION` survives** as the one genuine class-level rule. "SW below
1.5in, BW at 2in and above" must hold for every component at that size or the
joint cannot be made. PIP calls it *joint construction*. It stays at class
level, per size, and each component row's `end` is validated against it — a
policy and its observance, not two sources of truth.

**Schema consequence.** One size carries several rows of the same component type
(flange WN *and* flange BL; valve GATE *and* valve CHECK), so the key becomes
`(piping_class_id, component_type, qualifier, dn)`. Trap: in PostgreSQL two rows
with `qualifier IS NULL` do not collide under a plain `UNIQUE`, so `PIPE` would
silently admit duplicates. PG 17 gives the clean fix:

```sql
UNIQUE NULLS NOT DISTINCT (piping_class_id, component_type, qualifier, dn)
```

### 11.5 Corrosion allowance has two homes; one must go

`piping_classes.corrosion_allowance` (a `string(16)`) and
`PipingRuleKind::CORROSION_ALLOWANCE` both exist, and nothing reconciles them.
The enum's justification — "can legitimately vary with size" — was assumed by
the author, not stated by the user, and is wrong: CA is corrosion rate times
design life, both properties of the service, not of the diameter. A different CA
is what makes a different class (A1A at 1.5, A4A at 3.0).

**Confirmed by the user, 2026-09-24: a single class never carries different CA at
different sizes.** The rule kind goes; the header column stays and should become
`decimal corrosion_allowance_mm` — a number that feeds a B31.3 calculation, not
a string that accepts "3", "3 mm" and "1/8 in" alike. The rule kind has zero
callers outside its own definition, so removing it breaks nothing.

### 11.6 Header fields we have no home for

- `service_en` / `service_fa` — which fluids
- `special_requirement` — NACE, IBR, LTCS, stress relieved, HIC
- `design_temp_min` / `design_temp_max`
- **`fluid_service_category`** (B31.3: Normal, Category D, Category M, High
  Pressure, Severe Cyclic) — new, and load-bearing: it is what explains why one
  class takes 5% random radiography and another 100%. Without it the NDT
  percentages are unexplainable numbers.
- numbered notes, referenced from body rows

### 11.7 Revision: the whole document, and the register already does it

**User decision: the PMS revises as one document, and there is one PMS per
project.**

No new mechanism is needed. `documents` -> `document_revisions` ->
`document_files` exists with `cde_state` and RLS sharing, and ITP was registered
the same way (`2026_09_19_210000_register_itp_as_a_document.php`). PMS follows
that precedent. Classes hang off a revision; the standing constraint "a
published class locks" is then derived from document state rather than
separately enforced.

Copy-on-write per revision is affordable: ~50 classes x ~20 component types x
~20 sizes is ~20,000 rows a revision, ~200,000 over ten. That is nothing.

**User decision: lines already AFC stay pinned to the revision they were built
to, and are flagged as impacted when a new revision is issued.** They are not
migrated forward.

### 11.8 NDT belongs in the PMS and feeds the ITP

**User decision: NDT lives in the PMS.**

`itp_stages` already has exactly the columns an NDT requirement needs —
`method` (VI/DI/UT/MT/PT/RT/PMI/LT/FT/DR), `frequency_en`, `acceptance_en`,
`reference`. The mapping is close to one-to-one.

Direction, per the user's standing rule against a second source of truth: **the
PMS states, the ITP cites.**

### 11.9 Speciality (SP) items — in scope, plus manual valves

**User decision: SP items are in scope now, and non-automatic (manual) valves
are to be added.**

Manual valves in the PMS finally consume `VALVE_TRIM` (6 specs / 43 trims), the
third asset built and never wired. A manual valve row needs body (`CASTINGS` or
`FORGINGS`, body only per the standing constraint), trim (`VALVE_TRIM`),
rating, ends, construction standard (API 600/602/6D, BS 1868) and **operator**
(handwheel / lever / gear / chainwheel). Operator is per size — a gearbox
becomes mandatory above a diameter — so it sits on the new axis unchanged.

This yields a clean boundary and does **not** reopen the §5ag deferral: if it
has an actuator it is a datasheet; if it does not, it is a PMS row. The actuator
pack is the discriminator. Control valves, PSV/TSV and the valve function-tag
axis remain deferred.

**BUILT, 2026-09-25.** `piping_class_valve_specs` — a 1:1 side table on the body
row, not four more columns on `piping_class_items`, because a trim, a
construction standard and an operator are NULL on every pipe, flange, elbow and
gasket row in the system. The discriminator is enforced by the schema and not by
a comment: `operator` is CHECKed to `HANDWHEEL / LEVER / GEAR / CHAINWHEEL`, and
there is no actuator column and no fail-safe column at all, so an MOV cannot be
written into a class body.

Three references answer the three independent questions, and two of them had
been sitting unwired since the rounds that built them:

| question | source | state before this round |
| --- | --- | --- |
| body | material library, groups `CASTINGS` / `FORGINGS` | wired (§11.12 step 5) |
| trim | material library, group `VALVE_TRIM` | **built, never consumed** |
| operator | `actuators.ref.json`, the `power: MANUAL` half | **built, never consumed** |
| construction standard | `valve-construction.ref.json` | **new — nothing held it** |

The new pack holds 13 standards (API 600/602/603/594/599/608/609/623/6D,
BS 1414/1868/1873, ISO 15761), each with the valve types it covers, the body
product forms it implies and its NPS window. Every row carries
`verified: false` — none of these standards is in the repo — so a finding built
on a size scope says so in its own message rather than quoting it as the
standard's requirement. `ValveConstruction::scopeIsCitable()` exists so the day
a copy of API 600 is bought, one data change makes the findings citable and no
code changes.

`ManualValves` reports 15 codes and refuses nothing (§11.10). Two are worth
recording as decisions rather than as code:

- **No gearbox threshold is hardcoded.** "Gear operator above NPS 8" is real in
  practice and different in every project specification, and this repo has
  already been bitten by a validator rule that encoded the author's habit rather
  than a standard. Instead `operatorConsistency()` compares a class **against
  itself**: if the 6 inch gate valve in this class is geared, the 12 inch one
  cannot be a bare handwheel. Nothing outside the document is consulted, so the
  rule cannot be a rule about the transcriber.
- **A check valve takes no operator, and that falls out of the data.** The
  actuator pack holds no travel for `CHECK`, so `travelOf()` returns null and
  the absence is correct rather than a special case in code. The mirror of the
  same fact catches a handwheel on a ball valve: quarter turn against multi
  turn is mechanical, not a preference.

`CHAINWHEEL` was added to `actuators.ref.json` (v1.1.0) for this round. It is
exempt from the travel test on purpose: a chainwheel is not a way of making
torque, it is a way of REACHING a valve mounted out of arm's length, and it
hangs off whatever operator is underneath.

`ManualValveTest` — **42 tests**.

#### 11.9.1 The valve is rated by B16.34, not by the flange standard (2026-09-25)

**The user supplied ASME B16.34-2025.** It closes the gap named first in the
standards review: until this round the platform held B16.5 and B16.47 and
nothing else, so a valve's pressure–temperature envelope was being read off the
**flange** tables. That is the commonest specification error in piping, and it
is wrong in three concrete ways:

| | B16.5 (flange) | B16.34 (valve) |
| --- | --- | --- |
| Class 400 | rated | **not tabulated at all** |
| Class 4500 | absent | **rated** |
| Special Class | no such concept | **a second, higher envelope** for valves that pass extra NDE |

`valve-pt-ratings.ref.json` — **100 curves** (50 material groups × Standard and
Special), **2,002 temperature points**, SI only, all `verified: true`. The U.S.
customary tables are the same curves re-rounded and are deliberately not
transcribed: two copies of one fact is two answers.

**The corroboration, and what it cost to check.** B16.34 Standard Class is
supposed to reproduce the flange ratings for the same material group. Against
the already-verified B16.5 pack it does so in **4,039 of 4,050** comparable
cells. The eleven that differ are listed in `crossStandardDiscrepancies`, and
they are the reason the pack had to be transcribed rather than aliased.

**Four cells of B16.34-2025 do not survive arithmetic.** All four are digit
transpositions in the high classes, and all four were found by validator rules
rather than by reading:

| group | rating class | °C | class | printed | corroborated |
| --- | --- | --- | --- | --- | --- |
| 1.18 | Standard | 500 | 1500 | 106.6 bar | 160.6 bar |
| 3.19 | Standard | 450 | 2500 | 205.9 bar | 295.9 bar |
| 2.1 | Special | 538 | 4500 | 462.2 bar | 426.2 bar |
| 2.9 | Special | 425 | 4500 | 587.7 bar | 538.7 bar |

Each is stored **as printed** — a transcription that silently corrects its
source stops being a transcription — and each carries `doNotCite` plus the
evidence for calling it an error. `ratingAt()` returns null for those cells and
`refusalFor()` says `CELL_WITHHELD_AS_SUSPECTED_PRINTING_ERROR`; an
interpolation that would span one is refused too. This is the `verified: false`
principle applied one cell at a time.

Two of the four arbitrate each other: groups 1.18 and 3.19 are printed with the
same Standard Class curve from 38 °C to 600 °C, and each group's bad cell is
contradicted by the other's good one.

`ValvePtRatings` refuses rather than guesses in four distinct ways
(`MATERIAL_GROUP_UNKNOWN`, `PRESSURE_CLASS_NOT_TABULATED`,
`ABOVE_THE_LAST_TABULATED_TEMPERATURE`, `CELL_WITHHELD_…`) plus
`LIMITED_CLASS_IS_COMPUTED` — Mandatory Appendix V derives Limited Class per
valve from a stress area, so there is no table and a bare null would read as
missing data.

`groupFor('A182')` returns **null**, not the first group found: A182 runs from
F1 to F91 across a dozen groups, and a plausible-looking wrong curve is worse
than no curve. That distinction produced a second one in `ManualValves` —
`BODY_NOT_IN_B1634` (the standard has never heard of this spec, a DISCREPANCY)
is now separate from `BODY_GRADE_NOT_STATED` (A216 is there twice, as WCB in
group 1.1 and WCC in 1.2, and the row does not say which — INCOMPLETE).

Five new findings on a valve row: `RATING_ABSENT`, `RATING_NOT_A_VALVE_CLASS`,
`BODY_NOT_IN_B1634`, `BODY_GRADE_NOT_STATED`,
`DESIGN_TEMPERATURE_ABOVE_THE_CURVE`, and `MATERIAL_NOTE_LIMITS_TEMPERATURE` —
the last because "not to be used over 371 °C" sits under a table that keeps
printing numbers above 371 °C, so the note has to travel with the material or
the grid over-rates the valve. **This is the first check in the system that puts
a material, a pressure class and a design temperature together and asks whether
the valve can actually hold.**

#### 11.9.2 The length, from B16.10 (2026-09-25)

**The user supplied ASME B16.10-2022.** A rating is not a drawing: B16.34 says
a Class 600 gate valve in A216 WCB holds 102 bar at 38 °C, and B16.10 says it
is 559 mm long. The second number closes an isometric and sets the cut length
of the pipe either side of the valve, and the platform had no source for it.

`valve-face-to-face.ref.json` — **1,833 dimensions**, 6 pressure classes, 11
valve types, plus **267 ring-joint adjustments** (Table 3.3-1) and **12 facing
rules** (Table 3.2-1).

**Scope: steel only.** The Class 125/250 cast-iron and AWWA columns were read
and discarded — 478 cells. B16.34, which supplies the rating, does not cover
cast iron and the material library holds no cast-iron valve body, so a length
for one could never be paired with anything.

**Four symbols, not one number.** `A` face-to-face flanged, `B` end-to-end
buttwelding, `D` centre-to-face and `E` centre-to-end for angle bodies, which
have no face-to-face because they turn a corner. A column headed "A and B"
prints one figure serving both, so two rows are emitted from it.

**One column can serve several valve types.** "Globe, Lift Check, and Swing
Check" is one column: at Class 600 NPS 6 all three are 559 mm, by the standard
and not by coincidence. `valveTypes` is therefore a list.

**The finding that changed the model.** A **lift check appears twice** in Table
1.5-1 — with the globes as an in-line body measured face-to-face (symbol A,
559 mm) and with the angle valves measured centre-to-face (symbol D, 279 mm).
Same valve type, same class, same size, two bodies, 280 mm apart. `lengthFor()`
returns null and `refusalFor()` says `SEVERAL_BODY_STYLES_OFFERED` rather than
picking one.

**Nineteen printed irregularities, all declared, none corrected.** Sixteen
places where a valve gets *shorter* as it gets bigger and three cells where the
millimetre and inch columns disagree beyond rounding. Two have the standard's
own explanation: Table 1.3-1 column 9 takes its large sizes from **API 6D**
(note 14), so that column is two standards spliced together; and Class 900
valves NPS 2½ and smaller carry **Class 1500** dimensions by note (2) of Table
1.5-2, which makes the small end of the column longer than the sizes above it.

**The erratum.** ASME issued a March 2023 erratum for misaligned column
headings on pages 13 and 21. The corrected pages are bound at the **front** of
the PDF, ahead of the title page, so a naive parse reads them first and then
overwrites them with the faulty originals. They are parsed last, and compared:
**0 cells differ**, so the erratum changed headings only — which is what ASME
said — and the column map was read from the corrected pages.

**Cross-pack check.** Every class dimensioned here is one B16.34 rates, and
`pipe-sizes` supplies the DN↔NPS vocabulary (the validator caught this pack
spelling NPS 1½ as `1-1/2` where the platform spells it `1 1/2`). One class is
rated and not dimensioned: **4500**. A valve can be perfectly rateable and not
drawable, and that is now sayable.

Three more findings on a valve row: `NO_TABULATED_LENGTH`,
`PATTERN_NOT_STATED` and `DIMENSIONAL_STANDARD_DOES_NOT_COVER_IT`. The middle
one matters most in practice — B16.10 routinely offers two lengths (a Class 600
gate valve is 559 mm long or 457 mm short) and a PMS row naming neither has not
specified the valve. The pattern is looked for in `description_as_written`
first, because that is where a real sheet puts it, and the finding is only
raised when the row cites B16.10 for itself.

`ValveFaceToFaceTest` — **15 tests**. `ManualValveTest` — **46**.

#### 11.9.3 The tests, from API 598 (2026-09-25)

**The user supplied API Standard 598 (2023).** It is the third leg of the
valve: B16.34 rates it, B16.10 measures it, API 598 says what has to be
witnessed before anyone accepts it. **This is the first reference pack in the
platform that produces ITP rows rather than drawing figures.**

`valve-testing.ref.json` — **60 requirement rows** (Table 1) over 6 test
columns, **10 shell-pressure rules** (Table 2), **13 closure-pressure rows**
(Table 3), **5 duration bands** (Table 4), **22 leakage rows** (Table 5) plus
the formulas that take over above NPS 48.

**The shell test pressure is not printed in API 598.** For a steel valve Table
2 gives a *rule*: 1.5 × the pressure rating at 38 °C, rounded **up** to the
next whole bar. The rating is in ASME B16.34, which the platform now holds, so
`ValveTesting::shellTestPressureBarG()` computes it — **the first calculation
in the system that needs two purchased standards at once**:

| class | B16.34 rating at 38 °C (group 1.1) | × 1.5 | shell test |
| --- | --- | --- | --- |
| 150 | 19.6 bar | 29.4 | **30 barG** |
| 300 | 51.0 bar | 76.5 | **77 barG** |
| 600 | 102.0 bar | 153.0 | **153 barG** |
| 1500 | 255.1 bar | 382.65 | **383 barG** |

Without a material group there is no answer, and `shellTestPressureBarG()`
returns null rather than a figure that would be right for group 1.1 and wrong
for the other forty-nine.

**Two axes the PMS does not have.** API 598 tests a **floating** ball valve
differently from a **trunnion mounted** one, and an API 609 **Category A**
butterfly differently from a **Category B**. A PMS row says "BALL" and stops.
`testsFor()` returns nothing and `refusalFor()` says `VARIANT_REQUIRED`, naming
the choices — the gap made visible rather than guessed past. A gate valve, by
contrast, has a column of its own, so "parallel slide gate" is an extra route
into the globe column and not a missing answer: `requiresVariant('GATE')` is
false and nobody is nagged about ordinary gate valves.

**Two traps inside Table 1**, both now asserted by tests:

1. **The high- and low-pressure closure rows invert.** Wherever the low-pressure
   test becomes optional, the high-pressure one becomes required. They are one
   decision written twice, and a copy-paste between them would be invisible.
2. **The class threshold moves with the size.** The closure rows split at Class
   1500 for DN ≤ 100 and at Class **600** for DN > 100. A Class 900 valve is on
   opposite sides of the line at NPS 4 and NPS 6. Reading it as a single
   boundary mis-states every large valve between Class 600 and 1500.

`leakageFor()` distinguishes a check valve (mL/min) from everything else
(drops/min) — different columns of Table 5, and reading across the wrong pair
is an order-of-magnitude error on an acceptance criterion. A **resilient seat is
zero at every size**, because that is what the seat type means rather than a
tabulated rate. Above DN 1200 the table stops and the standard's formulas take
over; extrapolating the table instead would be a different, wrong answer.

`ValveTestingTest` — **18 tests**.

**Next: wire it into the ITP (ADR-015).** The pack now answers "which tests, at
what pressure, for how long, to what leakage" for any valve in the PMS; the ITP
service does not yet ask.

#### 11.9.4 API 600 arrives, and corrects three guesses (2026-09-25)

**The user supplied API Standard 600 (2021).** It is the first purchased copy
that is a **109 dpi scan with no text layer**, and that changes what can be
taken from it: the prose OCRs almost perfectly, the landscape numeric tables do
not. So this round verifies the **scope** and transcribes **no tables at all**.

**The verified:false discipline paid for itself.** Three of our guesses about
API 600 were wrong, and each was producing a false finding:

| field | guessed | actually | what it was doing |
| --- | --- | --- | --- |
| `bodyGroups` | `[CASTINGS]` | `[CASTINGS, FORGINGS]` | flagging every legitimate A105 **forged** gate valve as `BODY_FORM_AGAINST_STANDARD` |
| `npsMin` | 2 | **1** | putting every NPS 1–1½ API 600 valve out of scope |
| `npsMax` | *(open)* | **42** | accepting an NPS 48 gate valve API 600 does not cover |

The forged-body error is the instructive one. The guess — "API 600 is cast,
API 602 is its forged small-bore counterpart" — is what every piping engineer
says, and it is wrong: **Table D.1 gives the Group 1.1 body as "C-Si A105 or
A216-WCB"**, a forging and a casting in one row, and 7.3 speaks of "the shell of
a cast or forged, carbon or alloy steel valve". The old value is kept in
`correctedFromGuess` rather than deleted, because the point of the record is to
show which findings the platform was raising wrongly and from which field.

**Verified from clause 1:** bolted bonnet, outside screw and yoke, rising stem,
non-rising handwheel, single or double gate, wedge or parallel seating, metallic
seating surfaces, flanged or butt-welding ends; **DN 25–1050 (NPS 1–42)**;
**classes 150, 300, 600, 900, 1500, 2500**. `scopeIsCitable('API 600')` is now
**true** — the first of the thirteen — and its out-of-scope findings no longer
append "scope read from the standard title, not from a purchased copy".

**New concept: `sourceQuality`.** Owning a standard is not the same as being
able to read it, and the pack now distinguishes `NOT_HELD`, `TEXT` and
`SCANNED_IMAGE`. API 600 is `SCANNED_IMAGE`, and `tablesNotTranscribed` names
the seven tables that were deliberately left alone — minimum wall thickness,
wear travel, stem diameter, packing width, seating/stem/backseat materials,
trim numbers, and the Annex D material combinations — with the reason (*"a
figure that is wrong in the third digit is indistinguishable from a right
one"*) and what would fix it (*a text-layer PDF, or a scan at 300 dpi or
better*).

**The trim chart stays unverified.** `VALVE_TRIM` still carries 20 API 600 trims
at `verified: false`. Table 9 is exactly the table OCR cannot be trusted on, and
a trim number attached to the wrong seating material is a procurement error
wearing a standard's name.

`ManualValveTest` — **50 tests**, including three that assert the corrected
behaviour and two rewritten because they had encoded the wrong guess.

#### 11.9.5 A readable API 600, and the trim chart stops being folklore (2026-09-25)

**The user supplied a text-layer copy of API 600-2021.** The scan verified the
scope; this verifies **Table 8**, which is the chart the whole valve module
turns on.

**The industry chart had 20 trims. Table 8 has 30.** Missing from ours: **5B**
and the entire nickel-alloy family **19, 19A, 19B, 19C, 20, 20A, 20B, 20C, 21**
— Alloy 625, C276 and 825, which are ordinary selections on sour and seawater
service and simply could not be recorded.

**Trim 1 is obsolete.** Table 8 prints "TRIM NUMBER 1 IS OBSOLETE" across the
row. Until the standard was read, the platform offered it as a normal choice.
It is now **held but not offered**: `trimsFor('GATE')` returns 29,
`trimsFor('GATE', true)` returns 30, and a row naming it raises
`TRIM_WITHDRAWN` — "the standard dropped this" rather than "we have never heard
of it", which is a different instruction to a transcriber. Deleting it would
have turned a reportable fact into an unknown trim.

**Table 9 adds substitution.** Specify trim 10 and the manufacturer may supply
12 or 16; specify 8 and they may supply 5. The relation runs **one way** and is
recorded as such.

**Two more inventions exposed.** The old chart gave trim 9 a stem of *ASTM B564
N04400* and trim 6 a seat of *ASTM B151*. Table 8 gives trim 9's stem as **MFG
Standard** — the standard defers to the manufacturer — and trim 6's second
seating surface as Cu-Ni per note (k), with no specification at all. Plausible
inventions are the hardest kind to notice, and both had survived a full test
suite.

**The shape changed because the standard's shape is different.** The old model
split a trim into **seat, disc, backseat, stem** — our invention. Table 8's
columns are **seating surface** (one concept covering the seat ring and the
wedge face, which is why a trim can name two of them) and **stem/backseat
bushing** as a single column group with one material type and two hardness
columns. `requiredParts` for API 600 is now
`['seatingSurface', 'stem', 'backseatBushing']`.

A seating surface also resolves through **up to three routes** — cast integral,
forged integral, weld deposited — so the property is `seatingSurfaceSpecifications`,
plural. Collapsing them into one would force a choice the standard leaves to
the manufacturer.

**Two sentinels are now first-class.** `MFG Standard` (the standard declining to
name a specification) and `WITHDRAWN` (an obsoleted trim). Both are carried
through the specification *and* the grade so they cannot be mistaken for data,
and the validator checks that pairing.

`valve-construction` API 600 is now `sourceQuality: TEXT`, and
`tablesNotTranscribed` changes meaning: the remaining tables are dimensional
and bolting data **nothing asks for yet**, not data that cannot be read.

`ManualValveTest` **55**, `MaterialLibraryTest` **108**. Wider run **530 passed
/ 9,394 assertions**.

#### 11.9.6 API 602, and Class 800 stops being a formula off the web (2026-09-25)

**The user supplied API Standard 602, 10th edition (2015)** — the small-bore
companion to API 600. Two things came out of it, and the second is the larger.

**The cast/forged folklore is now wrong at BOTH ends.** Our unverified entry
said API 602 meant a forged body. **Table 1a lists castings — A216 WCB, A352
LCC, A351 CF8M — beside the forgings.** API 600 said the same thing last round.
Two standards checked, two single-form claims collapsed, and six entries in the
pack still carry one. So `BODY_FORM_AGAINST_STANDARD` now **discloses in its own
message** whether the claim behind it is a citation or a habit — the same
treatment the size-scope finding already had.

Also corrected: `npsMin` was open, and clause 1 starts at **DN 8 (NPS ¼)**.
Confirmed unchanged: gate, globe **and** check; NPS 4 ceiling.

**CLASS 800 IS NOW CITED, NOT GUESSED.** The platform derived it as
`1/3 × Class 600 + 2/3 × Class 900` from public sources, `verified: false`.
API 602 **clause 4.1.3** defines it: the ratings *"are a linear interpolation of
Standard Class 600 and Standard Class 900 pressure/temperature ratings listed in
ASME B16.34"*. Class 800 sits two thirds of the way from 600 to 900 — the same
weights. **The guess was right and is now a citation.**

Two further things fell out of reading the clause:

- **The base standard was wrong.** The entry said `appliesToStandard: B16.5`.
  Clause 4.1.3 says **B16.34**. A Class 800 *valve* was being derived from the
  *flange* tables — the same error, in miniature, that `valve-pt-ratings` exists
  to correct.
- **API 602 cites B16.34 undated**, and says that for undated references the
  latest edition applies. So for a project today the governing Class 800 rating
  is the interpolation of **B16.34-2025**, *not* the figure printed in API
  602-2015 Table 2a. The printed table is a snapshot; the rule is the
  requirement.

**Corroboration.** Applying the clause to our verified B16.34 group 1.1 against
API 602's printed Table 2a: **14 of 16 rows within 0.023 MPa**. The two that
differ — 50 °C (13.273 computed vs 13.37 printed) and 500 °C (3.073 vs 3.14) —
are declared, and are consistent with B16.34 having moved in the decade between
the two documents rather than with an error on either side.

The validator rule that blanket-refused `verified` on a derived class was
relaxed on the same terms as the curve rule before it: a derived class may claim
it only if it names the clause, the date read, and the standard it derives from.

**Four tests had encoded the old guesses** and were rewritten — including one
that had already been rewritten once, from API 600 to API 602, and was wrong
both times. It now asserts the *disclosure* rather than the claim.

`ManualValveTest` **57**, `ValvePtRatingsTest` **21**. Wider run **534 passed /
9,409 assertions**.

#### 11.9.7 API 603, and the field that was asking the wrong question (2026-09-25)

**The user supplied API Standard 603 (2025)** — the corrosion-resistant cut of
the gate valve. Verified from clause 1: **NPS ½ to 24**, **classes 150, 300 and
600 only**, full port, bolted bonnet, OS&Y. It stops where API 600 keeps going
(NPS 42, Class 2500), and that ceiling is now checkable.

**The third single-product-form claim collapsed** — clause 7.3 again says *"the
shell of a cast or forged valve"*. Three standards read, three collapses. But
API 603 makes the more useful point: **it does not restrict the product form at
all.** Table 4 gives the body as *"As selected from ASME B16.34, **Group 2 and
Group 3**"*.

That is what "corrosion-resistant" in the title means, stated as something a
machine can test — and the platform can test it, because `valve-pt-ratings`
holds all fifty B16.34 groups. So `bodyMaterialGroups` was added beside
`bodyGroups`, and a new finding
**`BODY_MATERIAL_GROUP_AGAINST_STANDARD`** resolves the row's spec and grade to
its B16.34 group and checks the family: A216 WCB is group **1.1** and therefore
outside API 603 *however it was made*, while A351 CF8M is **2.2** and ordinary.

**The lesson is about our own model, not the standard.** `bodyGroups` asks which
product form a standard permits. Three standards in, the answer is always
"both", and for API 603 the question was simply the wrong one. A field that
keeps returning the same answer is usually measuring the wrong thing.

**A cross-pack link fell out too.** Clause 7.2: *"Each valve shall be pressure
tested as specified in API 598."* `testedTo('API 603')` now returns `API 598`,
so the construction pack and the testing pack meet without anyone hardcoding
the join.

**Trim vocabulary recorded, not duplicated.** API 603 Table 5 uses the API 600
trim numbers but only **24 of the 30** — 5B and the 20/20A/20B/20C/21 hardfaced
nickel family are absent — and Table 6 offers **three** substitutions where API
600 Table 9 offers six, because the 13Cr-based swaps have no place on a
corrosion-resistant valve. That is held as a `trimVocabulary` note on the entry
rather than as a second copy of the chart: re-transcribing it would create two
answers to one question.

`ManualValveTest` **61**. Wider run **538 passed / 9,419 assertions**.

#### 11.9.8 API 608: a valve is not its shell (2026-09-25)

**The user supplied API Standard 608 (2020).** The largest correction of the
whole valve sequence came out of clause 4.1:

> *"The valve pressure-temperature rating shall be the lesser of the shell
> rating or the seat and seal rating."*

Until now the platform read the shell rating out of B16.34 and called it the
valve rating. For a soft-seated ball valve that is not a rounding error. A
**Class 600** group 1.1 shell is **102 bar** at 38 °C; the same valve with a
**PTFE seat above DN 100 is 19.7 bar** — a factor of five, in the direction that
buys a valve for five times the pressure it can hold.

`valve-pt-ratings` gains **`seatRatings`** — API 608 Table 1, 8 curves and 52
points, PTFE and R-PTFE × floating and trunnion × three size bands — and
**`governingRatingAt()`**, which returns the lesser of shell and seat with a
`governedBy` flag. A metal seat is unaffected: Table 1 does not cover it, so the
pack returns the shell and says so rather than implying anything.

**`SEAT_GOVERNS_THE_RATING`** reports the gap on a PMS row, with both figures in
the message.

**THE API 598 ARC CLOSES.** `ValveTesting::testsFor('BALL', …)` has been
refusing with `VARIANT_REQUIRED` since the API 598 round, because API 598 tests
a floating ball differently from a trunnion mounted one and a PMS row says only
"BALL". **API 608 clause 1.4 is where that vocabulary comes from** — *"floating
(seat-supported) ball (Figure C.1) and trunnion ball valve designs (Figure
C.2)"*. `ValveConstruction::designVariants('API 608')` now returns exactly the
two names `ValveTesting::variantsFor('BALL')` asks for, and a test asserts the
two packs agree. The gap became **`BALL_DESIGN_NOT_STATED`** — reportable
instead of silent.

**A scope shape the model did not have: size and class depend on the END TYPE.**
Clause 1.1/1.2 — flanged and butt-welding run NPS ½–24, socket-welding and
threaded stop at **NPS 2**; and flanged stops at **Class 600** while the other
three reach **Class 800**. One `npsMin`/`npsMax`/`pressureClasses` triple cannot
say that, so `endTypeScopes` carries it and the flat fields hold the union.

Note the mirror with API 602, where flanged ends existed at every class *except*
800. Two standards now say the same thing from opposite directions: **Class 800
is a non-flanged, compact-valve class.**

Clause 4.2 sends Class 800 shell ratings to **API 602 (2016) Tables 2a–2f** — a
second standard pointing at the source the Class 800 derivation was verified
against last round. *(We hold API 602-2015; the citation is dated 2016 and that
difference is recorded rather than assumed away.)*

`ManualValveTest` **66**. Wider run **543 passed / 9,435 assertions**.

#### 11.9.9 API 609: the valve with no ASME class (2026-09-25)

**The user supplied API Standard 609 (2021).** It completes the valve
construction set and contributes the sharpest category distinction yet.

**Category A butterfly valves have no ASME pressure class at all.** Clause
1.2 a): they are *"manufacturer's rated cold working pressure (CWP)"* valves
carrying a class **125 or 150 flange BOLTING PATTERN** — which looks like a
class and is not one. Category B is the ASME class and P-T rated valve, with an
offset seat. Any code that reads a Class 150 shell rating for a Category A valve
has invented a figure the standard never claimed, so `ratingBasis` records the
difference per variant and the seat table refuses Category A outright.

**Both halves of the API 598 gap are now closed from the construction
standards.** API 598 note (h) says *"Butterfly Category A and Category B
definition according to API 609"* — and `designVariants('API 609')` now returns
exactly what `ValveTesting::variantsFor('BUTTERFLY')` asks for, as API 608 did
for the ball designs last round. A test asserts each pair agrees.

**The seat table gained a second shape.** API 608 keys a ball seat on the ball
design and a DN band; **API 609 Table 1 keys a butterfly seat on the pressure
class.** Same idea, different axes, so a seat curve now carries a
`discriminators` map instead of fixed fields, and a caller that does not supply
them gets null rather than whichever curve matched first. **Class 600 has an
R-PTFE column and no PTFE column** — the standard declines to rate PTFE there,
which is an answer and not a missing cell.

`seatRatings` is now 13 curves: 8 ball (API 608) and 5 butterfly (API 609).

**A win NOT claimed.** The tempting story was "a fourth single-product-form
claim collapses". It did not: API 609's `bodyGroups` was **already null** — the
entry never claimed a product form. The validator caught the overstatement
(*"records a correction to bodyGroups that changed nothing"*) and the entry now
says so explicitly. Clause 1.1 does give it the widest material scope of the
five read: gray iron, ductile iron, bronze, steel, nickel-based and special
alloys.

**A gap in OUR vocabulary, surfaced rather than hidden.** API 609 reaches
**NPS 60** and `pipe-sizes` stops at **NPS 48**. Rather than truncate the
standard to fit the pack, `npsMaxBeyondPipeSizes` declares it and the validator
reports it as a note. ASME B36.10M is what would close it.

**Butterfly face-to-face is deliberately not transcribed.** Tables 2 and 3a–3c
give it, and **ASME B16.10 Table 1.3-4 already does**. Two sources for one
dimension is two answers; the honest next step is a deliberate cross-check
between them, and it has not been done.

`ManualValveTest` **68**, `ValvePtRatingsTest` **25**. Wider run **549 passed /
9,450 assertions**.

#### 11.9.10 API 623: a substitution table belongs to its standard (2026-09-25)

**The user supplied API Standard 623 (2021)** — the globe valve, and the sibling
of API 600. NPS 2–24, classes 150–2500, and the widest set of body
configurations here: bolted **and** pressure-seal bonnet, rotating and
nonrotating rising stems, rising and nonrising handwheels, straight / y-pattern
/ right-angle, and stop-check.

**Fourth genuine product-form collapse.** Table 7: *"Body and bonnet — As
selected from ASME B16.34, Group 1, Group 2, and Group 3."* All three groups, no
product-form restriction. Clauses 7.3 and 7.4 do speak only of castings, but
they are about *inspecting* a casting when one is used (MSS SP-55), not a
restriction to them.

The contrast with API 603 is now recorded on both entries, and it is the point:
**API 623 takes Groups 1, 2 and 3; API 603 takes only 2 and 3.** That limit is
what the word "corrosion-resistant" in the API 603 title actually buys.

**The globe trim chart went from 9 trims to 24.** The old spec held nine off an
industry chart, in the four-part shape the standard does not have. Table 8
carries the same 24 numbers as API 603 — the API 600 set without 5B and without
the 20/20A/20B/20C/21 nickel family — and prints **"TRIM NUMBER 1 IS OBSOLETE"**
just as API 600 does.

**A SUBSTITUTION TABLE BELONGS TO ITS STANDARD, NOT TO THE TRIM NUMBER.** API
623 Table 9 is *not* API 600 Table 9. It drops `8 → 5` and adds **`2 → 10`**,
which API 600 does not offer. Trim 8 and trim 2 exist in both charts and
substitute differently, which is the pair that proves the rule.

**A fifth invented property, caught.** The old chart carried a per-trim boolean
`requiresOversizeStem`, ticked on the austenitic trims. API 623 says no such
thing. Clause 5.8.1 states a **design obligation on the manufacturer** — the
minimum comes from Table 5, and *"the actual stem diameter shall take into
account the valve design details and the stem material strength
characteristics"*, with MSS SP-91 bounding the input force. A plausible
simplification of a real rule is the hardest kind of invention to spot.

**Materials inherited, and labelled as such.** API 623 Table 8 has the same 24
codes and the same column structure as API 600 Table 8, but the two have **not**
been compared cell by cell. So the codes, the obsolescence of trim 1 and the
Table 9 substitutions are `verified: true` from API 623, while every material
property stays `verified: false` with `materialsInheritedFrom` naming where it
came from. The validator caught the first attempt at this, which left a `source`
string on an unverified property — *"a citation nobody stands behind is worse
than none"*.

**The body-form test has now been wrong three times** — API 600, then API 602,
then API 623 — so it stopped chasing the last unverified guess and now asserts
the **pattern**: no verified standard restricts the body product form. If a
future purchased standard does, it fails loudly, and that would be worth
knowing. The code path is still covered against one of the four remaining
unchecked claims, with the finding required to admit it is unchecked.

`ManualValveTest` **74**, `MaterialLibraryTest` **108**. Wider run **555 passed
/ 9,933 assertions**.

#### 11.9.11 API 594: two types, two dimension sources (2026-09-25)

**The user supplied API Standard 594 (2022)** — check valves. NPS 2 to 48, and
three findings that each break an assumption the platform was carrying.

**1. THE FACE-TO-FACE SOURCE DEPENDS ON THE TYPE.** Clause 1 splits check valves
in two: a **Type A** valve takes its short face-to-face from **API 594 Tables 2
and 3**; a **Type B** valve takes it from **ASME B16.10**. The platform holds
B16.10 and *not* API 594 Tables 2/3 — so **a Type A check valve currently
resolves to a Type B length**. That is recorded as a known gap with the fix
named, not left to be discovered when a spool will not close.

Type A also admits **gray and ductile iron** bodies; Type B is B16.34 materials
only. Two variants of one standard with different material scopes as well as
different dimension sources.

**2. THE CLASSES COME FROM THREE FLANGE STANDARDS.** 150–2500 per **B16.34**,
**125 and 250 per ASME B16.1** (gray iron), and **150/300 per ASME B16.42**
(ductile iron). This is the first standard here to carry iron classes, and
`ValvePtRatings::tabulatesPressureClass('125')` is correctly false — a consumer
that resolves every class through B16.34 finds nothing for 125 or 250 and must
not invent it.

**3. THE CHECK-VALVE TRIM CHART WAS INVENTED OUTRIGHT.** The library held four
codes — `13CR`, `STL`, `316`, `MONEL` — that appear in no standard. **API 594
numbers its trims like every other API valve standard**: Table 4 gives **twelve**
(1, 2, 5, 5A, 8, 9, 10, 12, 13, 14, 16 and the bronze **AA**). And its parts are
**seating surface and hinge pin** — a check valve is opened by the flow, so it
has no stem and no backseat; the "disc" in the old four-part list was ours.

**A trim number belongs to its standard, not to the world.** A test asserted
that trim 8 was a gate trim and could not appear elsewhere — true only because
the check chart used made-up letter codes. API 594 has a trim 8 of its own, with
different materials. The API standards share one numbering family and the same
number means different things in different standards, exactly as the
substitution tables do.

**API 594 states no seat hardness at all** — the words *hardness*, *HB* and
*Brinell* appear nowhere in it, where API 600 and API 623 both give a column.
The validator rule demanding hardness on a hardfaced trim was written from the
API 600 shape; a spec may now declare the absence, and API 594 does. Borrowing a
figure from the gate chart would be an inspection criterion nobody wrote.

`ManualValveTest` **79**, `MaterialLibraryTest` **108**. Wider run **560 passed
/ 10,080 assertions**.

#### 11.9.12 API 599: not every standard numbers its trim (2026-09-25)

**The user supplied API Standard 599, ninth edition (October 2025)** — metal
plug valves. NPS ½ to 36, classes 150–2500 **including 800**, with threaded and
socket-welding ends stopping at **NPS 2** (the per-end-type scope shape API 608
introduced).

**API 599 PRINTS NO TRIM NUMBER TABLE.** API 600, 623 and 594 each print one.
API 599 does not: clause 6.2.1 gives the shell from **ASME B16.34 or a ductile
iron from B16.42**, and leaves seat, sleeve and plug facing to be agreed on the
purchase order. The two codes the library held for plug valves — `PTFE-SLV` and
`MTL` — were a vocabulary for a chart that does not exist.

So the API599 trim spec is **removed**, `trimStandardFor('PLUG')` returns null
alongside NEEDLE and DIAPHRAGM, and `ManualValves` no longer raises
`TRIM_ABSENT` on a plug valve row. **Demanding a trim number from a plug valve
asks for something the standard has not got** — the fourth invented vocabulary
this sequence has removed, and the first where the whole chart was fictitious.

**The third variant axis API 598 needed.** Note (f) of its Table 1 says *"for
lubricated plug valves, the high-pressure closure test is mandatory and the
low-pressure closure test is optional"* — prose, until now. Clause 1.2 names the
two: **LUBRICATED** and **NON_LUBRICATED**. With API 608 (ball designs) and API
609 (butterfly categories), every variant API 598 distinguishes now has its
vocabulary from a construction standard.

**Three-way and four-way plug valves are explicitly out of scope** (clause 1.2
NOTE), while **tandem** valves — two independently operating plugs in one body —
are in. Worth holding: `THREE_WAY_VALVE` is on the deferred list and this says
which standard will *not* cover it.

**Four design groups with different face-to-face dimensions** (clause 1.6):
short, regular, venturi, round port. The short pattern exists only in Class 150
and 300 and matches the B16.10 gate-valve face-to-face over NPS 1½–12 — which is
exactly what `valve-face-to-face` already holds, so the two agree.

**And a second overstatement caught.** The tempting story was "a fifth
product-form collapse". API 599's `bodyGroups` was **already null**, as API
609's had been, and the validator said so again. **Four entries genuinely
collapsed: API 600, 602, 603 and 623.** The rest never made the claim.

`ManualValveTest` **83**, `MaterialLibraryTest` **108**. Wider run **564 passed
/ 10,167 assertions**.

#### 11.9.13 API Spec 6D: the loop closes (2026-09-25)

**The user supplied API Specification 6D, 25th edition (2021).** The largest
document held, and the one that settles an anomaly declared four rounds ago.

**IT IS A SPECIFICATION, NOT A STANDARD.** API 600 covers a valve type; API 6D
covers design, manufacturing, materials, welding, quality control, assembly,
testing, marking, documentation and process controls in one document, for
**five** valve types. Naming it on a PMS row picks a quality regime — and,
because **Annex C is normative**, a dimension source too.

**THE B16.10 LOOP CLOSES.** B16.10 Table 1.3-1 note (14) said its Class 150
gate figures for the large sizes were *"extracted from API 6D"*. Read from the
other side, they are:

> **17 of 19 sizes match to the millimetre.** The two that do not are the same
> inch figure rounded differently — 7.50 in is 190.5 mm, and one standard
> rounds up while the other rounds down.

**And the declared anomaly is settled.** The B16.10 round recorded that Table
1.3-1 column 9 *shortens* from 762 mm at NPS 34 to 711 mm at NPS 36 and
attributed it to note (14). API 6D gives **813 mm at NPS 36** and **660 mm at
NPS 30** — and our B16.10 data holds *both* values at each of those sizes. The
larger figure in each pair is the API 6D one; the smaller is the
**through-conduit** valve that note (14) sends to a different number. **The
column was never non-monotonic — it was two valve constructions printed in one
place.**

**A valve type nothing else here knows.** The 25th edition added **AXIAL**
valves. No component-template qualifier, no actuator travel, no trim chart and
no face-to-face row outside Annex C knows the type. Declared via
`valveTypesBeyondTemplate` rather than quietly added: widening the VALVE
template changes the PMS body, the MTO and every dropdown that reads it, and
that is a decision to take deliberately — the same treatment NPS 60 got when
API 609 reached past `pipe-sizes`.

**Class 400, for the third time.** Clause 1 NOTE: *"ASME Class 400 has been
removed from this specification."* ASME B16.34 never tabulated it, API 602 omits
it, and API 6D has now deleted it outright. Three independent documents say a
Class 400 **valve** is not a thing — while a Class 400 **flange** remains
ordinary in B16.5.

Also the first document here to name **hydrogen gas** service.

`ManualValveTest` **86**, `ValveFaceToFaceTest` **17**. Wider run **569 passed /
10,191 assertions**.

#### 11.9.14 ISO 15761: a second pressure system, and the last collapse (2026-09-25)

**The user supplied ISO 15761:2020** — the ISO twin of API 602: compact steel
gate, globe and check valves, NPS ¼ to 4.

**THE FIFTH AND FINAL PRODUCT-FORM CLAIM COLLAPSES.** ISO 15761 was the last
*verified* entry still asserting one form — `FORGINGS`, on the reasoning that it
is the compact forged valve. Clause 5.4.4.2: *"Body end flanges and bonnet
flanges shall be **cast or forged** integral with the body."* **Five for five**:
API 600, 602, 603, 623 and now ISO 15761. Every single-product-form claim this
repo made has been wrong.

**A PRESSURE SYSTEM THE PLATFORM DOES NOT HAVE.** Clause 1 rates these valves in
**two parallel systems**: ASME Class 150–2500 *and* **PN 16, 25, 40, 63, 100,
250, 400**. Every pack here — `pipe-sizes`, `flange-pt-ratings`,
`valve-pt-ratings`, the PMS itself — keys pressure on an ASME class number, so a
European sheet writing **PN 40** has nowhere to go. Declared through
`pnDesignations` rather than dropped.

And the two systems do **not** map one to one. Clause 1, on the class this
platform verified two rounds ago: *"Class 800 is not a listed class
designation… **There is no equivalent PN designation**."*

**A SECOND TRIM VOCABULARY.** Clause 6.1: *"The trim combination number (**CN**)
identifies both the stem material and the associated seating surface
material."* This is the system **API 602 Table 12** uses and a different one
from the API 600 trim numbers the library holds — the CN set includes **11A, 12A
and 14A**, which no API 600 chart has. It is recorded and deliberately *not*
transcribed: Annex F ties each CN to a body and bolting combination, so the
chart and its associations have to be built together or the association is lost.

**And the two families contradict each other.** API 600 Table 8 note (b)
**prohibits** free-machining 13Cr outright. ISO 15761 clause 6.1.2 **permits**
it when the purchaser specifies it, identified by the trim number **plus 100** —
CN101, 104, 105, 105A, 106, 107, 108, 108A. Same material, same valve family,
two answers. Which is exactly why a PMS has to name the governing document.

`ManualValveTest` **89**. Wider run **572 passed / 10,202 assertions**.

**The valve construction set is now ten of thirteen verified** — API 594, 599,
600, 602, 603, 608, 609, 623, 6D and ISO 15761. The three that remain
(BS 1414, BS 1868, BS 1873) are still unchecked claims whose findings say so. Four of them still
assert a single body product form; on the evidence so far, all four are wrong.

Still missing: **IPS-M-PI-110** (what an Iranian client actually cites; free to
obtain), **B16.25** for weld-end preparation, **NACE MR0175** for sour service,
and **ASME B36.10M** to reach NPS 60. Readable and unbuilt: API 600 Tables
1/4/Annex D, API 603 Tables 1–3, API 608 Tables 3–4, API 609 Tables 2/3a–3c, and
**API 602 Table 12**, whose trim vocabulary is keyed by **CN** rather than by
trim number.

**CORRECTION, 2026-09-24 — «نیازی به ثبت special items در pms نیست».** The
user states that special items need not be recorded in the PMS. The paragraph
that stood here proposed a class body holding **two kinds of row** (standard,
and special keyed by SP number x size). That proposal was *our analysis of
sampled PMS documents*, not a user decision, and it was built (step 6, commit
`f7ef1fa`) before the distinction was checked. It has been reversed by
`2026_09_24_180000_specials_leave_the_pms_body.php`.

**A class body holds one kind of row: component type x qualifier x size.**

**The SP register stays.** What the user actually decided about SP numbers is
untouched by the correction, and none of it involves the PMS: an SP number is
**unique across the whole project**, and it is recorded **both on the MTO and on
the datasheet** — one number, two uses. Since a PMS is transcribed rather than
authored (below), SP numbers are validated, never allocated. `specialty_items`
therefore remains, standing on its own, waiting for the MTO and the datasheet to
consume it.

*Method note, worth more than the feature:* a design document mixes user
decisions with the author's reasoning, and only the former binds. Before
building from a section of this ADR, check which paragraphs are headed
**User decision** and treat the rest as argument.

Because MTO is imported, an SP number arrives from two directions and the two
must agree. That reconciliation already has machinery: an MTO row citing an
unknown SP number is a `BaselineDiscrepancy`.

Tagged versus untagged matters here. Six templates carry `isTagged`; SP items
split the same way. A pig trap or restriction orifice is tagged and acquires two
identities — `SP-014` (what it is) and `V-2301` (which one it is). Which
register owns which is **moot for now**: with specials out of the PMS, nothing
in the built system needs the tagged instance. `specialty_items.is_tagged`
records the distinction; the question returns when the MTO consumes SP numbers.

### 11.10 A PMS is transcribed, not authored — and that changes the writes

**User decision: in the target market the PMS is produced outside and
transcribed into the system.**

Two consequences.

First, the entry screen is a **transcription tool**. 400 rows for one class,
50 classes, is not a click-per-row interface. It must be bulk-oriented: one
specification applied to a selected set of sizes. `setRules()` — built during
the per-size correction — is already that shape.

Second, and sharper: **write-time refusals become wrong.** `setRule()` currently
refuses SCH 160 at 3.5" because ASME does not make it. For an authoring tool
that is right. For a transcription tool it is a wall — the transcriber may not
correct the client's document, and cannot record what it says.

**User decision, 2026-09-24: record it, then raise a discrepancy.** This is the
`verified: false` precedent applied to rules: the data is held, and is not
citable until reviewed. Every write-time refusal in `PipingClassRuleService`
must be re-read in that light.

### 11.11 What this unlocks

None of the following is possible today. All of it becomes a query once material
lives in the rules and the class code lives on the MTO:

- MTO says `A106 Gr.B` where the class at that size requires `A312 TP316`
- a line's design temperature falls outside the class's P-T curve
- a ball valve in a class that lists no ball valve row
- 1" pipe with BE ends in a class whose joint construction is SW below 1.5"
- a spiral wound gasket against an incompatible facing
- MTO bolting below the B16.5 floor

### 11.12 Build order

| # | work | depends on |
| --- | --- | --- |
| 1 | `b165MaterialGroup` on grades, `verified: false` | — |
| 2 | `flange-pt-ratings` pack, with a standard axis | — |
| 3 | PMS as a registered document + revision container | 3 follows ITP |
| 4 | header enrichment; drop `CORROSION_ALLOWANCE` rule kind | 2 |
| 5 | body on component x qualifier x size; wire the material library | 1 |
| 6 | SP register + the special row kind | 3 |
| 7 | NDT block feeding the ITP | 4 |
| 8 | transcription screen, bulk-oriented | 5, 6 |
| 9 | MTO: class code + SP number columns, and the checks in 11.11 | 5, 6 |

Steps 1 and 2 are reference data only and carry no migration risk.

### 11.13 AMENDMENT (2026-09-24, same day) — a rating is `(standard, class)`, and some classes are computed

**Trigger (user):** valve classes generally line up with the ASME B16.5 / B16.47
rating classes, *but some valve classes — Class 800 for instance — do not exist
in those standards at all.* What follows from that?

More than expected. §11.3 above has a hole in it, and the hole is a symptom.

#### Where Class 800 actually lives

Not in B16.5 and **not in B16.34 either**. It is an *intermediate* class defined
by **API 602 / ISO 15761** for small-bore forged (wrought) steel gate, globe and
check valves with socket-welding and threaded ends. It exists precisely because
those valves have **no flange**: a B16.5 class number exists to fix flange
dimensions, and a valve with no flange is free to carry a pure pressure
designation. 800 fills the gap between 600 and 1500 for small bore.

#### It has no table — it has a formula

Per ISO 15761 §4.1.2 and API 602 §4.1.3, the Class 800 curve is a linear
interpolation of the B16.34 tables:

```
P800(T) = 1/3 * P600(T)  +  2/3 * P900(T)
```

Checked against carbon steel at 38 degC: `1/3(1480) + 2/3(2220) = 1973 psi`,
and a manufacturer's catalogue states **1975 psi at 100 degF** for a Class 800
A105 forged valve. The formula is right; the difference is rounding. All of
these numbers enter `verified: false` like every other figure in this repo.

**Design consequence.** `flange-pt-ratings.ref.json` must carry *derived* classes
alongside tabulated ones, rather than a fabricated 800 row:

```json
{ "class": "800", "definedBy": "API_602",
  "derivedFrom": [["600", 0.3333], ["900", 0.6667]],
  "verified": false }
```

This is better than data: any future intermediate class is expressible without a
new table, and the derivation is auditable.

#### The real finding: "rating" is not one enumeration, it is at least six

| standard | classes | what they rate |
| --- | --- | --- |
| B16.5 | 150, 300, 400, 600, 900, 1500, 2500 | flanges, NPS 1/2–24 |
| B16.47 A/B | 75, 150, 300, 400, 600, 900 | flanges, NPS 26–60 |
| B16.34 | 150, 300, 600, 900, 1500, 2500, 4500 | valves |
| API 602 / ISO 15761 | **800** | small-bore forged valves |
| **B16.11** | **2000, 3000, 6000, 9000** | **forged SW / threaded fittings** |
| B16.1 | 125, 250 | grey cast iron |

`piping_lines.pressure_rating` is a single `string(16)` holding all of them.

`3000` in B16.11 and `300` in B16.5 share neither scale nor meaning. **This is
the standing lesson already recorded in this repo — "codes are unique only
within their standard", learned on the API 600 scope question — recurring one
level up.** A rating is a pair, `(standard, class)`, and must be stored as one.

#### A valve's class relates to the piping class by `>=`, not `=`

A 600# piping class routinely specifies Class 800 socket-weld valves in small
bore. The valve is *stronger* than the class requires, and that is correct, not
a deviation.

So: the class rating governs the flanges and the P-T envelope; each valve row
carries its own class; and the check is **sufficiency** —

```
valve MAWP at design temperature  >=  class MAWP at design temperature
```

**Never compare class numbers.** `800 > 600` happens to be true; `3000 > 300` is
meaningless because the two live on unrelated scales. Comparison is on pressure
at temperature, always. This is the same shape as the bolting sufficiency check
the user specified — one pattern, two uses.

#### `requiresRating` is on the wrong axis

`component-templates.ref.json` today:

```
ELBOW  rating=-     TEE   rating=-     COUPLING rating=-   OLET rating=-
FLANGE rating=True  VALVE rating=True
```

But a **socket-weld** elbow is class-rated (3000/6000/9000 per B16.11), while a
**butt-weld** elbow is not — it inherits the schedule of the pipe it joins. Same
template, opposite answers.

So `requiresRating` is not a property of the component type. It is a property of
**component type x end type**. This directly breaks `isScheduled()`
(`category in {PIPE, FITTING} and requiresRating !== true`), which will ask a
socket-weld elbow for a schedule when it should be asking for a class.

#### A validator that falls out for free

> **CORRECTED by §11.16 (same day). Two errors below: the table is quoted from
> its socket-welding column only (threaded correlates differently), and it is a
> *rating basis*, not a fit-up rule — B16.11 explicitly permits thinner or
> thicker wall. The check is sufficiency, not equality. Read §11.16.**

B16.11 ties the class to the **socket bore**, not to strength:

| fitting class | bored for |
| --- | --- |
| 3000 | Sch 80 |
| 6000 | Sch 160 |
| 9000 | XXS |

A Class 3000 fitting on Sch 160 pipe will not seat, and loads the weld root. We
hold the fitting class and the pipe schedule for the same size in the same
class, so the check costs nothing. Add it to §11.11.

#### What this changes in the build order (§11.12)

- **Step 2** gains derived classes, and the pack's key becomes
  `(standard, class, material group, temperature)`.
- **New step, before 5:** move rating off a bare string onto `(standard, class)`,
  and move `requiresRating` onto component type x end type.
- **Step 9** gains two checks: valve-class sufficiency by pressure at
  temperature, and B16.11 fitting rating basis against actual pipe schedule
  (see §11.16 — sufficiency, not equality).

#### Note to self

The evidence was already quoted in §11.1's own source material — the real PMS row
reads `A105 forged 3000 lb SW B16.11` against `A234 WPB LR BW B16.9`. The `3000`
was read as part of a description string rather than as a *different rating
scale*. A number in a transcribed description is not decoration; ask which
standard issued it.

### 11.14 B16.47 — the materials are held, the dimensions are not (2026-09-24)

**Trigger (user):** are the specifications of B16.47 flanges recorded in the
material reference library?

Two different questions hide in that one, and they have opposite answers.

#### The material library correctly holds none of it

`materials.ref.json` states the exclusion at the top of the file:

> `pressureRating`: **NOT held here.** A flange rating is a property of the
> COMPONENT under ASME B16.5/B16.47, not of the material, and
> `piping_classes.pressure_rating` already carries it. **A105 is A105 whether
> the flange is 150# or 1500#.**

That is right, and B16.47 changes nothing about it: B16.47 is a **dimensional**
standard, not a material specification. A 30" Series A weld-neck flange is made
from the same forging specs as a 6" B16.5 one.

#### And the materials for those flanges are present

`FORGINGS` (`componentTypes` includes `FLANGE`, `BLIND`, `SPECTACLE_BLIND`):

```
A105   0 grades     A350  11 grades     A182  22 grades
A694   9 grades     A707   7 grades
```

**A694 (F42–F70) is specifically the large-diameter pipeline flange and fitting
spec**, and A707 covers low-temperature forged flanges. Nothing is missing on
the material side.

#### The gap is dimensional, and it starts exactly at NPS 26

`flange-bolting.ref.json` declares its own limit:

```
source: "ASME B16.5 ... Classes 150, 300, 600, 900, 1500"
  5 ratings x ~20 rows, every one of them  1/2 .. 24
```

It stops precisely where B16.47 begins, while `pipe-sizes.ref.json` runs to
NPS 48. So for NPS 26–48 we hold size, schedule and material, and hold **no
bolting data and no P-T basis**.

`FlangeBolting::forJoint()` returns `?array` and `return null` (line 146) above
24". Harmless today — the class is registered in `EpccServiceProvider` and has
**no business-logic consumer yet** — but the moment the bolting sufficiency
check the user asked for is wired, it will have **no floor to compare against
above 24" and will pass silently.** That is the worst failure mode available:
a check that reports success because it has no data.

The standards catalogue holds only a citation row —
`ASME · B16.47 · Large Diameter Steel Flanges NPS 26 through NPS 60 · 2020` —
so we can cite the standard and hold nothing from it.

#### Series A and Series B are not interchangeable

B16.47 has two series with different ancestry: **Series A** from MSS SP-44
(heavier, fewer and larger bolts) and **Series B** from API 605 (more, smaller
bolts on a tighter bolt circle). At the same NPS and the same class, outside
diameter, thickness, bolt count and bolt circle all differ. Series B also
carries a Class 75 that Series A does not.

Therefore **series is a project-level choice** and belongs in the class header or
the piping configuration, and the pack needs a `series` axis. Building it
without one repeats the §11.3 warning — B16.5 versus B16.47 — one level finer.

Whether the B16.47 P-T tables track the B16.5 material-group numbers unchanged
is **not asserted here**. Both series' dimensions and ratings enter
`verified: false` and are not citable until checked against a purchased copy.

**Open question put to the user and not yet answered:** which series the target
projects typically use. It affects only priority, not design.

#### Added to the build order (§11.12)

> **Extend `flange-bolting` to B16.47 with a `series` (A/B) axis, covering
> NPS 26–48 so the pack is flush with `pipe-sizes`.** Until then, any
> sufficiency check must treat "no data" as *unknown*, never as *pass*.

### 11.15 Both B16.47 series are in use — which simplifies one pack and doubles another (2026-09-24)

**Answer to the question left open in §11.14 (user):** projects use **both**
Series A and Series B.

That invalidates the assumption in §11.14 that series is a project-level choice.
It cannot live in `project_piping_config`; it has to be resolvable at each
flange.

#### Its home already exists

§11.4 gives a body row the payload

```
{spec:A105, form:FORGED, dimStandard:B16.5, rating:150, end:BW, facing:RF}
```

so at NPS 26 and above it simply becomes `dimStandard: "B16.47", series: "A"`.
**No new structure.** A class header may carry a *default* series to speed
transcription, but the row is authoritative.

#### The P-T pack does NOT need a series axis

Checked, because the opposite was being assumed:

> The dimensional series, A and B, **have the same pressure-temperature
> ratings.** But unless they use special bolts they will not fit up together.

B16.47 materials align with B16.5 (nickel alloys excepted), so the same tables
generally apply. This splits the two packs cleanly:

| pack | key |
| --- | --- |
| `flange-pt-ratings` | (standard, class, material group, temperature) — **no series** |
| `flange-bolting` | (standard, **series**, class, nps) — **series required** |

**But editions drift.** The same source warns that for one material and class the
rating *can* differ between B16.5 and B16.47 depending on edition — "typically by
5 psi or so". So the pack must carry the **edition year**, not only the standard.
The standards catalogue already holds `ASME · B16.47 · … · 2020`, so the link
exists.

#### Four checks that come almost free

1. **Series A does not bolt to Series B.** At the same NPS and class the outside
   diameter, bolt count and bolt circle all differ; mating them is not possible
   without special bolts. This is a **joint-level** check and belongs on the
   existing `PortCompatibility` seam, which today only warns about facing. The
   predictable source of the clash is a vendor equipment nozzle in one series
   against a piping class in the other.
2. **Above NPS 24 the maximum class is 900.** B16.5 reaches 2500; B16.47 does
   not. A 1500# class therefore cannot carry a 30" flange — nothing stops that
   today.
3. **Class 75 exists only in Series B.**
4. **RTJ is Series A only**, and within Series A only for Classes 300–900 (one
   source further restricts the defined RTJ dimensions to NPS 26–36). This lands
   directly on `permittedFacings`, which we hold and do not validate.

#### One restriction deliberately not asserted

Sources indicate B16.47 covers only **weld neck and blind** flanges — not SO, SW,
threaded or lap joint — which would make four of the `FLANGE` template's six
qualifiers invalid above NPS 24. One source's table was self-contradictory at
exactly this cell (showing Series A as blind-only and Series B as weld-neck-only,
which agrees with nothing else). **Not claimed here.** It enters
`verified: false` with the rest and is settled against a purchased copy.

#### Net effect on the build order

- `flange-pt-ratings` gets **simpler** — no series axis — but gains an edition year.
- `flange-bolting` **doubles** — both series in full, NPS 26–48.
- Four new checks join §11.11, the flange-series mismatch being the one that
  stops a joint from being assembled at all.

### 11.16 CORRECTION to §11.13 — B16.11 Table 8 is a rating basis, not a fit-up rule (2026-09-24)

**Trigger (user):** B16.11 contains a table giving the thickness equivalent of
each class, and that probably bears on system validation.

It does. Reading the actual table showed **two errors in §11.13**, one of
omission and one of kind.

#### The table

ASME B16.11 **Table 8** in the 2016 edition (**Table 7** in earlier ones),
*Correlation of Fittings Class with Pipe Schedule No. or Wall Designation of
Pipe*:

| Class | Type of fitting | Schedule No. | Wall designation |
| --- | --- | --- | --- |
| 2000 | **Threaded** | 80 | XS |
| 3000 | **Threaded** | 160 | … |
| 6000 | **Threaded** | … | XXS |
| 3000 | **Socket-welding** | 80 | XS |
| 6000 | **Socket-welding** | 160 | … |
| 9000 | **Socket-welding** | … | XXS |

#### Error 1 — §11.13 quoted one column as if it were the table

§11.13 states `3000 -> Sch 80, 6000 -> Sch 160, 9000 -> XXS`. That is the
**socket-welding column only**. For a *threaded* fitting, Class 3000 correlates
to **Sch 160**, not Sch 80.

So one class number means two different wall thicknesses depending on end type.
This is the standard's own proof of the §11.13 claim that the axis is
**component type x end type**, not component type — arrived at there by
argument, and confirmed here by the table.

#### Error 2 — it is a rating basis, and §11.13 read it as a fit-up restriction

§11.13 says a Class 3000 fitting on Sch 160 pipe "will not seat, and loads the
weld root". **The standard says the opposite.** Directly beneath Table 8:

> **NOTE (1): This Table is not intended to restrict the use of pipe of thinner
> or thicker wall with fittings.**

and §2.1.1 is headed **Basis of Rating** — "the schedule of pipe corresponding to
each Class designation of fitting **for rating purposes**".

The physical reasoning agrees: **pipe OD is constant across schedules at a given
NPS**, and a socket bore is machined to accept the OD. A Class 3000 socket
fitting therefore accepts Sch 40 and Sch 160 pipe alike. The web source behind
the §11.13 sentence had confused bore with wall.

#### So the validator is sufficiency, not equality

```
Class 3000 socket-welding fitting  ->  rating basis = Sch 80
actual pipe                        ->  Sch 160
=> the fitting is weaker than the pipe; the line's allowable pressure is
   governed by the fitting, not by the pipe wall
```

The check is therefore *"is the fitting's rating basis at least the pipe's actual
schedule"*, and a shortfall is a **finding about which component governs**, not a
refusal.

**This is the third instance of one pattern**, and that is now worth naming:

| case | check |
| --- | --- |
| bolting | MTO quantity/length/diameter >= the B16.5 floor |
| Class 800 valve | valve MAWP at design temperature >= class MAWP |
| **B16.11 fitting** | **fitting rating basis >= actual pipe schedule** |

All three are sufficiency. None is equality. Whatever implements the first
should be shaped so the other two are instances of it rather than three separate
services.

#### Two further checks the table gives away

**The (class, end type) pair is itself constrained.** Threaded exists only as
2000/3000/6000; socket-welding only as 3000/6000/9000. So **"Class 9000
threaded" is not a thing** — one trade source calls a 9000LB NPT request a red
flag for exactly this reason — and neither is Class 2000 socket-welding. A
transcribed row carrying an impossible pair should be flagged at entry.

**`2M`, `3M`, `6M`, `9M` are permitted alternative class designations**, with M
standing for 1000. Since the PMS is **transcribed**, a source sheet may well use
them. The parser must accept both spellings or the transcriber is blocked by a
legal marking.

#### Edition sensitivity, again

The table moved from Table 7 to Table 8 between editions. This is the second
place today where an edition number changes an answer (the first being the few-psi
drift between B16.5 and B16.47 in §11.15). **Reference packs carry an edition
year, and citations resolve against it.**

### 11.17 Wellhead scope — API 6A, and the piping type as a standards profile (2026-09-24)

**Trigger (user):** projects with a wellhead facility use API standards such as 6A
and 6D, which differ wholesale from ASME in material, in pressure and
temperature rating, and in dimensions.

This is the largest scope change in this ADR, and the user's own proposal —
*make the piping type filterable, and give it a type* — turns out to be the thing
that makes it tractable.

#### First: 6A and 6D are not the same problem

**API 6D fits the model we already have.** It **references the ASME B16.34 rating
tables rather than duplicating them**, uses ASME classes 150–2500, and covers
flanged and butt-weld gate, ball, plug and check valves. The `(standard, class)`
pair from §11.13 already carries it.

One trap: **API 6D-2008 raised Class 600 at 100 degF from 1440 to 1480 psig.**
So 6D is *not* identical to B16.34. That is the **third** place in one day where
an edition changes an answer, after the B16.5/B16.47 few-psi drift (§11.15) and
the B16.11 Table 7→8 move (§11.16). The point is no longer a detail: **packs
carry an edition year and citations resolve against it.**

**API 6A is a different regime in every axis:**

| axis | ASME | API 6A |
| --- | --- | --- |
| pressure | dimensionless class (150…2500) | **actual psi**: 2K/3K/5K/10K/15K/20K |
| behaviour with temperature | **derates continuously** | **flat** across the temperature class |
| temperature | a number | **a class letter** (K, L, N, P, R, S, T, U, V) |
| material | ASTM spec (A105) | **material class** AA…HH |
| size | NPS | **bore diameter** — 2-1/16", 4-1/16", 13-5/8" — *but see §11.18: the PIPE stays NPS* |
| flange | B16.5 / B16.47 | **6B / 6BX** |
| gasket | B16.20 R/RX | **BX** — *WRONG, see §11.18: B16.20 covers BX and we already hold it* |
| quality | — | **PSL 1/2/3/3G/4** and **PR1/PR2** |

A 6A item's whole identity is one structured marking:

```
A114-API 6A-3 1/16 in-10,000 psi-S-FF-1,5-3-PR2-6-05
                  |        |     |  |   |  |  |
               size      RWP  temp mat H2S PSL PR
```

#### The user's decisions

- **The Christmas tree itself is tagged equipment with a datasheet; its piping
  and its manual accessories are piping members** — inside PMS scope. Consistent
  with §11.9: manual valves are PMS rows, actuated ones are datasheets.
- **The boundary is the tree's outlet flange.**
- **API 6A continues downstream of that flange** to a transition point —
  **but this varies between projects.**
- **Sour service (NACE MR0175 / ISO 15156) is in scope now**, lifting an earlier
  deferral.
- **Piping type becomes a first-class, filterable concept.**

#### Piping type is a standards profile, not a label

Treated as a label it solves nothing. Treated as a **profile that selects which
reference packs and which rules apply**, it resolves the whole 6A/ASME conflict
at one point instead of in every table:

| what the type binds | process piping | wellhead piping |
| --- | --- | --- |
| size system | NPS (36-size pack) | NPS for pipe + **bore designation** for connections (§11.18) |
| rating axis | dimensionless ASME class | **RWP in psi** |
| temperature behaviour | continuous derating from tables | **flat within the temperature class** |
| material reach | `CASCADE` (spec → grade) | **performance class** (AA…HH) |
| flange standard | B16.5 / B16.47 | **6B / 6BX** |
| gasket family | B16.20 R/RX | B16.20 **BX** — already held (§11.18) |
| quality axis | — | **PSL / PR** |

**The type list is project-configurable** (process, utility, wellhead, flare,
drain …) and each type carries a profile. Only "wellhead" pulls in API 6A, so a
project without a wellhead never meets the complexity.

This is the same shape as the platform's **founding requirement that the
standards framework (ISO vs AWP) be selectable rather than hardcoded** — one
axis further down.

**Crucially, the transition point is data, not a rule.** Because it varies by
project, the system must not know "after the choke". The project **declares** it
by assigning a class or line to a type. What the system *does* owe is detection:
**any joint whose two sides carry different piping types is an interface and must
be validated explicitly**, never silently joined.

#### The boundary already has a home

`component-templates.ref.json` carries `NOZZLE` with **`isTagged: true` and
`requiresRating: true`**. The tree's outlet flange is exactly that — a nozzle on a
tagged equipment item — and the piping begins there. If the vendor supplies a
6BX 10K outlet with a BX ring, the piping class must present the same.

That makes a **third job** for the `PortCompatibility` seam:

| # | check | from |
| --- | --- | --- |
| 1 | facing | exists, warns only (`PortCompatibility.php:112`) |
| 2 | B16.47 Series A vs B | §11.15 |
| 3 | **API 6A flange/ring across an equipment or type boundary** | here |

A third recurrence. Like the three sufficiency checks in §11.16, this is an
abstraction asking to be built once.

#### What this breaks

> **CORRECTED by §11.18. The paragraph below is overstated: 6B weld necks carry
> RESTRICTED bores matched to real NPS pipe and schedules, so wellhead PIPE rows
> use the existing 36-size pack unchanged. What is needed is a
> `(6A size, rating) -> (NPS, schedule)` mapping table, not a second size
> universe. The mapping stops at 6BX, which is always full bore.**

**A second size system — the deepest impact.** `piping_class_rules` is keyed on
`dn integer` + `nps varchar`, and the user's standing constraint is that sizes are
worked in NPS. **`2-1/16"` is not an NPS**; it is a bore. Nothing in the 36-size
pack can express it, and the per-size model of §10 has no key for wellhead rows.

**A fifth `reachedBy`.** The library has CASCADE / CONSTITUENT / TRIM /
REQUISITION_ONLY. API 6A states a **requirement**, not a selection: "material
class DD" fixes body and trim *categories* and leaves the specification to the
manufacturer. The classes, as far as three agreeing sources show:

| class | body | pressure-controlling parts (trim) | sour |
| --- | --- | --- | --- |
| AA | carbon / low-alloy | carbon / low-alloy | no |
| BB | carbon / low-alloy | **stainless** | no |
| CC | stainless | stainless | no |
| DD | carbon / low-alloy | carbon / low-alloy | **yes** |
| EE | carbon / low-alloy | stainless | **yes** |
| FF | stainless | stainless | **yes** |
| HH | CRA | CRA | **yes** |

Note it already embeds the body/trim split we built `VALVE_TRIM` for.

**Temperature is a combinable class letter.** `P+U` (−20 to 250 degF) is a common
6A gate valve rating, so the field is not a single-valued enum.

**Rating philosophy differs.** A comparison function cannot just read numbers; it
must know whether the rating derates with temperature or is flat.

#### What comes free

**PSL feeds the ITP**, exactly as the NDT block does in §11.8. And the
`(material class x RWP) -> minimum PSL` table is a complete validator:

```
AA/BB/CC:  <=5K -> PSL1  ·  10K,15K -> PSL2  ·  20K -> PSL3
DD/EE/FF:  <=5K -> PSL1  ·  10K -> PSL2  ·  15K,20K -> PSL3
HH/ZZ:     PSL3 throughout  ·  20K -> PSL4
```

#### Sour service, and a trap worth stating plainly

**"NACE compliant" is not a property of a material.** A grade is not absolutely
acceptable; it is acceptable **within an environmental envelope** — H2S partial
pressure, temperature, chloride, pH — and under hardness restrictions (carbon
steel at 22 HRC, for instance). A boolean `naceCompliant: true` on a grade would
record a falsehood.

What belongs on the grade is the **hardness limit and the applicability
envelope**; compliance is **computed at assessment time** against the service.
This is the same discipline as `verified: false`: hold the input, do not
pre-compute the conclusion.

And sour service is **cross-cutting, not wellhead-only** — ASME piping in sour
service is equally subject to MR0175. It must not be buried inside the wellhead
profile.

#### Source reliability — worse here than anywhere else in this ADR

Public sources **contradict each other** on API 6A:

- temperature class lists: `K,L,N,P,S,T,U,V` (a direct transcription of Table 2),
  versus `K,L,P,R,S,T`, versus lists including X and Y
- class S range: one source −18 to 60 degC, another −18 to 149 degC
- material classes: one source names only four; another maps DD to austenitic
  stainless, contradicting three others
- whether 6B spans 2K–5K with 6BX taking 10K–20K, or 6BX spans the whole range

The tables above follow the sources that transcribe the standard's own Tables 2
and 3 and agree with each other. **None of it is citable.** Everything enters
`verified: false` and waits for a purchased copy.

#### Build order impact

A new step, and it is not small:

> **Piping type as a standards profile** — a project-configurable type list, each
> binding a size system, rating axis, temperature model, material reach mode,
> flange and gasket standard, and quality axis. Then a **bore-diameter size
> pack**, a **performance-class material mode**, and the API 6A rating, PSL and
> temperature-class packs behind the wellhead profile.

The profile must come **before** the wellhead data, or the data has nowhere to
live. And it should be built so that an ordinary project never encounters it.

### 11.18 CORRECTION to §11.17 — the pipe is NPS; only the connection is a bore (2026-09-24)

**Trigger (user):** API 6A pipe sizes can be compatible with ASME/ASTM pipe
sizes, and so can the flanges.

Correct, and §11.17 overstated the problem in three places. The wellhead work is
**substantially smaller** than that section claims.

#### Correction 1 — `pipe-sizes.ref.json` is not broken for wellhead scope

§11.17 says *"size is a bore diameter, not NPS"* and calls a second size system
"the deepest impact". That is true of the **equipment connection**, and false of
the **pipe**.

API 6A **Type 6B weld-neck flanges do not have full bores — they have restricted
bores machined to match standard ANSI/ASME pipe sizes and schedules.** The worked
example: a **4-1/16" 5,000 psi 6B** flange has a maximum bore of **3.47"**,
approximating the ID of **4" Schedule 160 line pipe** at 4.5" OD. Manufacturers
list stock as *"weld neck flanges 2-1/16" to 7-1/16", **neck sizes 2" to 6"**,
schedules SCH 80, SCH 160 and XXH"*.

And the underlying reason, which is the user's point exactly:

> **API and ASTM/ANSI pipe sizes share common ODs in many sizes. ANSI and API
> standards share a common ancestry.**

So the two designations describe different things rather than competing:

| | basis |
| --- | --- |
| ASME/ASTM **NPS** | a *nominal* label, not a measurement |
| API 6A **size** | the actual **through-bore** |

**A wellhead line's pipe rows therefore use the existing 36-size NPS pack,
unchanged.** Only the *flange and equipment connection* carries a 6A bore
designation — and for 6B it maps to a real (NPS, schedule) pair.

What we need is not a parallel size universe but **one mapping pack**:
`(6A size, rating) -> (NPS, schedule)`. That is a table, not an architecture.

#### Correction 2 — 6B and 6BX behave differently, and the mapping stops at 6BX

- **6B weld neck**: restricted bore matched to NPS pipe; 45K yield material.
- **6BX weld neck**: **always full bore**; 60K yield at 10,000 psi and 75K at
  15,000 psi and above. Their necks **"do not usually match any pipe schedules"**,
  and specifying pipe-matching necks on 6BX 10K/15K is described as done
  **"at high risk"**.

So the NPS mapping holds for 2K–5K and **deliberately stops** at 10K. The pack
must say *no mapping* there rather than invent one.

Also a scope limit worth holding: **API 6A does not specify weld-neck flanges
above 11"**; charts circulating above that size are explicitly unofficial.

#### Correction 3 — the gasket family is not new; we already hold it

§11.17 lists the wellhead gasket family as **BX** against B16.20 R/RX, implying
something outside our library. Checked the pack:

```
B16.20-RJ  (ASME B16.20 ring joint)
  RJ-R-SOFT · RJ-R-304 · RJ-R-316 · RJ-RX-316 · RJ-BX-316
```

**B16.20 covers R, RX and BX, and all three are already in the gasket group.**
That line of §11.17 was wrong. Nothing to add.

#### A new rule, and it is a fourth sufficiency check

> **"API 5L / ASTM carbon steel line pipe is lower yield than API 6A flanges,
> therefore a heavier wall is required."**

The flange is 45K, 60K or 75K; A106/API 5L pipe is not. Matching the bore is not
enough — **the pipe wall must compensate for the yield difference** so the
assembly still reaches the flange's rated working pressure. Note too that 6BX
flanges are typically 4130/4140 low-alloy or 410 SS, so **a compatible higher
grade of pipe is required**, not merely a thicker one.

That is the **fourth** instance of the pattern named in §11.16:

| case | check |
| --- | --- |
| bolting | MTO quantity/length/diameter >= B16.5 floor |
| Class 800 valve | valve MAWP at design temp >= class MAWP |
| B16.11 fitting | fitting rating basis >= actual pipe schedule |
| **6A weld neck** | **pipe wall + grade sufficient for the flange's RWP given the yield gap** |

#### Flange interchangeability — the sources disagree, so the system must not decide

- one: API and ASME flanges are **"not interchangeable"**, and where bolt circle
  and hole count appear identical the similarity is **"misleading and dangerous"**
- another: *"some API flanges can easily be joined with ASME flanges even though
  the flange rating is different"*
- a third, on 6B 5,000 psi: a **"dimensional heritage shared with ASME B16.5
  Class 1500 ring-joint flanges"**, and *"in overlapping sizes the flanges
  generally mate, but … **confirm dimensions ring-for-ring and hole-for-hole
  before mixing systems on a joint**"*

Three reputable-sounding sources, three different answers. **The system must
therefore neither pass nor refuse a cross-standard flanged joint silently.** It
must **flag it as an interface requiring explicit engineering approval, and
record the decision** — the same treatment §11.10 gives a transcribed value that
fails a rule, and the same treatment §11.17 requires where two piping types meet.

#### Net effect on the build order

The wellhead profile gets **materially cheaper**:

- ~~bore-diameter size pack~~ → **a `(6A size, rating) -> (NPS, schedule)` mapping
  pack for 6B, explicitly empty for 6BX.** Pipe rows keep the existing NPS pack.
- ~~BX gasket family~~ → **already present** in `B16.20-RJ`.
- still required: the **performance-class material mode** (AA…HH), the **RWP /
  temperature-class / PSL packs**, and the **piping type profile** itself.

§11.17's alarm about a second size system was overstated. The profile, the
material mode and the quality axis remain real; the size universe does not.

### 11.19 API 5L was already held — and one cross-reference had rotted (2026-09-24)

**Trigger (user):** is there anything in the system for API 5L? Then, on being
shown the answer: **PSL exists in 6A too, and there it runs 1 to 4.**

Unlike §11.14, the audit found the data present and in good shape. It found a
**real, shipped defect** next to it, and the user's follow-up exposed a **naming
collision that was one step from becoming a bug**.

#### What was already there

`API5L` sits in the `PIPE` group, `reachedBy: CASCADE`, product forms
`SMLS / ERW / DSAW`, with minimum yield and tensile on every grade, all
`verified: false`. The **PSL axis was modelled correctly** as `classOrType`, the
same slot every other spec uses for its class or type. The standards catalogue
carries `API · 5L · Line Pipe · 2018 · MATERIAL`, and `ItpTemplateSeeder`
already cites 5L for pipeline incoming material.

Better than expected: a **cross-reference already existed**. Fifteen flange and
fitting grades carry `matchingLinePipeGrade`, pairing A694 F42–F70 and A860
WPHY-42–70 with the line pipe grade they are meant to be welded to — *"F60
flanges go on X60 pipe"*.

#### The defect: five of those fifteen pointed at nothing

| dangling reference | held by |
| --- | --- |
| `API 5L X46` | A694 F46, A860 WPHY-46 |
| `API 5L X48` | A694 F48 |
| `API 5L X50` | A694 F50 |
| `API 5L X56` | A694 F56 |

The pack contained only B, X42, X52, X60, X65 and X70. **X46, X48, X50 and X56
were named but absent**, and `validate_packs.py` — 28 material rules — had no
rule that a cross-reference must resolve.

This is the **same shape** as the §11.14 finding, where `flange-bolting` stopped
silently at NPS 24. The lesson recorded there applies again, one level up:
*missing reference data must read as unknown, never as pass* — and here it read
as neither, because nothing looked.

**Fixed.** Rule 29 was written **first and made to fail** on the shipped pack (all
five, exit 1) before any data was added; then X46, X48, X50, X56 and **X80** were
added, and the rule went green. Pack `1.9.0 -> 1.10.0`, 355 -> 360 grades.
`MaterialLibraryTest` 103 passed / 6863 assertions.

#### PSL is a pair — the user's catch, and a third instance of one trap

**API 5L has PSL 1 and 2. API 6A has PSL 1, 2, 3, 3G and 4.** Same acronym, same
general idea — a product specification level — but **different standards,
different scales, and no meaning in common**:

| | scale | what it governs |
| --- | --- | --- |
| **API 5L** | PSL1, PSL2 | line pipe chemistry, CVN impact testing, carbon equivalent |
| **API 6A** | PSL1, PSL2, PSL3, PSL3G, PSL4 | extent of QA, inspection and testing on wellhead equipment |

A 5L PSL2 is **not** a 6A PSL2. It is not a lower grade of one, either — they are
different axes.

This is the **third** appearance of the trap named in §11.13:

1. `Class 300` (B16.5) versus `Class 3000` (B16.11) — same word, different scale
2. a rating is therefore `(standard, class)`, never a bare string
3. **a PSL is `(standard, level)`, never a bare string**

And the near-miss is worth stating: §11.17 had *already* written the 6A
`(material class x RWP) -> minimum PSL` table into this ADR, while the pack
*already* stored 5L's PSL as the bare string `"PSL2"`. Both were correct alone.
Nothing anywhere said they were different things. The first code to read a "PSL"
from one and compare it with the other would have been wrong and would have
looked right.

The `_note` on the 5L spec now says so explicitly, and the remedy is the §11.13
remedy unchanged: **carry the standard with the level.**

#### The fourth sufficiency check is already computable on the pipe side

§11.18 established that a 6A flange out-yields line pipe, so the pipe wall and
grade must compensate. The pack now holds the whole pipe side of that sum:

| grade | min yield | | 6A flange | min yield | lowest 5L grade that clears it |
| --- | --- | --- | --- | --- | --- |
| B | 245 MPa (36 ksi) | | **6B** (45K) | 310 MPa | X42 (290) **falls short**; X52 clears |
| X42 | 290 (42) | | **6BX 10K** (60K) | 414 MPa | X60 (415) clears **by 1 MPa** |
| X52 | 360 (52) | | **6BX 15K/20K** (75K) | 517 MPa | **X80 (555) — X70 does not clear** |
| X60 | 415 (60) | | | | |
| X65 | 450 (65) | | | | |
| X70 | 485 (70) | | | | |
| X80 | 555 (80) | | | | |

That last row explains the §11.18 source's remark that 6BX flanges are typically
**4130/4140 low-alloy or 410 SS**: at 75K yield, ordinary line pipe does not
reach the flange. Only the 6A side of the comparison is still missing.

Note also that `matchingLinePipeGrade` is the **precedent** for this check — it
already expresses "this flange grade belongs with that pipe grade" as a named
pair. The 6A version is the same relation computed from yields instead of
enumerated.

#### Still open

- **PSL1 versus PSL2 has no semantics.** The letters are stored; what distinguishes
  them — mandatory CVN impact testing, carbon-equivalent limits, tighter chemistry
  on PSL2 — is not. Until it is, the system cannot validate the ordinary project
  rule that **sour service requires PSL2**.
- **No sour-service variant** (API 5L Annex H). Sour service entered scope in
  §11.17, and line pipe is exactly where it bites. This is now a live gap, not a
  deferral.
- Both need real numbers from a purchased copy, and both stay `verified: false`
  until they have them.

### 11.20 A piping MTO is often issued as several sub-MTOs — RECORDED, DEFERRED (2026-09-24)

**User:** in some projects the piping MTO is issued as several sub-MTOs — pipe
MTO, fittings MTO, flanges MTO, valves MTO, paints MTO, and so on. **Recorded
now so it is not lost; completing the MTO is deferred by the user.**

#### Why the split exists

The industry item ordering found in §11.9 —
`Pipe -> Fittings -> Flange -> Gasket -> Fasteners -> Spacer & Blanks -> Valve ->
Specialty` — **is the cut line.** Each commodity goes to a different vendor under
a different purchase order: pipe from a mill, fittings from a forge, valves from a
valve maker, paint from a coating supplier. **The sub-MTO boundary is a
procurement package boundary.**

`ProcurementService` and `PurchaseOrder` today have **no package or commodity
concept at all**, so the two ends of that chain do not meet.

#### The live defect this creates

`BaselineService::reconcile()` takes the **union** of item keys from the two
batches:

```php
$keys = array_unique([...array_keys($left), ...array_keys($right)]);
```

`baseline_batches` has **no scope column** — only `source_kind` (`XLSX_MTO`), a
filename and a revision label. A batch cannot say *"I claim to cover fittings
only."*

So reconciling a **fittings-only sub-MTO** against a full model batch raises
**`MISSING_IN_MTO` for every pipe, flange, valve and gasket in the model** —
thousands of false findings, with the real ones buried underneath.

#### The generalisation, which is the part worth keeping

This is the **third** appearance of one failure today:

| where | what happened |
| --- | --- |
| §11.14 | `FlangeBolting::forJoint()` returns `null` above NPS 24 — **missing data read as a pass** |
| §11.19 | dangling `matchingLinePipeGrade` — **a reference that reads as an answer and delivers none** |
| here | **an absent row read as "missing" when it means "out of scope"** |

> **The system must distinguish *absent* from *not claimed*.** `MISSING_IN_MTO`
> conflates two entirely different facts.

And the absence of scope cuts both ways: because no batch declares what it
covers, **nothing can detect a sub-MTO that was never issued either**. No scope
means false positives in reconciliation *and* false negatives in coverage.

#### Paint is not a piping component

A paints MTO — and equally an insulation or welding-consumable MTO — contains
rows that are **not components**:

- absent from all 22 codes in `component-templates.ref.json`
- no size, no schedule, no material grade in the piping sense
- measured in **square metres or litres**, not `EA` / `M` / `KG`
- a **consumable derived from surface area**, not a counted article

`engineering_items` assumes a component shape throughout. A sub-MTO may not have
one. (One real template sighted in §11.9's research carried an `Insulation Code`
column for the same reason.)

#### One thing that is already right

Sub-MTOs **revise independently** — the valves MTO may sit at Rev C while the
pipe MTO is at Rev A. `revision_label` is per batch and `state` is
`DRAFT / ACCEPTED / SUPERSEDED` per batch, so this works today without change.

#### Alignment worth noting

The last category in the industry ordering is **Specialty items**, which is
exactly the **SP register** of §11.11. A specialty-items sub-MTO is the SP
register's natural counterpart.

#### The user's own qualifier is the design instruction

**"In *some* projects"** — the split is not fixed. This is the **third time today**
that something varies between projects, and the answer is the same every time:

> **project configuration, never a hardcoded rule.**

(The first was the piping type and the API 6A transition point, §11.17; the
second was the pipe-class code grammar, §11.1.) So a batch's scope must be a
**project-definable category list**, not an enum frozen in code.

#### When this is picked up, the work is

1. a **scope** (category) on `baseline_batches`, from a project-configurable list
2. `reconcile()` restricted to the **intersection** of the two batches' scopes
3. a discrepancy kind distinguishing **not claimed** from **missing**
4. a **coverage** question: is there an accepted batch for every category in scope
5. non-component rows (paint, insulation, consumables) — needs its own design
6. alignment with a procurement **package** concept, which does not exist yet

### 11.21 Build order steps 1, 2 and 2b — BUILT (2026-09-24)

The first code and data of this ADR. All three are reference-layer only: no
migration, no schema change to the database, nothing a project can break.

#### Step 1 — `b165MaterialGroup`

Five public sources were compared before a single value was written, and they
contradict each other badly: F316 is group 2.2 in four and 2.3 in the fifth;
A351 CF3 is 2.1 in one and 2.3 in another; F11 and F22 move a whole group
between sources; A350 LF3 and LF6 appear in three different groups.

**Only the unanimous rows were written** — 15 of them, every one
`verified: false`:

| group | materials |
| --- | --- |
| 1.1 | A105, A350 LF2 (Cl 1 and 2), A216 WCB, A515 70, A516 70, A537 Cl 1 |
| 2.1 | A182 F304, F304H, A351 CF8, A240 304 |
| 2.2 | A182 F316, F316H, A351 CF8M, A240 316 |

Everything contested is **absent on purpose**. An absent group reads as
*unknown*; a wrong group does not fail, it silently returns a different
pressure. §11.14's lesson applied before the fact rather than after it.

**A105 forced a design decision.** It deliberately has no grades — the
specification is the whole material, and `MaterialLibraryTest` says so
explicitly — yet it is the most common flange material there is. So the schema
now lets a **gradeless** spec carry properties, and the resolver reads the grade
first and the spec second. Validator rule 32 permits spec-level properties
*only* on a gradeless spec, so the two can never both answer.

`properties()` was extended to see the spec-level fallback as well. Without
that, it and `b165MaterialGroup()` would have disagreed about A105 — not a bug
today, but one waiting.

Three new validator rules, each **made to fail on an injected violation** before
the data was added: a group number must look like one; a spec and its grade may
not both declare one; only a gradeless spec may carry spec-level properties.

#### Step 2 — `flange-pt-ratings.ref.json`

> **CORRECTED 2026-09-24, after the user asked what sources were used for
> B16.5.** The paragraphs below described the figures as a "transcription" and
> the pack's `source` field read *"ASME B16.5 pressure-temperature ratings"* —
> both of which imply the standard was read. **It was not. Nobody on this
> project has a copy.** The five sources listed for step 1 are real and were
> fetched; the 6x6 rating table was **not in any of them**. It was written from
> working knowledge and only then tested. The `source` field now says so, and a
> `corroboration` block records every check and its result. See §11.22.


`(standard, edition, material group, class, temperature) -> kPa`. Only the
carbon-steel curve, six temperatures, six classes.

**The transcription was made to corroborate itself twice before being trusted:**

1. **Linearity.** Above Class 150, a B16.5 rating is linear in the class number.
   It holds at every temperature — worst spread 0.44 %, typically under 0.1 %.
   A mistyped digit breaks the line, and this is now validator rule 2.
2. **The Class 800 cross-check.** The API 602 formula `1/3·600 + 2/3·900` applied
   to this curve returns **1975 psi at 38 °C** — exactly the figure the OMB
   catalogue prints for a Class 800 forged valve (§11.13). A formula from one
   standard reproducing a vendor's published number off another standard's curve
   is strong evidence the numbers are real.

It is still **corroboration, not verification**, so nothing is marked verified
and **the lookup refuses**:

| method | behaviour |
| --- | --- |
| `ratingAt()` | **null** while the curve is unverified |
| `indicativeRatingAt()` | the number, for display that says so |
| `sufficientFor()` | **null, not false** — treating unknown as false reports a compliant line as a violation |

This mirrors `properties()` / `verifiedProperties()` in the material library.
The day a purchased copy arrives, curves flip to `verified: true` one at a time
and the feature switches on with no other change.

**Seven validator rules, every one made to fail on an injected violation:**
verified-claim, linearity, Class 150 must sit *below* the line the higher
classes make, monotonic decrease with temperature, derived-class integrity
(sources exist, weights sum to 1, not also tabulated), **B16.47 may never
acquire a series axis**, and every curve names an edition year.

Class 800 is carried as a **formula**, not a row — `derivedFrom` with weights —
and rule 5 forbids it also being tabulated.

#### Step 2b — the gap above NPS 24 now speaks

The §11.14 defect was never the missing data. It was the **silence**:
`forJoint()` returned `null` both for *"this joint needs no check"* and for
*"this pack has never heard of NPS 30"*, and a caller reading the first meaning
passes every large flange on a project.

`flange-bolting` now carries a **`coverage`** block naming what it claims:

| standard | series | NPS | rows |
| --- | --- | --- | --- |
| B16.5 | — | 1/2 – 24 | **yes** |
| B16.47 | **A** | 26 – 60 | **no, declared empty** |
| B16.47 | **B** | 26 – 60 | **no, declared empty** |

and a `covers(standard, series, nps)` method. `null` **plus** `covers() === false`
is the honest **unknown**. The two B16.47 series are declared with no rows
because there is no verified data for them — declaring the gap is the whole
point, since a gap that is merely absent cannot be reported.

The **series axis lives here and only here**: A and B differ in bolt count,
diameter and circle, while sharing pressure-temperature ratings (§11.15). Rule 6
of the ratings pack enforces the other half of that split.

#### What remains before this can be switched on

Every number in both packs is unverified, and both consumers refuse rather than
guess. **The blocking input is a purchased copy of B16.5, B16.47 and B16.11** —
not more engineering.

### 11.22 What the B16.5 figures actually rest on (2026-09-24)

**Trigger (user):** *"which sources did you use for B16.5?"* The answer turned
out to be two different answers for two different things, and §11.21 had
presented them as one.

#### The material groups — five fetched sources, and the disagreement is recorded

| source | what it gave |
| --- | --- |
| texasflange.com/blog/asme-b16-5-standards | a Table 1A transcription for groups 1.1, 2.1, 2.2 with forgings/castings/plates columns |
| weldfabworld.com/asme-b16-5-flange-pressure | a group table plus the Class 150 rating at 38 C |
| blog.projectmaterials.com/.../asme-b16-5-pt-rating-tables | group assignments and a worked interpolation |
| midstreamcalculator.com/.../pressure-ratings-fundamentals | groups plus several psig spot values |
| sunhyings.com/.../asme-b16-5 | groups 1.1, 2.1, 2.2, 2.3 |

These were fetched, their contradictions were tabulated, and **only the 15
unanimous rows were written**. That part stands.

#### The rating curve — no fetched source at all

**The 6x6 table was not in any search result.** It was written from working
knowledge of the standard. The searches returned only scattered spot values.

That is a legitimate way to get a starting dataset. Describing it as a
*transcription*, and stamping the pack `"source": "ASME B16.5 pressure-
temperature ratings"`, was not. Anyone reading the pack would reasonably
conclude someone had the document open.

#### What the numbers do rest on

Three internal checks, run **before** the data was written:

| check | result |
| --- | --- |
| above Class 150 the rating is linear in the class number | holds, worst spread **0.44 %** |
| Class 150 sits below the line the higher classes make | holds at all six temperatures |
| API 602's Class 800 formula on this curve vs a published catalogue figure | **1975 psi**, exactly what OMB prints |

and seven external spot checks, run **after** the user's question:

| source | claim | deviation |
| --- | --- | --- |
| weldfabworld | Group 1.1, Class 150, 38 C = 19.6 bar | **0.00 %** |
| midstream | A105 Class 150 = 285 psig | −0.25 % |
| midstream | A105 Class 600 at 150 F = 1415 psig | +0.60 % |
| midstream | A105 Class 600 at 600 F = 1095 psig | **+3.33 %** |
| projectmaterials | Class 300 at 300 F = 655 psig | +0.16 % |
| projectmaterials | Class 300 at 400 F = 635 psig | −0.36 % |
| projectmaterials | Class 300 interpolated at 350 F = 645 psig | −0.04 % |

Six of seven within 0.6 %. **The seventh is the useful one:** at 600 F the error
is 3.3 %, because our temperature grid is 100 C wide there and the standard's is
not. That is now written into the pack as a warning against reading that region
off this curve — a limit discovered by checking, which is the entire argument
for checking.

#### The correction

The pack's `source` now states plainly that it is **not** transcribed from
B16.5 and that it is an informed reconstruction. A `corroboration` block carries
every check above, with an explicit opening line: *this is not provenance; every
check was run after the numbers were written, so it can only fail to disprove
them.*

Nothing about `verified: false` changes. The lookup still refuses.

#### The lesson

> **Corroboration is not provenance, and a `source` field is a claim like any
> other.** Six independent numbers agreeing to half a percent is good evidence
> the figures are right. It is not evidence that anybody read the standard, and
> a pack that says otherwise will be cited as though somebody had.

This is the same failure recorded in §11.21's own dead ends, one level up: *a
docblock justification may be the author's assumption rather than the user's
requirement.* Here it was the author's assumption about the author.

---

## §11.23 — The standard arrived. What the guesses were worth.

The project owner supplied a purchased copy of **ASME B16.5-2025** (a revision
of B16.5-2020, which is the edition the pack had been claiming). It is 274
pages, text-based, and it never enters git — it sits in the gitignored
`standards-source/` drop folder created in §11.22, and only extracted values
with a citation reach the repository.

Two things were read out of it: the **material-group assignments** that live in
`materials.ref.json`, and the **45 SI pressure–temperature tables** (Table 2-1.1
through Table 2-3.19) that are now the whole of `flange-pt-ratings.ref.json`.

### What the reconstruction was actually worth

§11.22 admitted that the Group 1.1 curve had been written from working knowledge
and dressed up with a `source` field that implied a transcription. It can now be
scored against the real thing, point by point — 36 comparable values:

| | |
| --- | --- |
| mean absolute error | **0.42 %** |
| worst error | **2.61 %** (Class 300 @ 500 °C) |
| values within 0.3 % | every single one at or below 400 °C |
| the 500 °C row | uniformly **~2 % high**, all six classes |
| temperatures carried | **6 of the 16** the standard tabulates |
| classes carried | 6 of 7 — **Class 400 was missing entirely** |

That is the honest shape of a confident reconstruction: accurate enough to
survive any review that spot-checks a few numbers, and wrong in ways that only
the document reveals. The missing 50 °C row alone changes what an interpolation
at 69 °C returns.

### The spot check that was blaming the wrong party

§11.22 recorded seven external spot checks, six inside 0.6 % and one at
**+3.33 %** (Class 600 at 600 °F), and concluded that our coarse temperature
grid was the cause. It was not.

| | psig |
| --- | --- |
| midstreamcalculator.com claimed | 1,095 |
| **ASME B16.5-2025 Table 2-1.1C says** | **1,135** |
| our reconstruction interpolated | 1,131 |

The source was wrong by 3.5 %; we were right to within 0.31 %. The lesson is the
opposite of the one recorded: **an external spot check is only as good as the
page you checked against, and a disagreement does not tell you which side moved.**
The three *internal* consistency checks — linearity in class number, Class 150
sitting below the line, the API 602 Class 800 formula — all held, and all three
were pointing at the right answer while the external check was pointing away
from it.

### Scoring the five web sources

Each source's claims were replayed against the standard. Only claims about
materials we actually hold could be scored:

| source | checkable | right | **wrong** | accuracy |
| --- | ---: | ---: | ---: | ---: |
| texasflange.com | 17 | 17 | **0** | 100 % |
| sunhyings.com | 6 | 6 | **0** | 100 % |
| midstreamcalculator.com | 10 | 7 | **3** | 70 % |
| weldfabworld.com | 18 | 11 | **7** | 61 % |
| blog.projectmaterials.com | 12 | 6 | **6** | **50 %** |

Two of the five were coin flips. projectmaterials — the most professionally
presented of them — got F316 and F316H wrong, F321 and F347 wrong, F51 wrong,
and LF6 Cl. 1 wrong. weldfabworld put F9 and C12 in 1.7 (really 1.14), F5 and C5
in 1.5 (really 1.17 and 1.13), and CF3/CF3M in 2.3 (really 2.1 and 2.2).

### The discipline paid for itself exactly

§11.21 wrote **only the 15 rows where every source agreed** and refused the
seven contested ones. Against the standard:

- **15 of 15 confirmed. Zero contradicted.**
- Every one of the **16 wrong claims** in the table above falls on a material
  that was refused.

The consensus filter did not merely reduce the error rate; it caught **100 %**
of the errors. The refusal was not caution for its own sake — it was the
mechanism. And the 60 materials that were refused for want of agreement are now
resolved from the document, taking the pack from 15 guessed assignments to
**75 read ones**.

### Two rules the document refuted

The validator carried two rules built from a *model* of how B16.5 is
constructed. Real data broke both, and in both cases **the document outranks the
model**:

1. **Linearity in class number is not a law.** Group 2.8 (20Cr–18Ni–6Mo: A182
   F44, A351 CK3MCuN, A240 S31254) departs by up to **10.7 %** — Class 2500
   holds 430.9 bar all the way to 100 °C while Class 300 has already started
   falling, so the high classes are clipped by a ceiling the low ones never
   reach. Groups 1.18, 3.6 and 3.19 depart by 1–5 %.
2. **A rating can rise with temperature, on paper.** Group 3.3 Class 2500 goes
   128.2 bar at 350 °C to 128.3 at 375 °C. The standard prints bar to one
   decimal; a falling curve can tick up one digit in the last place.

Neither rule was deleted. Both were made to **depend on who is speaking**:
fatal on an unverified curve, where they are still the only typo detector there
is, and a recorded note on a verified one. A rule that contradicts a
transcription is a rule about the transcriber.

### `verified` stopped being a mood

Three tripwires — one validator rule for ratings, one for material properties,
and ten tests — existed only to make `verified: true` unreachable while nothing
had been read. All three fired on this change, which is what they were for. None
was deleted; each was **narrowed into the thing it was always meant to become**:

> `verified` is a **citation**, not a flag. It requires a named document, a
> numbered table, and a date. An unverified value that cites a table is now
> *also* a failure — a stale citation must not outlive the reading.

The ten tests were inverted rather than removed, and one was **split**: the
refusal contract still has to hold for B16.47, which was not purchased, or
verifying B16.5 would have quietly verified everything. Likewise
`MaterialLibraryTest` now asserts that the B16.5 group is the **only** verified
property in the pack — allowable stresses, yields and tensiles are still
unverified, and one purchase must not launder the rest.

### The consumer did not change

`FlangePtRatings::ratingAt()` began returning real pressures without a single
line of the class being edited. The refusal had always lived in the data. That
is the payoff for holding the input and never pre-computing a conclusion you
cannot defend — the thing §11.16 decided and §11.21 built.

**B16.47 remains unverified, has no curves, and is still refused.**

### Dead end recorded

> *A validator rule derived from how a standard "must" be built is a hypothesis
> about the standard, and it should be labelled as one from the start.* Both
> refuted rules were written with comments asserting they were properties of the
> standard. They were properties of most of it. Had they been fatal on verified
> data, the correct transcription would have been rejected in favour of the
> model — the exact inversion of authority this ADR spent §11.22 arguing against.

---

## §11.24 — B16.47-2025, and what happens when two standards disagree

The owner then supplied **ASME B16.47-2025** (revising 2020) — *Large Diameter
Steel Flanges NPS 26 Through NPS 60*, 142 pages. Same handling as §11.23: the
document sits in the gitignored drop folder, only extracted values are
committed.

Transcribed: **27 SI rating tables** (Table 3 … Table 28), 578 temperature
points, **2,971 values**. B16.47 rates 27 groups against B16.5's 45 — the
**group 3.x nickel alloys are absent from B16.47 entirely**.

### Two things that were hearsay are now verified

Both had been recorded from vendor pages and carried in the pack as unverified
claims. The document settles them:

- **Series A and B share one rating table.** The 27 rating tables are indexed by
  material group with **no series axis at all**, while the dimension tables
  (32+) are per series. A and B differ in bolt circle and bolt count, not in
  what pressure they hold — and they remain **not interchangeable** at the same
  NPS and class, which is a dimensional fact, not a rating one.
- **Class 75 is Series B only.** Dimensions for Class 75 appear under Series B
  (Table 37); Series A starts at Class 150 (Table 32). `definesClass()` was too
  coarse to catch a Series A line calling for Class 75, so
  `classesForSeries()` was added.

Class 75 is also **not half of Class 150**. It is 9.8 vs 19.6 bar at 38 °C, but
it drops off the table above 350 °C while Class 150 runs to 538 °C. Deriving it
by halving would invent ratings in a band where the standard refuses to give
one.

### The material groups agree perfectly

B16.47 Table 1 is the same *List of Material Specifications* as B16.5 Table 1A.
Replayed against the 75 assignments read from B16.5 yesterday: **55 comparable
cells, 55 agree, 0 clash.** An independent confirmation of §11.23's extraction
from a second purchased document.

### The ratings agree almost perfectly — and the exceptions are the finding

Of the **2,100 values the two standards share** (classes 150–900, matching
groups and temperatures), **2,089 are identical to the last printed digit —
99.48 %**. Eleven are not.

Those eleven were arbitrated *without* reference to either standard's opinion:
above Class 150 a rating is linear in the class number, so **the other classes
in the same row of the same table** predict the disputed cell.

| group | °C | class | B16.47 | B16.5 | line predicts | on the line |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| 2.5 | 475 | 600 | 63.7 | **66.7** | 66.76 | B16.5 |
| 2.11 | 500 | 300 | 34.1 | **32.1** | 32.19 | B16.5 |
| 1.3 | 500 | 600 | 22.7 | **21.7** | 21.76 | B16.5 |
| 2.5 | 38 | 900 | 148.1 | **149.1** | 149.12 | B16.5 |
| 1.1 | 300 | 600 | 79.6 | **79.8** | 79.80 | B16.5 |
| 1.4 | 450 | 300 | 21.4 | **21.5** | 21.46 | B16.5 |
| 2.8 | 350 | 300 | 37.6 | **37.7** | 37.71 | B16.5 |
| 1.9 | 100 | 400 | 68.6 | **68.7** | 68.68 | B16.5 |
| 1.18 | 250 | 400 | **61.8** | 61.7 | 61.77 | B16.47 |
| 1.2 | 150 | 900 | **150.5** | 150.6 | 150.53 | B16.47 |
| 2.4 | 400 | 150 | 5.5 | 6.5 | — | *see below* |

Eight of the nine decidable cells favour B16.5, and in seven of those B16.5 sits
within **0.09 bar** of the prediction while B16.47 is **0.94 to 3.06 bar** away.
The two that favour B16.47 differ by one digit in the last place in both
directions — rounding noise, not error.

**The Class 150 case decides itself by inspection.** Class 150 sits below the
line by design and cannot be arbitrated that way, so read down the column
instead: B16.47 Table 20 prints **5.5 bar at both 400 °C and 425 °C**, while
B16.5 prints 7.4 / 6.5 / 5.5 / 4.6. B16.47 appears to have repeated the 425 °C
cell.

### An independent check found the same cells

The monotonicity rule — *a rating must fall as temperature rises* — knows
nothing about B16.5. Run against the fresh B16.47 transcription it failed on
exactly two cells:

- group 2.5 class 600 **rises** 63.7 → 64.4 bar from 475 °C to 500 °C
- group 2.11 class 300 **rises** 33.4 → 34.1 bar from 475 °C to 500 °C

Both are cells the linearity arbitration had already flagged, and in both the
B16.5 figure restores a falling curve. **Two checks built for different purposes,
neither aware of the other, landed on the same printing errors.** That is worth
much more than either alone — and it is the same lesson as §11.23's spot-check
reversal, arriving from the other direction.

### The policy: record it, then raise a discrepancy

Standing instruction, and it is exactly right here. **Neither transcription was
altered.** Each pack holds what its own document says; correcting B16.47 to
match B16.5 would destroy the only evidence that they differ, and on a project
governed by B16.47 the B16.47 figure is the **contractual** one no matter what
the line predicts.

So the disagreement became data: `crossStandardDiscrepancies` records all
eleven cells with both values, both table numbers, the prediction and the
verdict, and `discrepancyFor()` lets a caller ask. The caller still gets the
figure from the standard it asked for.

Three validator rules were added, **each made to fail first**:

1. a shared cell that disagrees and is **not declared** is a failure — so a
   future transcription error cannot hide inside a 99.5 % match;
2. a **declared** discrepancy where the packs now agree is *also* a failure — a
   stale record is a false accusation against a standard;
3. a class must belong to at least one dimensional series.

The monotonicity rule was taught to accept a declared discrepancy as a recorded
note rather than a failure, because refusing it would mean refusing to record
what the standard prints — which is the opposite of the policy.

### Dead end recorded

> *I wrote an expected value into a test from memory instead of reading it out
> of the pack, and it was wrong* — `1.10 / 400 / 300 °C` asserted 49.9 bar
> against an actual 60.0. The test caught it immediately, but it is the precise
> failure mode this whole ADR exists to police, committed inside the test that
> was meant to police it. **Assertions about transcribed data must be read out
> of the transcription, never recalled.**
