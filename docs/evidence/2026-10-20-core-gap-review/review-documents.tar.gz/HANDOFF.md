> **Current review / user deferral — 2026-10-20:** [core gaps and priorities](docs/CORE-GAP-REVIEW-2026-10-20-EN.md) / [فارسی](docs/CORE-GAP-REVIEW-2026-10-20-FA.md). Structured prerequisite item design AND implementation explicitly deferred; free text retained. Source/document review, not a test run or new authority/schema approval. Recommended next: focused document allocation review, then warehouse provenance/arithmetic diagnostics; next user-visible target is exact-line PO receipt after needed decisions. Conflicting older status/“current full source green” statements below are historical evidence, not this review’s current verification.

> **Approved PDF continuation — 2026-10-20:** [current prerequisite appendix](docs/INSPECTION-PREREQUISITE-PDF-EN.md) / [فارسی](docs/INSPECTION-PREREQUISITE-PDF-FA.md). Selected prerequisite_pdf implemented: all records/full history/retained stage, separate from issuance snapshot; same scope, no new schema/authority/writes.409 on changes during render.20/1102 + separate4/60 PASS; not full-suite/current-CI/deployed. Only prerequisite-PDF deferral and contradictory historical prose below are superseded; other decisions retained.

> **Current delivery — 2026-10-20:** [original-notice status filter for prerequisites](docs/INSPECTION-PREREQUISITE-ACTIVE-NOTICE-FILTER-EN.md) / [فارسی](docs/INSPECTION-PREREQUISITE-ACTIVE-NOTICE-FILTER-FA.md). User-selected active_notice_filter: All default, not-cancelled/cancelled, independent of prerequisite state; no writes/authority/schema/PDF. Company-picker/count scope retained;36/2008 PASS. Seven prior source hashes matched, no recovery needed; vendor remains excluded-cache symlink. Not full-suite/current-CI/browser/deployed/committed/pushed; private DB stopped after checks.

> **Current delivery — 2026-10-20:** [readable prerequisite company picker](docs/INSPECTION-PREREQUISITE-COMPANY-PICKER-EN.md) / [فارسی](docs/INSPECTION-PREREQUISITE-COMPANY-PICKER-FA.md). User-selected company_picker: captured name/code from visible declaring companies only, literal search/25-option pages, pinned selection/independent pages. No new directory/access/schema/write/PDF.56/1793 PASS; not full-suite/current-CI/browser/deployed/committed/pushed.16 prior sources restored from checked archive with differences preserved; new bundle in evidence; private DB stopped after checks.

> **Current delivery — 2026-10-20:** [project prerequisite tracking](docs/INSPECTION-PREREQUISITE-REGISTER-EN.md) / [فارسی](docs/INSPECTION-PREREQUISITE-REGISTER-FA.md). Selected tracking_register: status/declaring-company identity/literal notice filters,25-row pages and visible-only counts, cancelled-original label; no new writes/authority/schema/PDF. Missing inherited-stage workspace source restored/verified; recovery report/source archive in evidence. Final47/1051 + separate legacy1/12 PASS; earlier runs overlap. Not full-suite/current-CI/browser/deployed/committed/pushed; private DB stopped after checks.

> **Current delivery — 2026-10-20:** [exact inherited ITP context for prerequisites](docs/INSPECTION-PREREQUISITE-ITP-LINK-REVIEW-EN.md) / [فارسی](docs/INSPECTION-PREREQUISITE-ITP-LINK-REVIEW-FA.md). User-selected inherited_stage implemented: retained notice snapshot only in create/current/history context; no live sources, new schema/access/backfill, structured sub-items or PDF changes.54/807 + separate legacy1/12 PASS; not full-suite/browser/current-CI/deployed/committed/pushed. Private DB stopped after checks.

> **Current delivery — 2026-10-20:** [recipient prerequisites](docs/INSPECTION-NOTIFICATION-PREREQUISITES-EN.md) / [فارسی](docs/INSPECTION-NOTIFICATION-PREREQUISITES-FA.md), [ADR-045](docs/ADR-045-INSPECTION-NOTIFICATION-PREREQUISITES-EN.md). Explicit any_reader_company_scope / report_and_recipient_confirm / all_notice_readers implemented. Multiple item-text requirements, reasoned edits/withdrawals, sender live-issuer reports, recipient confirmation/rejection and immutable history. No automatic gate, technical acceptance or source/stock authority; original/PDF unchanged.81/1290 + separate upgrade1/5 PASS; not full-suite/current-CI/deployed/committed/pushed; private DB stopped after checks. Earlier current notices below are historical.

> **Current delivery — 2026-10-20:** [company acknowledgment](docs/INSPECTION-NOTIFICATION-ACKNOWLEDGMENT-EN.md) / [فارسی](docs/INSPECTION-NOTIFICATION-ACKNOWLEDGMENT-FA.md), [ADR-044](docs/ADR-044-INSPECTION-NOTIFICATION-ACKNOWLEDGMENT-EN.md). Explicit any_authorized_company_reader / issue_and_cancellation_separate / all_authorized_notice_readers / detail_and_current_pdf implemented. First immutable company/event receipt, no late original receipt after cancel; scoped company/person/time and current PDF with409 on receipt changes during render. No automatic read tracker, transport/signature/approval or doc/MTO/MR/PO/stock authority. Final61/1040 + separate upgrade1/5 PASS; overlapping final PDF1/22 PASS. Not full-suite/current CI/deployed/committed/pushed; private DB stopped.

> **Current delivery — 2026-10-20:** [independent issued cancellation](docs/INSPECTION-NOTIFICATION-CANCELLATION-EN.md) / [فارسی](docs/INSPECTION-NOTIFICATION-CANCELLATION-FA.md), [ADR-043](docs/ADR-043-INSPECTION-NOTIFICATION-CANCELLATION-EN.md). Explicit current_issue_grant/cancel_only/status_reason_scoped_replacement implemented: separate append-only event, immutable original number/version/body/snapshot, effective CANCELLED, scoped reason/actor/time without private-history disclosure. Current PDF banner/status and409 on cancellation during render. Final59/884 + separate upgrade1/5 PASS; overlapping PDF1/22 PASS. Only cancellation deferral superseded; replacement/undo/acknowledgment deferred. Not90-case/full-suite/production/current-CI certification; no commit/push/deploy. Private DB stopped.

> **Latest continuation — 2026-10-20:** [optional filter time UI](docs/INSPECTION-NOTIFICATION-FILTER-TIME-UI-EN.md) / [فارسی](docs/INSPECTION-NOTIFICATION-FILTER-TIME-UI-FA.md), user-selected `filter_usability` delivered.26 tests/404 assertions and7 Chromium groups/147 checks PASS (separate/nonadditive). Partial helper blocks submit; fully empty omits bound; no assumed offset/new authority/schema. Current synthetic rendered Chromium fixtures, not production/live-auth/full suite; private DB stopped.

> **Current delivery — 2026-10-20:** [notification register filters](docs/INSPECTION-NOTIFICATION-REGISTER-FILTERS-EN.md) / [فارسی](docs/INSPECTION-NOTIFICATION-REGISTER-FILTERS-FA.md). User-selected `register_filters`: literal number/current-reference search, state, inclusive offset-aware overlap, authorized counts/pages and language/context preservation. No inferred legacy window, history search, new authority/schema/endpoint/write. **58 tests /640 assertions PASS, zero skipped**, not full suite/production/current CI/performance certification. Earlier counts historical; ADR-042/MTO/private-history boundaries retained.

> **Current delivery — 2026-10-20:** [notification draft edit history](docs/INSPECTION-NOTIFICATION-DRAFT-HISTORY-EN.md) / [فارسی](docs/INSPECTION-NOTIFICATION-DRAFT-HISTORY-FA.md). User-selected `draft_history`: atomic DB before/after/version + captured editor name/UUID/time/settings, append-only/FORCE RLS, originating-company readers only, no recipient/PDF history.25-row pages, no-op saves retained, no pre-install backfill. Migration120000; **87 tests /1139 assertions PASS, zero skipped**, not full suite/production/current CI. Earlier totals historical; authority/ADR-042/MTO boundaries retained, issued cancellation/rescheduling deferred.

> **Current delivery — 2026-10-20:** [notification date/time UI](docs/INSPECTION-NOTIFICATION-TIME-UI-EN.md) / [فارسی](docs/INSPECTION-NOTIFICATION-TIME-UI-FA.md). User-selected `date_time_ui`: native date/time + explicit offset, visible exact/direct/no-JS entry and readable display; no inferred timezone/API/schema/authority change. Related53/740 and final4/81 subset PASS; separate18 browser scenarios/149 checks PASS, nonadditive. Not full suite/production/current CI/E2E/all-browser acceptance. History and replace_time/ADR-042/MTO boundaries retained.

> **Current delivery — 2026-10-20:** [notification activity window](docs/INSPECTION-NOTIFICATION-ACTIVITY-WINDOW-EN.md) / [فارسی](docs/INSPECTION-NOTIFICATION-ACTIVITY-WINDOW-FA.md). User-selected `replace_time`: required planned start/end replace single time, preserve offsets and compare instants; EN/FA forms/register/detail/PDF. Legacy issued times explicitly labelled, no backfill; legacy drafts must explicitly convert before issue. Migration110000; **71 tests /802 assertions PASS, zero skipped**, not full suite/production/current CI; earlier counts/single-time contract are historical. Same authority/ADR-042/MTO boundaries; no issued rescheduling.

> **Current delivery — 2026-10-20:** [bounded notification draft editing](docs/INSPECTION-NOTIFICATION-DRAFT-EDIT-EN.md) / [فارسی](docs/INSPECTION-NOTIFICATION-DRAFT-EDIT-FA.md). User-approved `draft_only`; same current draft grant/company, optimistic version, fixed source/creation evidence; latest-edit metadata, not full draft history. Issued/PDF immutability retained; issued cancellation/rescheduling deferred. **58 tests /631 assertions PASS, zero skipped**; not full suite/production/current CI. Earlier create-only limits/counts are historical; ADR-042/MTO boundaries unchanged.

> **Current delivery — 2026-10-20:** [issued-notification PDF](docs/INSPECTION-NOTIFICATION-WORKFLOW-EN.md) / [فارسی](docs/INSPECTION-NOTIFICATION-WORKFLOW-FA.md): actual EN/FA output from immutable history, same readers and post-render visibility recheck; no record mutation/signature/transport/source-read delegation. Project metadata captured only on new issues; no legacy backfill. **42/501 + separate21/85 PASS =63 tests /586 assertions across two commands, no skips**, not full suite/production/current CI. Earlier PDF deferrals and46/250 counts are historical; five ADR-042 choices and MTO boundary retained.

> **Current delivery — 2026-10-19:** [operational ITP notifications](docs/INSPECTION-NOTIFICATION-WORKFLOW-EN.md) / [فارسی](docs/INSPECTION-NOTIFICATION-WORKFLOW-FA.md). Explicit main contractor, authorized-admin draft/issue permission assignment, document-revision stages, drafts, atomic issue/immutable snapshot and purpose-limited recipient inbox are implemented. **Two final commands:46 tests /250 assertions PASS**, not full regression. Notice is not inspection result/signature/external delivery/usable stock. Earlier contract-only status below is historical; five ADR-042 choices and ADR-041/MTO boundaries retained. No production/current-CI claim.

> **New requirement/status — 2026-10-19:** [ADR-042: ITP inspection notifications](docs/ADR-042-ITP-INSPECTION-NOTIFICATIONS-EN.md). Five owner choices retained: all stages, separately delegated contractor permission, explicit authorized project recipients, document-revision/stage host, main contractor only. **Input contract only:7 unit tests/24 assertions PASS; no operational draft/issue UI/service yet.** Notification is not ADR-041 inspection result; earlier evidence does not certify this feature.

> **Current delivery — 2026-10-19:** [independent inspection entry](docs/INSPECTION-ENTRY-EN.md) / [فارسی](docs/INSPECTION-ENTRY-FA.md), [ADR-041](docs/ADR-041-INDEPENDENT-INSPECTION-ENTRY-EN.md). **46 affected tests /558 assertions PASS**,14 new cases. Owner versioned nominations/suspension, create-only original-visible PO form, server attribution and immutable new evidence. Existing TPI/PMC/MC/OWN independence, non-PASS findings and IRN numbering retained; no default/inherited writer, PO read delegation, source/lot/financial/receipt/usable/MTO mutation. Migration190000 privately verified only; no full-suite/production claim. Older current notices/counts below are historical and nonadditive.

> **Current delivery — 2026-10-19:** [independent inspection pagination](docs/INSPECTION-REGISTER-PAGINATION-EN.md) / [فارسی](docs/INSPECTION-REGISTER-PAGINATION-FA.md). **40 affected tests /556 assertions PASS**, four new cases. Inspection25-row pages, independent three-way navigation/true totals, explicit project + unchanged participant-visible quality RLS, unused PO eager load removed; advisory receipt semantics unchanged. Supersedes the earlier inspection-pagination deferral only. No new role/schema/endpoint/write or full-suite/production claim; older evidence/notices below are historical.

> **Current delivery — 2026-10-19:** [exact money + independent register pagination](docs/REGISTER-PAGINATION-MONEY-EN.md) / [فارسی](docs/REGISTER-PAGINATION-MONEY-FA.md). **41 affected tests /499 assertions PASS**, eight new cases. Exact stored decimal money/null≠zero; independent25-row MR/PO pages, filtered totals/late count, stable ordering and preserved filters/original caller RLS. This closes the two earlier recommended increments, not indexed/load-certified search or inspection pagination. No new endpoint/schema/role/action or full-suite/production claim. Prior evidence retained; older current/follow-up notices below are historical.

> **Current feature — 2026-10-19:** [independent MR/PO register search + states](docs/PROCUREMENT-REGISTER-FILTERS-EN.md) / [فارسی](docs/PROCUREMENT-REGISTER-FILTERS-FA.md). **33 affected tests /310 assertions PASS**, eight new cases. Bound literal header search, category/state intersection, unchanged original caller RLS, scoped counts and inspections unchanged. No new role/schema/endpoint/action or full-suite/production claim. Server pagination/indexing and preexisting register float/integer money formatting remain explicit follow-up recommendations. Prior evidence retained; older current notices below are historical.

> **Current correction — 2026-10-19:** [safe pricing-form recovery](docs/PO-PRICING-FORM-RECOVERY-EN.md) / [فارسی](docs/PO-PRICING-FORM-RECOVERY-FA.md). **42 affected tests /465 assertions PASS**, nine new cases. Recover input only for the same current PO hash and complete active UUID set; blank≠zero, stale/malformed input not rebased, original write/grant/source checks unchanged. No new role/schema/endpoint or full-suite/production claim. Prior evidence preserved; older current notices below are historical.

> **Current read-only feature — 2026-10-19:** [structured retained pricing comparison](docs/PO-PRICE-HISTORY-COMPARISON-EN.md) / [فارسی](docs/PO-PRICE-HISTORY-COMPARISON-FA.md). **33 affected tests / 359 assertions PASS**, eight new cases. Exact text money, UUID-matched before/after prices/currency/totals, unknown≠zero, raw snapshots retained and latest20 only. Existing buyer/project RLS unchanged; no new writer/role/schema/approval or full-suite/production claim. Prior evidence unchanged; older current/next notices below are historical.

> **Current workflow addition — 2026-10-19:** [PO draft directly from MR details](docs/MR-TO-PO-CONTEXT-ACTION-EN.md) / [فارسی](docs/MR-TO-PO-CONTEXT-ACTION-FA.md). **43 affected tests / 340 assertions PASS**, five new cases. Eligible own-buyer/current independently nominated authors reuse the existing full-copy POST; live source/grant/archive rechecks, safe validation return, no source consumption/reservation/issue. GET stays nonmutating; the optional action deliberately creates a DRAFT PO. No new endpoint/role/schema or full-suite/production claim. Prior evidence unchanged; older current/next notices below are historical.

> **Current feature — 2026-10-19:** [read-only MR detail sheet](docs/MATERIAL-REQUISITION-DETAILS-EN.md) / [فارسی](docs/MATERIAL-REQUISITION-DETAILS-FA.md). **30 affected tests / 240 assertions PASS**, ten new cases. Exact stored source lines/original quantity spelling, recorded approval/rejection metadata and bounded visible related POs, under original caller RLS/current membership/discipline/plan. No journal delegation, mixed-unit sum, official remaining quantity, new role/schema/write gate. Prior evidence unchanged; no full-suite/production claim. Evidence: `docs/evidence/2026-10-19-mr-details/summary.json`. Older current/next notices below are historical.

> **Current targeted verification — 2026-10-19:** [PO rollback / nomination-suspension contention](docs/PO-ROLLBACK-REVOCATION-EN.md) / [فارسی](docs/PO-ROLLBACK-REVOCATION-FA.md). **38 affected tests / 328 assertions PASS**, including four new two-connection schedules (issue rollback, suspension commit/rollback, issue-before-suspension). Runtime code unchanged; no authority/workflow/schema changes. These are bounded timeout-and-fresh-retry schedules, not comprehensive crash/revocation certification. Prior evidence remains unchanged; totals are not cumulative. Older current/next notices below are historical.

> **Current boundary repair — 2026-10-19:** [human OrderGap source protection](docs/ORDER-GAP-HUMAN-BOUNDARY-EN.md) / [فارسی](docs/ORDER-GAP-HUMAN-BOUNDARY-FA.md). Confirmed HTTP quantity-amendment escape for controlled MR copies closed; human attribution/amendment now use fresh locked source markers and protected forms are hidden. Trusted/legacy lineage and accepted complete pricing retained. **77 affected tests / 764 assertions PASS**, six new cases. No new roles/MTO policy/schema migration or full-suite/production claim. Evidence: `docs/evidence/2026-10-19-order-gap-human-boundary/summary.json`. Legacy/manual authority redesign remains deferred. Older current/next notices below are historical.

> **Current security correction — 2026-10-19:** [PO issued-guard RLS isolation](docs/PO-GUARD-ISOLATION-EN.md) / [فارسی](docs/PO-GUARD-ISOLATION-FA.md). Confirmed hidden-journal line-mutation bypass repaired with a trigger-only, visible-parent-capped integrity lookup; caller settings restored and ordinary journal RLS unchanged. **71 affected tests / 658 assertions PASS**, six new cases including archived populated upgrade. Forward-only function migration180000; no historical row rewrite/new roles/MTO rights/production application/full-suite claim. Evidence: `docs/evidence/2026-10-19-po-guard-isolation/summary.json`. Older current/next notices below are historical.

> **Current increment — 2026-10-19:** [OrderGap mutation lock alignment](docs/ORDER-GAP-LOCKING-EN.md) / [فارسی](docs/ORDER-GAP-LOCKING-FA.md). **65 affected tests / 552 assertions PASS**, six new cases, including two real issue-versus-amend connection schedules. Project advisory → project → PO → item locks; fresh-state/lineage rechecks; legacy rules retained and controlled issued-content freeze unchanged. No new roles/MTO authority/reconciliation writer or full-suite/production claim. Evidence: `docs/evidence/2026-10-19-order-gap-locking/summary.json`. Next recommendations are design/review, not enabled post-issue amendment or capacity release. Older current/next notices below are historical.

> **Current increment — 2026-10-19:** [read-only MR source commitment review](docs/PO-SOURCE-REVIEW-EN.md) / [بررسی فقط‌خواندنی تعهدات منبع](docs/PO-SOURCE-REVIEW-FA.md). **57 related tests/502 assertions PASS**,12 new cases. Existing caller-RLS/discipline visibility only; no buyer impersonation/new roles/schema/write actions. Visible cancelled/headerless legacy commitments and recorded allocations are distinguished; hidden buyer evidence is UNKNOWN, not missing/zero; quantities retain historical units and no official remaining balance is inferred. ADR-036/038/039 authority/atomic issuance retained; prior108/746 evidence unchanged. No full/recovery/production claim. Next: lock-order alignment and controlled resolution/post-issue design; write-based legacy resolution/release remains NOT implemented. Older current/next statements below are historical.

> **Latest functional delivery — 2026-10-19:** [PO DRAFT entry](docs/PURCHASE-ORDER-ENTRY-EN.md) / [ثبت پیش‌نویس سفارش خرید](docs/PURCHASE-ORDER-ENTRY-FA.md). Accepted independent owner-configured PO author nomination, no default/MR inheritance; manual 1–20-line DRAFT only, exact pricing and project-wide counter. **92 related tests/613 assertions + separate MR upgrade1/57 PASS**; new PO entry+upgrade14/133 included. No issuance, spending approval or MR consumption. Direct detail proc/pack entitlement gap closed. Full suite/recovery not repeated; older latest/full-gate headers below are historical, not current certification or mandatory next steps. Evidence: `docs/evidence/2026-10-19-po-entry/summary.json`.

> **Latest functional delivery:** [Purchase order detail sheet](docs/PURCHASE-ORDER-DETAILS-EN.md) / [فارسی](docs/PURCHASE-ORDER-DETAILS-FA.md), reached from order numbers in Procurement.54 targeted tests/227 assertions PASS (8 new HTTP cases/52 assertions). Latest user directive: faster feature bundles, affected tests per change; full suite only milestones/high-risk/release, no routine recovery/report churn. Source changed: full-green statements below are historical, not current feature proof and NOT a new mandatory pending gate. Existing numbering defect and MTO authority deferral unchanged.

## Standing working rule — documentation and decisions first

Before any proposal/change, inspect canonical requirements/ADRs and dated owner corrections; distinguish ACCEPTED domain rules, PROPOSED implementation, explicit deferral and actual built source. Use docs/DECISION-REFERENCE-INDEX-{EN,FA}.md for navigation, not as a second authority. Never reopen settled principles because an old question list survives. For a defect/conflict, present source references, impact and recommendation; do not silently supersede business decisions. User authorized the documented reconciliation corrections, NOT new MTO/admission authority. Maintain paired EN/FA documents, preserve historical evidence, and update current pointers/status. Missing authority does not prohibit read-only/technical work that grants none.

> **Latest correction — 2026-10-18 decision reconciliation:** start with [decision index](docs/DECISION-REFERENCE-INDEX-EN.md) / [فارسی](docs/DECISION-REFERENCE-INDEX-FA.md). Accepted ADR-018 evidence/mapping/withdrawal/header/coverage/history rules are NOT new questions. Prototype header equality restriction corrected to explicit same-version ancestry;46 offline cases now, not38. Permission redesign remains explicitly deferred; no admission writer/role, app/DB/API/OrderGap change. All450 full-tested application hashes unchanged;1112/16488 full pass remains valid. Older38-case/latest-policy-next headers below are historical. See docs/evidence/2026-10-18-decision-reconciliation/.

> **Latest offline continuation, 2026-10-18:** [scope-admission draft contract](docs/ADR-024-SCOPE-ADMISSION-CONTRACT-EN.md) / [فارسی](docs/ADR-024-SCOPE-ADMISSION-CONTRACT-FA.md):38 standalone cases and3 detected mutants; no application/DB edits, all450 full-tested source hashes unchanged. Complete1112/16488 green remains valid;38 is NOT added to PHPUnit. Proposal only, ready_to_admit=false, UNADMITTED, no authority granted. Next gate: explicitly settle trusted issuer/actor policy, evidence authentication and correction/revocation/dispositions before any admission writer. No OrderGap/API change.

> **CURRENT CLOSEOUT — 2026-10-18:** [complete scope-source suite GREEN](docs/G01-SCOPE-FULL-SUITE-EN.md) / [گزارش فارسی](docs/G01-SCOPE-FULL-SUITE-FA.md): **1112 tests/16488 assertions,0 failures/errors/skips,exit0; all450 source and2 worker hashes unchanged**. JUnit1298.043810s. The scope-source complete-suite pending gate is CLOSED; pending/next-full statements below are superseded history. No app source changes this closeout. Observation remains UNADMITTED; readiness false/gross null; G01 OPEN, OrderGap/authority unchanged. Next: trusted versioned scope/topology admission, not repetition of the unchanged full gate. Standalone current-source recovery: `epcc-source-recovery-scope-full-2026-10-18.tar.gz`; earlier446-source bundle and overlay remain historical. Database on excluded cache disk, private socket/no TCP, stopped after closeout. No production migration/commit/push/PR.

> **CURRENT — 2026-10-18 scope-observation slice:** read [G01-SCOPE-OBSERVATION-EN](docs/G01-SCOPE-OBSERVATION-EN.md) / [FA](docs/G01-SCOPE-OBSERVATION-FA.md) FIRST. New450-file source:58 related PHPUnit tests/197 assertions and5 real contention scenarios PASS; **complete suite on this source NOT RUN/PENDING**. Earlier1098/16429 green below belongs only to preceding446-file source. New sidecar is always UNADMITTED; readiness false/gross null; no historical backfill, selector/OrderGap/authority change. Runtime data moved to excluded `/home/user/.cache/epcc-app-journal-pg-uo100j_u` after test tmpfs exhaustion; metadata identifies it, socket unchanged. Next: new-source complete gate, then trusted admission. Earlier status text below is history, not current-source verification.

# HANDOFF — EPCC Platform

**Living document. Update it at the end of every working session.**
Last updated: **2026-10-18 — COMPLETE current journal-source suite GREEN**. Read `docs/G01-JOURNAL-FULL-SUITE-VERIFICATION-{EN,FA}.md` and `docs/evidence/2026-10-18-g01-full/summary.json` FIRST. Branch arena/baseline-verification-2026-10-18, base0c54c7f plus uncommitted fixes/journal; no push/PR. **One complete configured Unit+Feature run:1098 tests/16429 assertions,0 failures/errors/skips,exit0; JUnit1238.612073s (~20m39s). All446 frozen source hashes and2 prior worker hashes unchanged before/during/after.** No app/model/migration/template/test source edited this turn; subsequent edits docs/evidence only. The previous pending FULL gate is CLOSED; do not rerun just because older headers say pending.

**NEXT DEVELOPMENT SLICE:** provenance-backed pinned scope manifest/topology admission and fail-closed effective selection under existing ADR-024 principles. Current NEW journal is already connected to real snapshots but constrained UNRESOLVED; OrderGapService still sums all accepted rows. No effective gross/board switch, legacy backfill, historical FK VALIDATE, MTO-authority redesign, usable/inspection/received-order semantics or ADR-032 approval. Integrated21-case pilot still unexecuted. Prior89/240 related +5 real-service contention scenarios remain SAME-source bounded evidence, not added to1098. Synthetic36/offline26/33 are separate.

Runtime for completed run: PHP8.4.26/PHPUnit12.5.35/PG17.11; actual epcc role non-super/non-BYPASSRLS/non-CREATEDB; private Unix socket /tmp/epcc-app-journal-sock-* port5545, disposable /tmp/epcc-app-journal-pg-*, no TCP/local trust TEST ONLY, integrity flags ON/WAL128/32MB. No concurrent DB suite or root runner. No app8000/demo5432/browser-smoke/frontend/jsdom/Docker/Actions result this turn. Composer/platform,351 scoped PHP lints,standards/conformance/screening and offline33/26 passed independently. Runtime may vanish after reset; no env/keys/deps/DB in refreshed source recovery.

The journal migration remains forward-only; new-row composite FK is NOT VALID for history; integrity trigger pins/restores only its inserted source context without RLS bypass; depth guard is NOT schema-owner authority. New schema's full suite is now proved together. No commit/push/PR/production migration. Recovery verifies current446 hashes against clean baseline; no complete app rerun on recovered copy.

<details><summary>Previous related-green/full-pending header (superseded)</summary>

Last updated: **2026-10-18 — REAL application NEW-acceptance chronology implemented**. Read `docs/G01-REAL-ACCEPTANCE-JOURNAL-{EN,FA}.md` and `docs/evidence/2026-10-18-g01-app/summary.json` FIRST. Branch `arena/baseline-verification-2026-10-18`, base0c54c7f, all changes uncommitted; no push/PR. **Current gate:89 related PHPUnit tests/240 assertions GREEN,0 failures/errors/skips;5 actual Laravel two-worker contention scenarios pass. Full configured suite on this CHANGED source NOT RUN/PENDING. Old1083/16385 green is pre-journal historical evidence, not current-source proof.**

**IMMEDIATE NEXT ACTION:** run the COMPLETE configured PHPUnit suite serially on the446-file tested-source-manifest, preserving hashes and making NO further app changes during the gate. Do not conflate the prior1083 result, bounded synthetic36, offline26/33 or related89. Runtime resets can remove deps/processes; rebuild isolated PG/PHP/locked vendor as needed, keep tests separate from demos.

Current implementation: new migration2026_10_18_100000 creates real clock/journal. Accepted-batch AFTER INSERT trigger atomically records exact NEW source tuple/ordinal. Source service locks project->document->revision; archive shares project lock. All journal entries constrained UNRESOLVED, never effective demand. New model/relation only; no board/API/authority switch. Deferred check tests source ACCEPTED+journal+nonempty rows; not full manifest/admission seal. Trigger temporarily pins/restores the already-inserted source tenant context, invoker only (no RLS bypass). Insert-depth check is integrity, NOT schema-owner security. Legacy row composite FK is NOT VALID for history, enforced for new rows. Migration down is forward-only and refuses destructive rollback. Expansion leaves old accepted batches without fabricated ordinals.

Changed vs old443 manifest: AcceptedMtoBatch.php and MtoAcceptanceService.php; added MtoAcceptanceJournal.php, new migration and15-case Feature test. Current manifest446 plus separate worker hashes. Related suites include MTO/staging/engineering/order-gap/archive/RLS/sargability. Initial harness issues (PDO commit exception type and masking UNIQUE fixture) fixed; final89 green. Real kernels test two commits, rollback, same-revision loser and both archive orderings, with pg_blocking_pids observation.

Runtime this turn: PHP8.4.26/PG17.11/psycopg3.2.6, real epcc non-super/non-BYPASSRLS/non-CREATEDB role; dedicated epcc_test only in /tmp/epcc-app-journal-pg-* with private Unix socket /tmp/epcc-app-journal-sock-* port5545/no TCP/local-trust TEST ONLY, integrity ON. Ignored env points to it. No demo5432 or app8000 server started; no customer data. Composer locked deps restored under .cache, may disappear after reset. Do not run PHPUnit and concurrency fixture preparation together; bootstrap purges seeded blobs. Root recovery tool was updated for the NEW446 manifest; archive excludes env/keys/deps/DB.


</details>

<details><summary>Earlier bounded persistence header (historical)</summary>

Last updated: **2026-10-18 — real PostgreSQL G01 persistence proof**. Branch `arena/baseline-verification-2026-10-18`, base `0c54c7f`, local/uncommitted; no push/PR. Start with `docs/G01-POSTGRES-PERSISTENCE-PROOF-{EN,FA}.md`. **36 real-PG prototype tests passed**, including5 verified two-connection contention/archival scenarios;3 deliberate schema regressions detected, then original36 green. Files `prototype/persistence/{schema.sql,test_postgres.py}`; synthetic one-scope source model ONLY, not Laravel migration or application integration. Existing443 baseline source hashes unchanged; old complete app1083/16385 green is historical, not a fresh full suite. G01 production board remains unfixed, ADR-032 unapproved, deferred MTO authority unchanged. Next useful slice: bounded NEW-acceptance journal adapter against real snapshots, with fail-closed scope/evidence contract and real app regression tests; do not enable board until unresolved-state consumers and missing interfaces exist.

Runtime this turn: restored PG17.11/psycopg3.2.6/PHP CLI only. Dedicated expendable PG cluster uses private Unix socket in /tmp/epcc-journal-sock-* with no TCP listener, local trust TEST ONLY, integrity settings ON. Runner explicitly drops/recreates ONLY epcc_journal_proof in an explicitly confirmed fresh /tmp/epcc-journal-pg-* cluster. Do not assume app8000/demo5432/Composer deps are live. No Laravel bootstrap or seed purge. Original+recovered-source proof and standalone26/33 tests verified; recovery refreshed without DB/credentials/dependencies.


</details>

<details><summary>Earlier baseline/design/backfill status headers (historical)</summary>

Last updated: **2026-10-18 (final-source green verification)**. Branch: `arena/baseline-verification-2026-10-18` (local/uncommitted; no push). Baseline `main@0c54c7f` plus preserved stabilization repairs. **Complete final-source PHPUnit run GREEN:1083 tests /16385 assertions /0 failures /0 errors /0 skipped, exit0**. All443 manifest source/test/template/reference files unchanged before/after the run. This closes the previous pending local full-suite gate; it is not production or EPCC-completeness certification. No application/migration/template/test-source content changed this session. New work:21-case piping pilot matrix (NOT executed end to end) and **PROPOSED, unapproved ADR-032** for physical attribution/completed-order semantics. Next recommended development slice: ADR-024 effective accepted-MTO revision/scope selection, whose domain principles are already accepted. Runtime:PHP8.4.26/PG17.11, test-only loopback5433 cluster (tmpfs, fsync/synchronous_commit/full_page_writes ON, non-superuser/non-BYPASSRLS role); separate seeded demoDB5432, actual Laravel preview8000. Start with `docs/FINAL-SOURCE-VERIFICATION-2026-10-18-EN.md`, `docs/PIPING-PILOT-ACCEPTANCE-MATRIX-EN.md` and `docs/evidence/2026-10-18-final/summary.json`. Older counts/limitations below are historical.

**Latest continuation — G01 design prototype:** `docs/ADR-024-EFFECTIVE-MTO-SELECTION-DESIGN-{EN,FA}.md`, standalone `prototype/domain/EffectiveMtoSelection.php`,33 executable cases passed +3 mutation probes detected. Existing443 source hashes unchanged; no Laravel bootstrap/database use, so demo blobs untouched. G01 production board remains unfixed; do not add33 to1083 PHPUnit tests. Next: reviewed migration/backfill/journal specification (legacy ordering/pinned topology/scope-set disposition/evidence revocation), then transactional adapter/RLS/concurrency tests and unresolved-state UI before board integration. MTO roles deferred; ADR-032 still unapproved. Recovery bundle refreshed to include prototype/design/evidence.

**Latest continuation — G01 migration/backfill specification (not applied):** see `docs/ADR-024-MIGRATION-AND-BACKFILL-SPEC-{EN,FA}.md`. Built offline `MtoBackfillPlanner` + `scripts/plan-mto-backfill.php`:26 tests pass,33 prior selection cases rerun pass,3 deliberate new mutations detected and4 CLI exit probes pass. Review candidates ALWAYS have ready_to_apply=false/writes_performed=0. Inventory-bound exact document chains; never infer a historical global ordinal or repair missing scope pins from current hierarchy. No DB exporter/apply adapter, production migration, admission/RLS/concurrency proof or board integration. Existing443 source content hashes matched. Runtime reset: restored PHP CLI only; do NOT assume prior app8000/PG5432 processes or Composer deps are running/present. No Laravel bootstrap/seed purge this turn. Next: isolated real-PostgreSQL persistence/constraint proof under the draft spec; authoritative topology/admission/scope-change interfaces and deferred MTO authority remain gating. No commit/push/PR. Recovery refreshed and verified against clean baseline.


</details>

<details><summary>Historical 2026-10-12 header (superseded)</summary>

Last updated: **2026-10-12** · Status: **prototype + working vertical slices** · Prior baseline: **872 passed / 3202 assertions** (+83 jsdom; +19 new order-gap-board assertions); Slice 4/5 targeted tests are pending runtime restoration. **Slice 6 (PO attribution + order gap) IMPLEMENTED**, the **ADR-012 HIGH defect (P-17) FIXED** (all 33 RLS tenant policies sargable + `RlsSargabilityTest`), and **piping phase P1 (ADR-008 PMS + branch table) IMPLEMENTED** — classes/rules/EXCLUDE constraint/publish gate/specificity resolver + `PipingClassTest`; all three status **IMPLEMENTED — awaiting runtime verification** on the owner's Laragon machine (`php artisan test`), per the "proceed without waiting for tests" instruction; RLS-fix mechanism EXPLAIN-verified against sandbox PostgreSQL 16.2. ADR-015 is the standing requirements record; sandbox dev-environment slice added (preview server + `scripts/run-tests.sh`); **rules 1–5 standing** (§0); full ~11,600-line documentation review completed with dated drift fixes (P-16) and escalated open items (P-15, P-17, P-18) — see `docs/IMPROVEMENT-PROPOSALS-EN.md`

</details>

This is the one file to read before touching anything. It answers: what is this,
what works today, what is deliberately missing, what will bite you, and what to
do next. Everything else is detail hanging off `README.md`.

**Companion record:** `CHAT-TRANSFER-HANDOFF-EN.md` / `CHAT-TRANSFER-HANDOFF-FA.md`
(repo root) carry the 2026-10-06 session-transfer handoff of the predecessor
`arena/roadmap-reconciliation` work (MTO staging + material-catalogue lineage).
They were fork-only files dropped by the PR #5/#6 history reconciliation and
restored from commit `a869114` on 2026-10-12 so that record is never lost again.


---

## 0. Standing operating rules (user-mandated, 2026-10-11)

Four rules the user set on 2026-10-11. They bind every session from here on;
violating any of them is a process defect, not a style choice.

| # | Rule | How it is enforced here |
|---|---|---|
| 1 | **Keep a handoff file and update it continuously.** | This file. Every session ends by updating the header line and appending a `## 10` session-log entry. Never let a session's findings exist only in chat. |
| 2 | **All documentation files are written in English and kept continuously updated.** | New/updated docs land in English. The bilingual FA/EN pairing rule still holds where an FA counterpart already exists (e.g. `MTO-REQUIREMENTS-FA/EN`), but the FA copy is never the sole record, and docs that drift from the code are fixed in the same change that moves the code. |
| 3 | **Requirements are produced and continuously updated as English ADR files.** | Every new requirement set gets an `ADR-EPCC-NNN` record (house style: status / date / depends-on / requirements / options / open questions / falsifiers), even while still PROPOSED — see ADR-015 for the Slice 6 requirements carried out of `MTO-REQUIREMENTS` §A5. When a requirement changes, amend its ADR in the same session; do not let requirements live only in chat or in prose docs. |
| 4 | **Maintain a development environment with a real display server and test execution.** | Three tiers: **(a)** Docker — `scripts/dev-up.sh` (PHP 8.4, PostgreSQL 17, Chromium, Vazirmatn) + `scripts/dev-test.sh`; **(b)** **Laragon on the owner's Windows machine — `docs/LARAGON-DEVELOPMENT-ENVIRONMENT.md`** (no Docker needed; same restore sequence, non-superuser `epcc` role, PDF export pending P-20); **(c)** the degraded-sandbox tier — `npm install` + `bash scripts/run-tests.sh` (runs every suite the machine can run and says loudly what it skipped) + `node scripts/preview-server.mjs` (zero-dependency live preview of the air-gap-safe prototype on port 8080, `/healthz` probe) + `bash scripts/sandbox-pg.sh start` (real PostgreSQL 16.2 in-sandbox, `epcc` non-superuser, `btree_gist` compiled from source). The PHP tier cannot enter these sandboxes — every acquisition route is network-blocked (php.net, packagist, getcomposer, apt mirrors, release-assets CDN) — so Laravel work runs on tier (a) or (b); that is stated, not hidden. Rule 5 of §4 stands: the Laravel suite never runs on SQLite. |
| 5 | **If a better alternative exists for any requirement, code or capability, say so — never stay silent.** | Every session reviews what it touched (and the adjacent code) for better options. Proposals are recorded with a status (`OPEN` / `ACCEPTED` / `REJECTED` / `BUILT`) in `docs/IMPROVEMENT-PROPOSALS-EN.md`. Cheap, safe fixes are implemented on the spot and marked `BUILT`; anything touching scope, schema or commercial terms waits for the user's decision. Silence is itself a defect: if a session genuinely finds nothing to improve, the session log says so explicitly. |

---

## 0a. 2026-10-06 MTO requirements reconciliation

User uploaded `epcc-platform-mto-docs-changes-2026-10-06.txt`, which is a ZIP package renamed as `.txt`. It contains complete replacement documentation files, not patches. It must **not** be blindly copied over this repository because it would contradict the current branch and could erase the real Piping Workspace / Test Pack status added in `f33c9a7`.

Reconciled MTO foundation requirements are now recorded in:

- `docs/MTO-REQUIREMENTS-FA.md`
- `docs/MTO-REQUIREMENTS-EN.md`

Important current-state rule: these MTO/MR/PMS items are **requirements/design only**, not implemented in the current branch unless code/migration/test is later added. Do not describe them as `BUILT`:

- `BaselineService`, `baseline_batches`, `baseline_discrepancies`;
- `PcfParser`, `ModelImportService`, `model_imports`;
- PMS services and NDT models mentioned in the uploaded package;
- PO attribution/order gap, or usable-material gap.

Slice 4 accepted immutable MTO snapshots are now built and are described below.

Accepted MTO principles for future work:

- approved MTO = gross procurement-planning quantity;
- model/isometric estimate = net engineering need;
- positive `net > gross` is a shortage and percentage tolerance must not suppress it;
- `mto_item_no` is not globally unique and cannot be the sole downstream key;
- accepted MTO rows must be immutable snapshots;
- acceptance is all-or-nothing per MTO document/sub-MTO revision;
- aggregation across accepted MTOs requires disjoint scope or exact immutable pair-level additivity evidence;
- MTO permissions/access design is deferred.

Material Library foundation was implemented after this reconciliation:

- `app/database/migrations/2026_10_06_100000_create_material_catalogue.php`
- `app/app/Models/MaterialItem.php`
- `app/app/Services/MaterialCatalogueService.php`
- `app/database/seeders/MaterialCatalogueSeeder.php`
- `app/tests/Feature/MaterialLibraryTest.php`

Built behavior: two-level catalogue identity shape (`project_id IS NULL` reserved for global/reference, project rows for project overlays), exact commodity-code lookup, alias-not-identity, controlled categories/status/source/unit, bilingual descriptions, RLS isolation, synthetic PH-14 piping catalogue.

Validation: `restore.sh` passed; `MaterialLibraryTest` passed 6 tests / 15 assertions; `SeedPathTest` passed 2 tests / 6 assertions; standards validator passed. Full Laravel suite was started and showed no failures before the sandbox timeout, but it did not complete.

Recommended next slice: implement MTO document/revision/staging (`mto_documents`, `mto_revisions`, `mto_staging_rows`) against the new material catalogue. MTO document/revision/staging was implemented after the material catalogue:

- `app/database/migrations/2026_10_06_110000_create_mto_staging.php`
- `app/app/Models/MtoDocument.php`, `MtoRevision.php`, `MtoStagingRow.php`
- `app/app/Services/MtoStagingService.php`
- `app/tests/Feature/MtoStagingTest.php`

Built behavior: versioned MTO document header, DRAFT revisions, editable staging rows, exact material resolution via `material_items`, validation states for unmatched material, alias-not-identity, unit mismatch, duplicate `mto_item_no`, invalid quantity, and project-participant RLS. This is the editable source for Slice 4 acceptance.

Validation: `restore.sh` passed; `MtoStagingTest` passed 8 tests / 21 assertions; `MaterialLibraryTest` passed 6 tests / 15 assertions; `SeedPathTest` passed 2 tests / 6 assertions; standards validator passed.

### Slice 4 — accepted immutable MTO snapshots

Added `accepted_mto_batches` and `accepted_mto_rows`, `MtoAcceptanceService`, and `MtoAcceptanceTest`. Only non-empty DRAFT revisions with all rows in `ACCEPTABLE` state are accepted. The service locks and validates the full revision, copies frozen source/material labels plus a source-row SHA-256 hash, marks the revision `ACCEPTED`, and performs every write in one transaction. A blocked or duplicate row leaves zero accepted rows and the revision in DRAFT. PostgreSQL RLS, immutable triggers, and model guards prevent later mutation/deletion; no MTO permissions were added.

### Slice 5 — net engineering estimate and gross/net comparison

Added `engineering_estimate_rows` and `EngineeringEstimateService`. Estimates preserve source type, revision/evidence and structured provenance, can remain provisional until linked to an `accepted_mto_row_id`, and use exact material/unit identity only. Linked rows report `SHORTAGE` when net exceeds gross, with no tolerance, or `DELTA_ONLY` when gross is equal to or greater than net. No waste, contingency, or cause is inferred.

### Slice 6 — PO attribution and the order gap

Added `purchase_order_items.material_item_id` (exact catalogue FK), `purchase_order_items.supersedes_id` (amendment lineage, partial unique — a line is replaced at most once) and `po_item_allocations` (explicit scope allocations, RLS-protected). Added `OrderGapService` (attribution by exact identity with unit-match validation, amend-as-new-row, allocate-with-cap, board) and `OrderGapController` + `procurement/order-gap` screen + four routes + sidebar entry (`project.ordergap`). Domain rules enforced: draft/cancelled POs count nothing (effective = `ISSUED`/`PARTIALLY_RECEIVED`), lineage heads only, zero tolerance, no proration (over-allocation refused), over-ordering is `OVER_PLAN`, unmatched lines stay in their own bucket, quantities computed as integer milli-units. `OrderGapTest` pins all of it including the non-participant RLS mirror and the HTTP screen. Status: IMPLEMENTED — awaiting runtime verification on the owner's Laragon machine (built without test execution per the 2026-10-11 instruction "فعلاً بدون انجام تست ادامه بده"; the Slices 4/5 precedent applies).

Next, in order: runtime verification on Laragon (`php artisan migrate:fresh --seed` + `php artisan test`) covering Slice 6, the P-17 RLS fix and piping P1; then ADR-008 build phase 3 (wire the PMS into component attach / joint compatibility) or piping P2 (equipment/nozzles) once the three ADR-010 questions are answered.

---

## 1. What this project is

A bilingual (EN/FA) modular platform for managing large industrial EPCC
projects — oil, gas, petrochemical, power. Sold per company on **Full** and
**Special** plans.

Four decisions are closed and should not be relitigated without a new ADR:

| Decision | Value | Where |
|---|---|---|
| Launch market | **Iran first.** On-prem/air-gap, Persian default, Jalali, IRR. International SaaS is a later phase, not parallel. | `docs/Iran-First-Market-Addendum.md` |
| Stack | **Laravel 13.31 + Filament v4 + PHP 8.4 + PostgreSQL 17** | `docs/ADR-003-Annex-A-Laravel-Evaluation.md` |
| Standards | **Selectable per project** — `ips-iran` (default), `iso`, `awp`. Chosen once at creation. | `standards-packs/` |
| AWP | **Deferred** to the international phase, kept in CI as a genericity guard. | `docs/ADR-002-Defer-AWP.md` |

> The requirements document is written **in English** by explicit instruction,
> even though project communication is in Persian. The *software* is bilingual.

---

## 2. Run it in 60 seconds

```bash
cd /home/user/epcc-platform/app
php artisan serve --host=0.0.0.0 --port=8000
```

After a sandbox reset the runtime is gone (source is not). Rebuild:

```bash
cd /home/user/epcc-platform && ./restore.sh     # idempotent, ~3-5 min
```

Sign in with any seeded account, password `password`:

| Email | Company | Plan | Good for demonstrating |
|---|---|---|---|
| `karimi@nioc.example` | NIOC-AFF (owner) | special | Everything unlocked; can create projects |
| `rezaei@pars.example` | EPC-PARS (contractor) | full | Authority limit blocks a 43.2B certificate |
| `hosseini@arvand.example` | EPC-ARVAND | **starter** | Locked modules / upgrade prompts |
| `tehrani@pmc.example` | PMC-TEHRAN | full | Consultant view |
| `former@pars.example` | EPC-PARS | — | **Disabled account** — gate 1 refusal |

All seeded emails end in `.example` and are generated by `AuthSeeder`; the login
screen lists them from the database, so they cannot drift out of sync.

---

## 3. What actually works today

**~40–45% of the specified system** (`docs/Prototype-Coverage-Map.md`, COV-EPCC-001).
Be honest about this in any demo.

- **Authentication** + the full **ARC §5 six-gate authorization pipeline**
  (AUTH → ENTITLEMENT → MEMBERSHIP → RBAC → ABAC → SoD, first failure wins).
- **Multi-tenancy enforced by PostgreSQL RLS**, not by `where` clauses. Scope is
  company × project.
- **Multi-project portfolio** and per-project certificate workspaces.
- **Project setup**: create a project, pick its standards pack, invite companies,
  staff people.
- **Release gates** driven by the framework-free standards engine.
- **Bilingual FA/EN with real RTL** and Jalali dates.
- **Entitlement-driven sidebar** (see §5).
- **Document register / CDE** (`doc`): rule-driven numbering, ISO 19650 states
  (WIP → Shared → Published → Archived) with suitability codes, revision
  control that archives rather than overwrites, **file attachments**
  (content-addressed, access-controlled), and the **review & comment cycle**
  that gates publication. See §5a and §5c.
- **Transmittals** (`doc`): formal multi-recipient issue, per-company
  acknowledgement with derived overdue tracking, and a bilingual ZIP package
  with a checksummed manifest. See §5d.
- **PDF export** of the MC certificate and the transmittal sheet, in both
  languages, via headless Chromium. See §5f.
- **QA/QC — punch list & Mechanical Completion** (`qaqc`): subsystem walkdown,
  A/B/C categories, a six-state lifecycle with independent verification, and the
  **MC gate** with its employer-approved exception. See §5e.
- **Filter + sort on every register table** (§5b), Persian-digit aware.

**Acceptance journey 3 (engineering document flow) now runs end to end**:
create → attach → share → review with blocking comments → dispose → publish →
transmit → acknowledge — **including PDF output**, which was the last gap.

**Acceptance journey 5 (mechanical completion) now runs end to end**: walkdown →
raise → assign → fix → verify → close → certificate, with the A-item gate
refusing issue and the owner's recorded exception the only way past it.

Deliberately absent: full-text/OCR search, offline sync, integrations, and the
installer. PDF export **is built** (§5f) — this list used to claim otherwise and
was corrected 2026-10-11 (rule 2). PROCUREMENT exists as a base chain only
(requisition → PO → inspection → warehouse → site); HSE and SCHEDULE remain
zero-page.

---

## 4. Architecture rules you must not break

These were each learned by fixing a real defect. Full list in
`docs/Spike-RLS-Results.md` (12 standing rules).

1. **`SET LOCAL` requires an open transaction**, otherwise tenancy fails **open**.
2. Use **`FORCE ROW LEVEL SECURITY`**; table owners bypass RLS otherwise.
3. **`NULLIF(GUC,'')`** — `SET LOCAL` leaves the GUC as `''` after commit.
4. **Audit by actor**, not by subject.
5. **Never RLS-test on SQLite.** It has no RLS; the test would pass and prove nothing.
6. **Participation ≠ membership.** `project_company` is the commercial fact RLS
   keys on; `project_memberships` is the personal grant. Read queries filter on
   **both** (ARC §5.4).
7. **Tenant state is transaction-scoped.** Never a plain `SET`.
8. **An ungated certificate is not a cleared one** — it is unexamined.
9. **Middleware order is load-bearing** — `auth` before `tenant`.

---

## 5. The sidebar is an authorization surface

`app/Support/Navigation.php` builds the menu from the *same* gates the pipeline
enforces, so the menu can never offer something the pipeline then refuses.
Three states, and conflating any two is a real defect:

| State | Meaning | Rendered as |
|---|---|---|
| `available` | Entitled and built | A real link |
| `planned` | Entitled, **not built yet** | Inert, "Soon" |
| `locked` | **Not in the company's plan** | Inert, "Upgrade" — the in-product upsell surface |

Telling a customer to *upgrade* for a module they already pay for is a billing
complaint; telling them "soon" for something they never bought is a lost sale.
Keep the distinction.

- Locked/planned items render as `<span>`, never `<a>` — no href means they
  cannot be clicked, middle-clicked or crawled into a denial.
- Icons are **inline SVG**: the preview iframe has no network, so icon fonts and
  CDNs silently fail.
- Injected by a **view composer** (`ViewServiceProvider`), not by each
  controller — otherwise every new screen must remember the sidebar, and the one
  that forgets renders a page with no way out.
- `PLANNED_MODULES` in `Navigation.php` is the list to shrink as modules land.

**Collapse / expand.** Desktop toggles `body.rail` (a 60px icon rail); mobile
toggles `body.drawer` (off-canvas, closed by the scrim, Escape, or following a
link). Class names match `prototype/index.html` deliberately, so the two cannot
drift. Three non-obvious constraints:

- The burger lives in `partials/topbar.blade.php`, **outside** the sidebar. A
  control that collapses the sidebar must survive the collapse — inside the
  drawer it would slide off-canvas and strand the user.
- The collapsed state is restored **in `<head>`, before first paint**. This app
  is server-rendered, so every click is a new document; restoring it at the end
  of the body makes the sidebar flash open on every navigation, which reads as
  a broken toggle. The class goes on `<html>` first, then mirrors onto `<body>`.
- The desktop rail state must be **neutralised inside the mobile media query**,
  or the off-canvas panel slides in 60px wide showing icons and nothing else.
- **`max-width` and `overflow` do nothing on an inline box.** Anything collapsed
  by the rail must be `inline-block` (or block) first. The language switch is an
  `<a>` — inline by default — so when it inherited the collapse rules it laid
  out at zero usable width and disappeared from the *expanded* sidebar.
- **`display:none` cannot be animated.** It is a discrete property, so hiding
  labels with it makes the rail snap however smooth the container is. Collapse
  them with `max-width`/`opacity` (inline) and `height`/`padding` (block), and
  keep `overflow-x:hidden` on the panel so text clips instead of scrolling.
- The width transition must live **outside** the mobile media query. The
  original one only applied to `transform` on mobile, so desktop never animated.
- `prefers-reduced-motion` is honoured — motion is a vestibular accessibility
  issue, not a taste preference.
- The script **must wait for `DOMContentLoaded`.** The sidebar renders before
  the content column (flex order), so the script is emitted *before* the button
  it wires up; running immediately made `getElementById` return `null` and the
  script bail at its own guard — the button looked perfect and did nothing.

Behaviour is covered by `app/tests/Browser/sidebar-toggle.test.cjs` (17
assertions, jsdom). PHPUnit never runs JavaScript, so the Laravel tests can only
assert the markup is present — run the jsdom test after touching the script.

> **Never hand-run a script the page already ships.** The first version of that
> test re-evaluated the sidebar script *after* parsing had finished, which found
> the button and passed 17/17 while the live page was completely dead. Let the
> parser execute it in natural document order (`beforeParse` to stub
> `matchMedia`, then wait for `load`). A test that bypasses the real execution
> order proves nothing.

---

## 5a. Document register / CDE

`app/Support/CdeState.php` is the state machine; `app/Services/DocumentRegister.php`
holds the rules; `documents` + `document_revisions` are the tables.

Two rules are load-bearing and are enforced **server-side**, not by hiding
buttons:

- **WIP cannot jump to PUBLISHED.** Skipping SHARED skips review — a drawing
  reaching construction unchecked is the exact failure ISO 19650 exists to
  prevent. SHARED → WIP *is* allowed: review rejecting a drawing is normal.
- **ARCHIVED is terminal.** Superseding is a record, not an erasure, so a new
  revision archives the old one and history is kept.

Suitability codes are validated against the target state (S-codes for SHARED,
A/B-codes for PUBLISHED); only WIP may carry none.

> **When adding a tenant table, copy the policy from migration `110000`, not
> `100100`.** The document register shipped with the *original* policy and had
> two defects at once: no `NULLIF(GUC,'')`, and no project scope — so an owner
> scoped to PH-14 still saw its own KISH-1 rows, because those are also "its
> own". Company identity is not a project scope (standing rule 7).

> **Eager-load RLS relations inside `runAs()`.** A lazy `->currentRevision`
> evaluated after the scope closes runs with no bound tenant and returns NULL.
> The row is invisible, not missing — fail-closed, but it looks exactly like a
> broken write.

### 5a.1 Attachments (FR-DOC-01/02)

`DocumentFileStore` owns the bytes; `FileType` owns what is acceptable.

- **Content-addressed storage.** The path is
  `documents/{project}/{ab}/{cd}/{sha256}.{ext}` and contains **no user input
  at all**. Path traversal is designed out rather than filtered out. The hash
  doubles as the integrity record (FR-AUD-02) and de-duplicates re-issues.
- **Allow-list, never a deny-list.** A deny-list is a list of the attacks
  someone already thought of. SVG and HTML are refused outright: documents to a
  user, executable script to a browser.
- **The stored MIME comes from our table, keyed by extension** — never from the
  client's `Content-Type`.
- **Only PDF/PNG/JPEG are served `inline`**; everything else is `attachment`,
  plus `nosniff` and a restrictive CSP. Inlining an arbitrary upload is how a
  stored file becomes stored XSS.
- **Nothing is on a public disk.** Every byte is streamed through
  `DocumentController@download`, so downloads pass auth → entitlement →
  membership → RLS exactly like the register screen.
- **Files attach only to WIP/SHARED revisions.** A published revision is a
  matter of record; the way to change it is a new revision.
- **Detach never deletes shared bytes** while another revision references the
  same hash.

> **PHP's upload limit fails SILENTLY.** Exceeding `upload_max_filesize` yields
> an `UploadedFile` that is merely *not valid* — no exception. The stock 2 MB
> default rejects nearly every real deliverable. `restore.sh` now writes
> `/etc/php/8.4/cli/conf.d/99-epcc.ini` (100 MB), and the store reports the
> server limit by name instead of "unknown error".

### 5a.2 The CDE must actually be common

> **Found by live verification, not by tests.** The document tables shipped
> with the standard tenant policy — own rows, plus the employer sees all. That
> is right for a payment certificate and **wrong for a document register**: a
> PMC holding `doc.view`, a full participant on the project, opened the
> register and saw *"no documents"*. Consultant, MC and TPI were all equally
> broken. Every unit test passed, because they all asserted the old model.

Migration `130000` makes **the CDE state the sharing boundary, not company
ownership**:

| Row | Author | Other participants | Employer | Non-participant |
|---|---|---|---|---|
| WIP | ✅ | ❌ | ✅ | ❌ |
| Shared / Published / Archived | ✅ | ✅ | ✅ | ❌ |

WIP stays private because a contractor will not adopt a system that exposes
half-drawn work to the client. `WITH CHECK` is deliberately **unchanged** —
read widely, write narrowly.

The employer keeping sight of WIP is a **deliberate, reversible** choice (it
matches how the owner is treated everywhere else here, and Iranian employer
organisations expect it). Strict ISO 19650 would hide it; that change is
confined to one branch of the policy.

Verified live across five roles on PH-14: author 5 docs / 1 WIP, consultant
4 / 0, employer 5 / 1, rival contractor 4 / 0, non-participant 404.

## 5b. Table filter + sort (FR-UX-04)

`resources/views/partials/tabletools.blade.php`. Opt a table in with one
attribute; everything else is discovered from the markup:

```blade
<table data-tt>
  <thead><tr>
    <th data-sort="text">Number</th>
    <th data-sort="num">Amount</th>
    <th data-sort="text" data-facet>State</th>
    <th>Actions</th>            {{-- no data-sort: not sortable --}}
  </tr></thead>
```

Gives every data table a search box, a dropdown per faceted column, a live
row count, a reset button, and click-to-sort headers (asc → desc → **back to
the server's order**; without that third state there is no undo).

**Two escape hatches, both load-bearing:**

| Attribute | On | Why |
|---|---|---|
| `data-sortkey` | `<td>` | Sort by something other than the displayed text. |
| `data-facet-value` | `<td>` | Group by something other than the displayed text. |

Where they are used and what breaks without them:

- **CDE state** → `data-sortkey="{{ CdeState::ordinalOf(...) }}"`. Sorting the
  *label* is wrong in both languages: alphabetically "Archived" precedes "WIP",
  and the Persian labels collate differently again. The register is read as a
  pipeline and must sort as one. `CdeState::ordinalOf()` is the single source
  of that order; an unknown state sorts last rather than throwing, because a
  sort must never be the thing that takes a page down.
- **Money** → `data-sortkey="{{ $c->net_amount }}"`. The cell renders
  `۴۳٬۲۳۴٬۵۰۰٬۰۰۰`; sorting that as text is nonsense.
- **Gate verdict** → `data-facet-value`. The cell shows "Blocked" *followed by
  every failure reason*, so faceting on raw text would give each blocked row
  its own dropdown entry. A filter with one row behind every option is not a
  filter.

> **Persian digits are folded before matching.** Typing `14` finds `۱۴-P-۱۲۰۱`
> and vice versa. Arabic yeh/kaf are folded to Persian, ZWNJ to a space, and
> diacritics dropped — a user on an Arabic keyboard, or pasting from an older
> Windows document, must still find the row.

**Progressive enhancement.** The toolbar is *built by script*. The server never
ships a search box that would be dead if the script failed — a plain, complete,
working table degrades to exactly that. The script sits in `<head>` and so
carries the same `DOMContentLoaded` guard as the sidebar (§5); without it,
`init()` finds no tables and fails silently.

**Filtered rows use the `hidden` attribute**, not a class, so they leave the
accessibility tree too. The row count is `aria-live="polite"`; sortable headers
are real `<button>`s with `aria-sort`.

> **Client-side, deliberately.** These are one project's rows — tens, not tens
> of thousands. A server round-trip per sort would be slower, lose scroll
> position, and thread every filter through the RLS query. **When a register
> outgrows this** (the SRS assumes 20k documents) the answer is server-side
> paging behind the same controls, not a bigger script.

Guards: `tests/Feature/TableToolsTest.php` (10 tests) + `tests/Browser/
table-tools.test.cjs` (44 assertions fa / 41 en). The PHPUnit sweep walks
**every** Blade view and fails if any `<table>` with a `<thead>` lacks
`data-tt`, so a future screen cannot ship an unfilterable table.

## 5c. Review & comment cycle (FR-ENG-06)

`CommentCategory`, `CommentDisposition`, `ReviewCycle`, `ReviewComment`,
`documents/review.blade.php`. Implements acceptance journey 3.

**The rule the module exists for: an open blocking comment prevents
publication.** Without it a comment sheet is a suggestion box, and a drawing
with an unanswered Code 1 reaches the site.

| Category | Blocks publication | Needs an answer |
|---|---|---|
| HOLD, CODE1, CODE2 | **yes** | yes |
| CODE3 | no | yes |
| CODE4, INFO | no | no |

`CommentCategory::blocksPublication()` is the single source of that truth;
adding a category is a one-line change, not a hunt through controllers.

**The gate lives in `DocumentRegister::transition()`**, not the controller —
the API, the importer and any future bulk action all pass through that method,
and a gate that only exists on one screen is not a gate. The refusal *names the
comments* ("comments 1, 4, 5"), because "blocked by 3 comments" sends the user
hunting.

Other enforced rules, each mutation-tested:

- **The originator cannot review its own document.** Self-approval is the
  control the owner is paying for.
- **Only the originator may dispose.** A reviewer answering its own comment is
  marking its own homework.
- **Rejecting requires a written justification.** "Rejected" with no reason is
  how a review cycle becomes a dispute, and that dispute is eventually read by
  a lawyer.
- **Only SHARED revisions are under review.** WIP has not been offered;
  PUBLISHED is answered by a new revision, not a late comment.

> **This table breaks the tenant pattern deliberately.** A comment has TWO
> companies with a claim: `company_id` (the reviewer who wrote it) and
> `originator_company_id` (who must answer). Keying the policy on `company_id`
> alone would stop the contractor answering comments on its own drawing —
> i.e. the entire workflow. Reads are open to every project participant
> (hiding comments from other reviewers is why reviews go round three times);
> writes are restricted to those two companies, with per-column rules in the
> service.

> **`FOR UPDATE` is not allowed with aggregate functions.** Sequence allocation
> locks the parent `document_revisions` row, not `max(seq)` — PostgreSQL
> rejects the latter outright. Parallel multi-reviewer is a stated requirement,
> so two reviewers colliding on `(revision_id, seq)` is the normal case.

> **A DB column default is NOT reflected back into the model.** `disposition`
> defaulted to `'PENDING'` in PostgreSQL, but the freshly created object held
> `NULL`, so `isPending()` and `isBlocking()` returned the wrong answer on a
> brand-new comment while the row was correct. Set defaults explicitly in the
> service. Caught by a test asserting the in-memory object.

## 5d. Transmittals (FR-ENG-05)

`TransmittalPurpose`, `Transmittal`, `TransmittalRecipient`, `TransmittalItem`,
`TransmittalService`, `TransmittalPackager`, `transmittals/index.blade.php`.
Completes acceptance journey 3: a document is drafted, reviewed, published and
now **formally issued**.

**A transmittal is evidence.** Its value in a delay claim is that it proves
*what* was sent, *to whom*, *when*, and *when they acknowledged it*. Every rule
below protects one of those four facts.

| Purpose | Acknowledgement | Response due |
|---|---|---|
| FOR_REVIEW | required | 14 days |
| FOR_APPROVAL | required | 10 days |
| FOR_CONSTRUCTION | required | 7 days |
| FOR_INFORMATION | not required | no clock |

- **Numbering** `{PROJECT}-TR-{SEQ:4}`, unique per project, DRAFT → ISSUED.
- **Issued letters are immutable.** You cannot add a document to a letter that
  has already gone out; you send a second letter. Editing a sent letter is
  forging the record.
- **Items point at a `revision_id`, never a `document_id`**, and snapshot
  `number / revision / state / suitability` *as at issue*. The revision moves
  on afterwards; the letter must still read as it did on the day.
- **WIP cannot be transmitted** — WIP has not been shared, so it cannot be
  formally issued.
- **Acknowledgement is recipient-only, self-only, and idempotent** — a second
  click never overwrites the first timestamp, because that timestamp is the
  entire evidentiary value of the row.
- **Overdue is derived, never stored.** A stored flag is wrong the moment the
  clock passes it and nobody ran the job.
- **ZIP export**: entries `{number}_Rev{rev}_{sanitised}`, plus `MANIFEST.csv`
  (SHA-256 per file) and a bilingual `TRANSMITTAL.txt` cover sheet.

> **`MANIFEST.csv` is written with a UTF-8 BOM.** Without it, Excel on a Persian
> Windows install renders every Farsi filename as mojibake, and the manifest is
> the one artifact a claims consultant actually opens.

> **RLS is sender ∪ recipients ∪ employer — and only once ISSUED.** The first
> cut gated recipiency alone, so an addressee (and the employer) could read a
> letter the sender had not yet sent, while the sender was still changing the
> distribution list. A draft is not correspondence. Caught by probing the model
> directly rather than trusting the index page, which had looked correct
> because the seeded recipient was also the employer.

> **A policy on a child table MUST NOT select from its parent.** Gating
> `transmittal_recipients` on `transmittals.issued_at` deadlocked the pair —
> the parent's own policy reads the child — and PostgreSQL aborts with
> `infinite recursion detected in policy`. `issued_at` is therefore
> **denormalised onto both child tables by trigger** (`AFTER UPDATE` on the
> parent to propagate, `BEFORE INSERT` on each child to inherit). The trigger,
> not the service, owns the guarantee, so an importer or a DBA cannot bypass it.

> **A third party sees nothing.** A contractor must not read a rival's
> correspondence on the same project — verified live: EPC-SAHAND, a full
> participant, sees an empty register and gets a 404 on the ZIP.

## 5e. QA/QC — punch list & Mechanical Completion (FR-COM-04/05)

**Category letters are A / B / C in BOTH languages** (user decision,
2026-09-11). The punch category is a contractual term that appears in the same
form on drawings, in the MC procedure and in correspondence with vendors who do
not read Persian, so الف/ب/ج invented a second vocabulary for one thing. Only
the explanatory prose after the dash is translated
(`A — مانع تکمیل مکانیکی`). This also covers the gate message and the MC
certificate PDF. Enforced by `tests/Feature/PunchTableTest.php`.

`PunchCategory`, `PunchState`, `Subsystem`, `PunchItem`, `McCertificate`,
`PunchListService`, `McCertificateService`, `PunchController`,
`punch/index.blade.php`. Completes **acceptance journey 5**.

**The one rule the module exists for:**

> An MC certificate cannot be issued while a category-A punch item is open,
> *unless* an Owner-approved exception is recorded.

Both halves matter. A gate with no legitimate override gets bypassed outside
the system, which is worse than no gate — so the override exists, but it is
**employer-only**, needs a **written reason**, and stores a **`jsonb` snapshot
of the items open at that moment**. The snapshot is evidence: re-deriving it
later would show today's open items, not the ones the owner actually accepted.
`test_the_exception_snapshot_does_not_drift_when_items_close_later` pins that.

**Where the rules live**

| Rule | Home | Why there |
|---|---|---|
| Which category blocks which milestone | `PunchCategory::blocksMechanicalCompletion()` / `blocksReadyForStartUp()` | A client renaming a category is a different edit from a client changing a rule, so labels are separate from the gate |
| Legal lifecycle moves | `PunchState::canTransition()` | One table, not scattered `if`s |
| Who may do what | `PunchListService` | The API, an importer and a mobile client must not each invent their own version |
| The gate itself | `McCertificateService::issue()` | Single choke point |

`RAISED → ASSIGNED → FIXED → {VERIFIED | REJECTED}`, `REJECTED → ASSIGNED`,
`VERIFIED → CLOSED`. **`isOpen()` is true for everything except `CLOSED`** —
`VERIFIED` deliberately still blocks, because verified means the inspector
agrees, while closed means the owner accepted it into the record.

Role rules, from the SRS §4.1 matrix row "Punch item (A)": MC/TPI/PMC/OWN raise,
the responsible contractor fixes, **anyone but the responsible company** verifies,
**only the employer closes** and **only the employer grants exceptions**.

**Traps this cost:**

- **The fixture had no management contractor.** Journey 5 needs a verifier that
  is neither the contractor nor the owner, so `MC-KARAN` (`tenant_type = MC`,
  user `jafari@karan.example`) was added. `SeedPathTest` asserts 8 companies now.
  **Note the meaning of MC — see §5h; it is not "Mechanical Completion".**
- **`consultant` had no `punch.*`**, so the PMC got a 403 on a register the SRS
  says it may verify. Capability decides *reach*; the service decides *actions*.
- **State must be set explicitly on create.** A DB default is not reflected back
  into the model, so `isOpen()` would read `NULL` on a freshly created row.
- The seeded subsystem is **deliberately blocked** (2 open A-items). A demo that
  opens on a green screen never shows the feature that was sold.


### A certificate must not rewrite its own evidence

An issued MC certificate is a statement about a **moment**: what was accepted,
on what basis, by whom. Anything on it that is recomputed at render time is not
evidence — it is a live report wearing a certificate's letterhead.

The PDF was computing "total / closed / open category-A" from the punch list on
every download. Those three numbers are the technical justification for the
handover. Found by downloading the same certificate twice:

| | at issue | a few closures later |
|---|---|---|
| Closed | 2 | **3** |
| Open — category A | 2 | **1** |

Same number, same URL, same ISSUED certificate, different facts. And the drift
always runs in the **flattering direction**: a certificate issued over two open
A-items quietly repairs itself into one that looks nearly clean, erasing
exactly what an auditor or an arbitrator would be looking for. The waived-items
list beside it was already correct, because `exception_items` is a stored jsonb
snapshot — so the page was half snapshot, half live query, and the half that
drifted was the summary.

Fixed with `mc_certificates.punch_summary` (jsonb, nullable), written by
`McCertificateService::issue()` and read through
`McCertificate::punchSummary($items, $openBlocking)`. **Nullable and
state-dependent on purpose:** a DRAFT keeps showing live numbers, because a
draft's job is to tell whoever is deciding whether to issue where the subsystem
stands *right now*. Issuing is what freezes it.

The subsystem register on `/projects/{p}/punch` still shows live closure
percentages, and that is correct — it is a working view of the site, not a
record of an event. **The rule is not "snapshot everything", it is "snapshot
what a document asserts about a moment".**

`punchSummary()`'s `isIssued()` check is currently unreachable through the UI
(nothing writes a snapshot before issue), so removing it changes no page and no
end-to-end test — mutation **M108** survived until the contract was asserted on
the model directly. It is kept rather than deleted because it is protecting a
real future mistake: the day anything writes a snapshot earlier, a draft would
silently start reporting a stale position to the person deciding whether to
issue.

## 5f. PDF export (headless Chromium)

`PdfRenderer`, `resources/views/print/{layout,mc-certificate,transmittal}.blade.php`,
`PunchController::certificatePdf()`, `TransmittalController::sheet()`.
**This retires the PDF half of risk IR-R2**, which the ADRs had flagged as the
highest-risk item in the stack and required a P0 spike for.

**Why a browser and not a PHP library.** Persian is a joining script: every
letter has up to four contextual forms, ZWNJ is semantic (`پیش‌نویس` is not
`پیشنویس`), and Latin document numbers sit inside RTL sentences under the bidi
algorithm. HarfBuzz gets this right. PHP PDF libraries mostly do not, and when
they fail they fail **silently** — a page that looks plausible to a
non-Persian reader and is gibberish to the client. mPDF's own maintainers point
users at headless Chrome for this reason.

**Verified, not assumed.** Rendered PDFs were rasterised and read: joining
forms, ZWNJ, bidi-embedded Latin tags, Persian digits and Jalali dates are all
correct in both languages. `pdffonts` confirms Vazirmatn is **embedded and
subsetted**, not substituted. ~1.05 s per document.

**Dependencies** (`restore.sh` installs all three): `chromium`,
**`fonts-vazirmatn`** — without it PDFs still generate, as boxes — and
`poppler-utils` for the tests. Chromium is **~315 MB and must go in the
air-gap bundle**; it runs with networking disabled.

**Design decisions worth keeping:**

| Decision | Reason |
|---|---|
| `PdfRenderer` takes finished HTML and knows nothing about certificates | Documents stay ordinary Blade views that can be previewed in a browser |
| Validates `%PDF-` magic bytes **and** a size floor | Chrome can exit 0 having written a truncated file; serving that as a signed certificate is worse than an error |
| Recursive scratch cleanup | Chrome treats the scratch `HOME` as real and mints `.cache`/`.config`/`.local`; plain `rmdir()` fails silently and leaks |
| Binary list is constructor-injectable | Lets an operator point at a custom Chrome, and lets tests simulate a host without one |
| **ZIP degrades, `/sheet.pdf` does not** | The ZIP's job is delivering drawings, so a missing renderer only drops the cover page. On the standalone endpoint the PDF *is* the deliverable, so it 503s |

**Traps this cost:**

- **`position: fixed` footers do not pin per page in Chrome's print path.** The
  footer landed across the top of page 2, over the table header. Footers now
  flow as normal content at the end of the document.
- **Chrome creates files inside the scratch `HOME`**, so cleanup must recurse.
- **`pdftotext` inserts bidi control characters** (U+202A–U+202E, U+200E/F)
  around RTL runs. They are invisible and they break naive substring matching,
  so the test helper strips them before asserting. A raw `assertStringContains`
  on Persian will fail for the wrong reason.
- The print views are exempt from the `data-tt` sweep test — a PDF has no
  JavaScript and no user to click a filter. The exemption is scoped to
  `views/print/` and was mutation-tested to confirm it still catches screens.


### Shell contract (read before adding a screen)

Every screen that shows the sidebar MUST nest exactly like this:

```blade
<body>
<div class="app">          {{-- flex row --}}
@include('partials.sidebar')   {{-- must be INSIDE .app --}}
<div class="wrap">         {{-- content column, flex:1 --}}
@include('partials.topbar')    {{-- must be INSIDE .wrap --}}
  ...page...
</div>
</div>
</body>
```

Two failure modes, both reported by the user on 2026-09-11:

- **Sidebar outside `.app`** — it stops being a flex sibling, so the content
  column starts at x=0 and slides underneath it.
- **Topbar as a direct child of `.app`** — it becomes a THIRD column next to
  the sidebar instead of a bar above the content, and the collapse button
  disappears from where the user expects it.

The toggle (`id="sb-burger"`) lives in the topbar, deliberately outside the
sidebar: a control that collapses the sidebar must survive the collapse, and on
mobile the sidebar is off-canvas entirely. `ShellStructureTest` enforces all of
this per screen. The view composer supplies `$user`, `$acting`, `$nav`, `$plan`
and `$langSwitchUrl` as **defaults**, so a new screen only needs the markup
above plus its view name in `ViewServiceProvider::SHELL_VIEWS`.


## 5g. Vendor transmittals — the second stream (FR-ENG-05b)

Two letters share a shape but are not the same thing:

| | Counterparty | Meaning |
|---|---|---|
| `CONTRACTOR` — `{PROJECT}-TR-{SEQ:4}` | EPC → Employer / Consultant | the contractual submission; starts a review clock, evidence in a delay claim |
| `VENDOR` — `{PROJECT}-VTR-{SEQ:4}` | Vendor → EPC | supply-chain correspondence; the Employer is not a party |

**User decisions (2026-09-11), all four confirmed before building:**
1. **Vendors do not log in.** The EPC's document controller records what the
   vendor sent. So `company_id` (the tenant column and RLS anchor) stays the
   EPC, and `vendor_company_id` names the originator. Conflating the two would
   hand a vendor tenant the contractor's whole register the day vendors get
   logins.
2. **Separate number series AND a separate screen** — two independent counters
   scoped by `kind`, and `/projects/{code}/vendor-transmittals`.
3. **Roll-up must be traceable.** `transmittal_items.source_item_id` is a
   nullable self-reference, so `vendor letter → EPC letter → client` survives.
4. Document type: existing `{TYPE}` codes are enough for now.

**Where the rules live:** `TransmittalService::draft()` (validation +
per-stream numbering), `TransmittalService::rollUp()`, two CHECK constraints
(`kind` is known; vendor fields agree with `kind`), and the RLS policy.

**The non-obvious part — separation must hold in the DATA, not just the UI.**
The Employer's original blanket clause ("owner sees every issued letter in the
project") silently exposed vendor letters. A filter on screen with a leak
underneath is not separation, so the employer catch-all is now
`kind = 'CONTRACTOR'` only. The Employer still sees a vendor letter when
**named as a recipient** (an explicit act of sharing) and always sees vendor
documents **rolled up** into a contractor submission. Migration
`2026_09_11_130000_...`; all three properties are pinned by tests.

**Traps:**
- `rollUp()` copies the snapshot from the **source item**, never re-reading the
  document. What the EPC forwards is what the vendor actually sent; if the
  vendor has since issued Rev C that is a different letter, not a silent
  upgrade.
- Roll-up is **idempotent** — rolling the same letter up twice adds nothing.
- Only an **issued** vendor letter can be rolled up, and only into a **draft
  contractor** letter.
- A company **cannot be its own vendor**, or a contractor could file its own
  submissions in the vendor stream and drop them from the client-facing count.

## 5h. "MC" means two different things — read this before using it

**This was wrong in the codebase for months and no test could see it.**

| Abbreviation | Meaning | Kind of thing | Where it lives in code |
|---|---|---|---|
| MC | **مدیریت پیمان** — Management Contractor | a **company type** | `App\Support\TenantType::MC`, `companies.tenant_type`, `MC-KARAN` |
| MC / MCC | **تکمیل مکانیکی** — Mechanical Completion | a **milestone** | `McCertificate`, `mc_certificates`, `PunchCategory::blocksMechanicalCompletion()`, `{PROJECT}-MCC-{SEQ}` |

A **management contractor** is a firm the *employer* engages to administer the
contract with the contractor on the employer's behalf: supervising execution,
checking progress and quality, verifying what the contractor claims, signing
off milestones. It is a standard Iranian contracting arrangement with its own
fee structure. **Mechanical Completion** is the point at which a subsystem is
built and ready for pre-commissioning. Same two letters, unrelated concepts.

The seeder, two Blade views, the SRS role table and the coverage map all
described the `MC` *tenant type* as "Mechanical Completion body". The company
was even named "Karan Completion Services / خدمات تکمیل کاران".

**Why nothing failed.** A tenant type only has to be a *matching string*. The
role rules (`PunchListService::VERIFIER_TYPES` / `RAISER_TYPES`) were correct —
an employer's contract administrator *should* raise and verify punch items —
so every behavioural test passed. The label is decoration to the code and
load-bearing to the user. Only a human reading the screen could catch it, and
that is exactly what happened.

**What now prevents a recurrence:**

- `App\Support\TenantType` — the nine SRS types in one place, with bilingual
  labels and a long comment on the MC collision. The codes were previously
  loose strings in five files.
- Migration `2026_09_11_140000_constrain_tenant_type.php` — a CHECK constraint
  so an importer or a `psql` session cannot invent a tenth type that the role
  rules would then silently refuse to recognise.
- `tests/Feature/TenantTypeTest.php` (7 tests) — asserts the words, not just
  the behaviour: that MC's label is «مدیریت پیمان», that the string
  "mechanical" does **not** appear in it, that the two contract-role views
  agree, that every type has labels in both languages, and that the CHECK is
  neither too loose nor too tight. Mutations M75–M77 confirm all three bite.

**The lesson worth keeping:** behavioural tests cannot see a wrong name. If a
term is contractual vocabulary the customer will read on screen, pin the term
itself in a test.

## 5i. The Filament admin panel (§9 item 1)

`/admin`, provider `app/Providers/Filament/AdminPanelProvider.php`.
Currently five resources: **Document**, **PunchItem**, **Transmittal**,
**User**, **Subsystem** (9 admin routes). Filament v4 + Livewire, discovered
from `app/Filament/`.

**TENANCY IS THE LOAD-BEARING PART.** Filament builds its OWN middleware stack
in the panel provider; the generated one knows nothing about `BindTenant`. By
standing rule 1, `SET LOCAL` outside a transaction is silently discarded, so a
panel without it does not merely lose isolation — it never establishes it.

What that actually looked like, measured rather than assumed:

| | with no `BindTenant` | with `BindTenant` |
|---|---|---|
| sees another tenant's rows | no | no |
| sees its OWN rows | **no** | yes |

RLS was failing **closed**, so "does not leak across tenants" passed while the
panel was simply broken and empty. **Only the mirror test told them apart.**
Never assert isolation without also asserting visibility — a screen that shows
nothing passes every leak test ever written.

**Four things the stock scaffold got wrong for this product:**

1. **403 for everyone.** Filament refuses panel access outside `local` unless
   `User` implements `FilamentUser`. Added `canAccessPanel()` returning
   `is_active` — mutation **M79** proved the first version was untested: a
   *deactivated* account could open the admin panel and the whole suite stayed
   green. That is the finding an on-prem security review leads with.
2. **Google Fonts.** `->font('Vazirmatn')` fetches from bunny.net/Google by
   default — a hard **AG-01…AG-06 violation**. In a customer datacentre it does
   not degrade, it hangs. Fixed with
   `provider: \Filament\FontProviders\LocalFontProvider::class`, which emits
   nothing and lets the OS-installed `fonts-vazirmatn` win — the same font the
   PDF renderer uses. Pinned by a test that greps the HTML for five CDN hosts.
3. **English, LTR, UUID-first.** `--generate` emits a column per DB column: it
   led with three UUIDs and showed both title columns at once. A document
   controller identifies a document by its **number**. The UUID column is
   *deleted*, not toggled off — a hidden column is still one somebody can turn
   on and paste into an email.
4. **A bulk DELETE button.** On a controlled register. Revisions supersede and
   states archive; that is the whole point of ISO 19650. Removed.

**A bug tests could not see.** The state column was bound to
`currentRevision.state`; the attribute is `cde_state`. Filament resolved null
and rendered an **empty cell on every row** — page still 200, tenancy tests
still green, and the register silently lost the field that says whether a
drawing may be built from. Found by *looking at a screenshot*. Any column whose
value arrives through a relation now gets a content assertion, because a
mistyped attribute fails silently rather than loudly (mutation **M81**).

**Locale.** `users.locale` existed and was populated but nothing read it; the
hand-written screens use `?lang=`. New `SetUserLocale` middleware applies the
user's own language (Persian default, `?lang=` still wins) because Filament
resolves labels through the translator at render time, far from any view.
Panel strings live in `lang/{fa,en}/epcc.php` — the first translation files in
the project.

**What an admin resource may DO is the second load-bearing decision.**
`--generate` gives full CRUD on every model. For this product that is wrong in
a specific way, and differently wrong per resource:

| Resource | create | edit | delete | why |
|---|---|---|---|---|
| Document | no | titles only | **no** | number/sequence/company are derived by `DocumentRegister`; the register archives rather than deletes (ISO 19650) |
| PunchItem | no | **no** | no | `state` is a position in a workflow with rules about *who* may move it, not a column |
| Transmittal | no | no | no | an ISSUED transmittal is evidence of what was sent on a date; items snapshot the revision as sent, and the per-stream counter is allocated under a row lock |
| Subsystem | no | no | no | the breakdown arrives as a bulk import from system engineering, and `code` is the join key the whole handover chain hangs off — a hand-typed code that misses the P&ID is invisible to every document, punch item and certificate that references it; editing it after punch items exist orphans them |
| User | no | no | no | `is_active` IS gate 1 and is what `canAccessPanel()` reads — an editable toggle re-opens every door in the product without passing any of the six gates; `company_id` is the tenant; roles live on the per-project membership, not the user |

The generated document form offered `number`, `sequence`, `company_id` and
`current_revision_id` as free inputs. Retyping a number is not an edit, it is a
collision with the `(project_id, number)` unique index; changing `company_id`
does not move a document, it makes it vanish from its author's register. The
form now edits the two genuinely free fields — the bilingual titles — and shows
the rest as read-only placeholders, because an admin still needs to *see* which
record they have.

The punch resource is stricter still: an admin form writing `state` would let
someone mark an item VERIFIED with nobody having verified it, on a register
whose entire purpose is proving somebody did — and `McCertificateService`
reads that column, so a forged state also unblocks a completion certificate.

**A grep is not an assertion.** The first version of the no-delete test
searched the source for `"DeleteAction"` and failed against the *code comment*
explaining why there is no DeleteAction. It would equally have missed a delete
introduced under another name. Rewritten to call `canDelete()` / `canCreate()`
/ `getPages()` — the resource's own authorization, which is what Filament
actually consults.

**One resource shows BOTH transmittal streams**, with `kind` as a filter.
The hand-written UI deliberately splits contractor (`-TR-`) from vendor
(`-VTR-`): a document controller working the contractual log does not want
supply-chain letters in their numbering. The admin view answers the opposite
question — "what left this project, by any route?" — so splitting it would be
the wrong shape. The employer still sees no `VTR` rows here, and that is
enforced in PostgreSQL, not in the resource: mutation **M86** hard-filtered the
table to `CONTRACTOR` and the isolation test still passed, because RLS was
doing the work all along.

### The Jalali defect — why a green suite still shipped a wrong page

The transmittal list went out with Filament's `->dateTime()` and rendered
`سپتامبر 12, 2026` on a page that was otherwise entirely Persian. HTTP 200,
every test green. **It was found by looking at a screenshot.**

On a submission log that is not cosmetic: the date decides whether a reply
landed inside the contractual 14-day window.

The root cause was not the panel. Jalali formatting only ever existed as a
private closure inside each Blade view — `$jdate = function ($d) use ($fa)`,
copy-pasted per screen. They agreed by luck, and a surface written months later
could reuse none of them, so it reached for the framework default.

Fixed by extracting **`app/Support/JalaliDate.php`** (`format`,
`formatWithTime`, `digits`) and routing every date and number through it —
all three panel tables and all ten Blade views; there is no `Morilog` call left
in `resources/views`. It takes `$lang` as an argument rather than reading the
app locale, because the PDF renderer formats a document in a language chosen
per render, not per request.

`DateFormattingTest` pins this **structurally**, not just by output: one test
fails if any view calls `Morilog` directly, another if any Filament file calls
`->date()`/`->dateTime()` outside a comment. Mutations **M87–M89** confirm all
three bite. A behavioural test alone would not have caught the re-introduction
of a fourth private closure.

**Scope.** This is an ADMIN view, not a replacement for
`/projects/{code}/documents`. That screen enforces the workflow (numbering via
`DocumentRegister`, transitions via `CdeState`, gating via `ReviewCycle`). This
one is for what the workflow does not cover: fixing a typo, looking a record up
across projects, inspecting what is stored. Both sit under the same RLS.

### 5i-2. Identity tables: the leak the Users resource exposed

**Building the Users resource is what found it.** `users`, `companies` and
`project_memberships` were never in the original RLS migration's
`TENANT_TABLES`. Isolation for users was a `->where('company_id', ...)` in one
controller — precisely the "forgotten where clause" that migration's own
comment says RLS exists to backstop. Measured, bound as EPC-PARS:

```
documents visible: 5      <- correctly narrowed
users visible:     9      <- every user of all eight companies
```

Nothing had exposed it because no screen listed users. A naive Filament table
would have published the client's representatives, the PMC's inspectors and two
rival EPCs' engineers — names and addresses — to every tenant.

Fixed in `2026_09_12_100000_secure_identity_tables`: RLS on `users` and
`project_memberships`, with three USING clauses — own company, the identity
hatch, and **counterparties on a shared project** (a document says "reviewed
by", a transmittal "acknowledged by"; hide those rows and working pages render
blank names).

**`companies` is deliberately NOT covered.** The participant list is on the
contract and every party already knows it; covering it would need a second
bypass for a row whose leak is "the contractor learns the consultant's name".
Recorded so the next person does not assume it was missed.

Three traps paid for here:

1. **Policy recursion.** The tight rule — "users holding a membership on a
   project my company is on" — makes `users` read `project_memberships` while
   that table's policy reads `users`. PostgreSQL rejects it outright:
   *infinite recursion detected in policy for relation "users"*. The clause was
   re-expressed through `project_company` (no RLS of its own), which is
   slightly wider — employees of a participating company who are not on the
   team — and that is the accepted trade.
2. **`NULLIF` on every GUC read** (rule 3). `current_setting(...,true)` returns
   `''`, not NULL, once a GUC is set and cleared in the same transaction, and
   `''::uuid` is a hard error. The first draft reproduced the bug this project
   already fixed once in `2026_09_09_100200`.
3. **Login happens before a tenant exists.** Authentication must read a user
   row to learn which company to bind, so `epcc.company_id` is necessarily
   unset — and unset means "see nothing". Without an escape hatch RLS does not
   leak; it locks everyone out. Hence `TenantContext::forIdentityLookup()`.

**The hatch is a bypass and is documented as one.** Mitigations: one greppable
name, transaction-scoped like every other GUC, cleared in a `finally`, and
**snapshot-restored rather than force-cleared** — a nested call that cleared
the GUC on exit silently shut the hatch its caller still needed, and the
symptom was not an error but a write that matched no rows, leaving the
"disabled" fixture account enabled.

### The bug that a green suite could not see

After the policy landed, **every `/admin` route redirected to the login screen
with a perfectly valid session.** Filament's `Authenticate` resolves the user
before `BindTenant` binds a tenant, so the guard got NULL and treated the admin
as a guest.

All 21 panel tests stayed green, because **`actingAs()` injects a User object
straight into the guard and never asks the user provider for it**. Found by
taking a screenshot — the third defect on this project found that way rather
than by a test.

Fixed at the *provider*, not in a middleware: `TenantAwareUserProvider` wraps
`retrieveById` / `retrieveByToken` / `retrieveByCredentials` /
`updateRememberToken` in the hatch, so the session guard, the panel,
`Auth::attempt` and remember-me are all covered by one greppable class.

**And the first test written for it was also inert.** `phpunit.xml` sets
`SESSION_DRIVER=array`, so a session does not survive between test requests and
Laravel keeps the already-resolved user in memory — `retrieveById()` is never
called. Mutation M95 deleted the provider override outright and the HTTP test
stayed green. The assertion that bites calls the provider directly, the way the
session guard does. **If a test exercises authentication, check it is not
riding on `actingAs()` or an in-memory session.**

### 5i-3. The subsystem register — deriving a gate, and a panel-wide digit defect

The MC gate is **derived, never stored**. `subsystems` has no state column: a
subsystem is certifiable when it has no open category-A punch item, which is a
question about *other* rows and changes the moment somebody closes the last
one. A boolean written at walkdown time is wrong by the afternoon, and "can
this be handed over" is precisely the question nobody should answer from a
stale column.

**Three rules the table must not restate in its own words.** `PunchCategory`
owns "A blocks MC", `PunchState` owns "open means anything but CLOSED", and
`McCertificate` owns DRAFT/ISSUED. The table asks all three rather than
hardcoding `['A']` or a literal state list — otherwise a future change to the
rule leaves this screen quietly asserting the old one, on the screen where
somebody decides whether to hand over a unit.

**Counts are computed by the database.** `Subsystem::openBlockingItems()` and
`closurePercent()` walk the loaded `punchItems` collection: correct for one
record on a detail page, quadratic on a register. The table uses `withCount`
with the same predicates, and a tinker probe asserts the SQL and the model
agree row by row — if the two ever disagree, one of them is wrong and it is
worth knowing which before shipping.

**`closurePercent()` returns 100 for an empty punch list.** Arithmetically
fine, dangerous on a handover register: "100%" beside a subsystem nobody has
walked down reads as finished when it means the opposite. The column renders
**"not walked down"** in words for that case.

**A one-row fixture proves nothing** (recorded before, re-proved here). With a
single subsystem a working badge and a hardcoded one render identically. The
fixture now carries five, each existing to kill a specific mutation:

| code | state it pins |
|---|---|
| PH-14-SS-2201 | 2 open A-items, DRAFT certificate — the blocked case |
| PH-14-SS-3301 | items raised and all CLOSED — genuinely clear |
| PH-14-SS-4401 | zero items — never walked down |
| PH-14-SS-5501 | one A-item **VERIFIED, not CLOSED** — still blocked |
| PH-14-SS-6601 | one open **category-B** item — open, but not blocking |

SS-5501 and SS-6601 were added *because* mutations survived without them.
M96 (the table's own open-state list drops VERIFIED) and M99 (blocking widened
to A+B) were both undetectable by any test until a row existed that could tell
the rules apart. **When a mutation survives, ask whether the fixture can
express the difference at all before rewriting the assertion** — and note M96
survived a test that checked `PunchState::isOpen()` and the *model* helper.
Both were right; the *table* was wrong. Assert on the rendered row.

**Adding fixture rows broke three unrelated tests**, which hardcoded
`PH-14-PL-0006` and `assertSame(5, $count)`. Those literals tested the
fixture's size, not the behaviour claimed in the test name. They now derive the
expectation (`count() + 1`, and the MC body's view as the reference for "every
participant sees the same list"), so the next fixture change does not break
them again.

**The panel-wide defect the screenshot found — mixed digit systems.** Persian
pages rendered our columns in Persian digits (۵, ۴۰٪) and Filament's own chrome
in Latin: *"نمایش 1 به 5 از 5 نتیجه"*. Latin numerals inside a Persian sentence
are instantly visible to a reader and invisible to an assertion that only
checks the page loaded. It affected **all five resources**, not just the one
being built — it had been shipping since the first one.

Fixed once, at the translator: `App\Support\LocalisedNumberTranslator` extends
Laravel's `Translator` and converts numeric `:parameter` values when the locale
is `fa`, bound via `$this->app->extend('translator', …)` in
`AppServiceProvider::register()` (**register, not boot** — the container
resolves `translator` during boot). Per-table fixes were rejected: they leave
the next table free to reintroduce it and do nothing for strings inside the
Filament package.

Only **wholly-numeric** values convert. Converting the rendered line would turn
PH-14-SS-2201 into PH-۱۴-SS-۲۲۰۱, and tags are read off drawings and typed into
search boxes in Latin. That guard is currently **unobservable through the UI** —
no rendered string passes a digit-bearing non-numeric parameter, and a mutation
removing it leaves every page byte-identical. So it is pinned by a test against
the translator directly, not by an HTTP test that would pass either way. An
inert test is worse than none: it reports safety it never checked.

### The mobile blank page — and why only Persian had it

`/projects/PH-14/documents?lang=fa` at a 430px viewport rendered **one unique
colour**: the background. Not a slow load, not missing data — the HTML was 66KB
with every document in it. The same page in **English at the same width was
fine**, and that asymmetry was the whole clue.

A flex item defaults to `min-width:auto`, which means *never shrink below my
content's intrinsic width*. The documents table is ~1032px intrinsic; the phone
viewport was 485px. So `.wrap` grew **past** the viewport instead of
overflowing inside it. In LTR that clips harmlessly off the right edge and the
page still reads. In RTL the block is laid out from the right edge, so the same
overflow pushes the **entire document off-screen to the left** — a blank
rectangle.

Measured, before → after:

| page (fa, 430px) | before | after |
|---|---|---|
| documents | **1** | 2760 |
| transmittals | 206 | 2632 |
| project / team / punch | 2562 / 3217 / 1087 | 2953 / 3219 / 3321 |

Fixed in the shell, not per view: `min-width:0` on `.app > .wrap`, plus
`overflow-x:auto` inside the existing mobile media block. **Both halves are
needed.** `min-width:0` alone contains the overflow but then clips it, and the
columns past the fold on a document register are the state and the revision —
the two fields somebody opens that register to read.

Three candidate fixes all restored the page (`table-layout:fixed`,
`min-width:0`, `display:block` on the table). The containment fix was chosen
because it repairs the layout bug itself rather than restyling every table, and
it leaves the `<table>` semantics the jsdom harnesses depend on intact.

**Why no test caught it.** The suite asserts status codes and the presence of
strings in HTML. Every one of those assertions passed on a page that painted
nothing — the markup was perfect and unreachable. `ShellStructureTest` now
pins both CSS rules *and* checks that the pages carrying wide tables really do
render through the shell, so a page that stopped using it could not keep
passing on the CSS assertion alone (M110–M111).

**This is the fifth defect found by looking rather than testing**, and the
first found by looking at a phone width. Rendering at desktop only is a blind
spot for an Iran-first product where site staff are on phones.

### 5j. AG-06 — the air-gap pre-flight, and what static scanning cannot see

`php artisan verify:airgap` is the command the customer runs at acceptance. It
scans `public/` and `resources/` for anything a browser would fetch from the
internet and grades each finding:

| severity | meaning | exit |
|---|---|---|
| **BLOCKER** | fetched while rendering: `src=`, a stylesheet `href`, `@import`, `url()`, or a JS loader that assigns `.src`/`.href` | **1** |
| **LATENT** | present in a shipped file on a path we do not enable | 0 (1 under `--strict`) |
| **BENIGN** | comment, licence, XML namespace | not reported |

The severity split is the whole product. A bare grep for `https://` over a
vendor tree returns dozens of hits, all noise until classified, and a command
that fails on things the customer cannot act on is a command the customer
learns to ignore. Default is BLOCKER: an unknown external reference is guilty
until somebody writes down why it is not. `--json` feeds the acceptance report;
`--strict` is what CI runs.

**Current findings: 0 blockers, 3 latent** — Pusher's CDN inside Filament's
`echo.js` (served `->core()` on every panel page but inert, because Echo is
never initialised with `BROADCAST_CONNECTION=log`) and Font Awesome inside
EasyMDE (`autoDownloadFontAwesome` defaults to true; we register no
MarkdownEditor field). If anyone adds one, pass
`autoDownloadFontAwesome => false` or it becomes a blocker on site.

**Two things the static scan missed, and the general lesson.**

First, Pusher. `echo.js` stores `cdn_https:"https://js.pusher.com"` and
concatenates the script URL at call time, so no literal `src="https://..."`
exists anywhere in the file. The first version of this command gave it a clean
bill of health. Dynamic script loaders are the highest-risk shape precisely
because they fetch lazily, so a pattern for CDN bases held in config
properties was added.

Second — and this one is the real lesson — **`ui-avatars.com`**. Filament's
default avatar provider builds the URL in PHP from the user's name, so it
appears in no shipped file at all; it was rendered into the user menu of every
admin page. Found by capturing a real browser's net-log against `/admin`, not
by reading code. Two defects in one: an image that cannot be fetched in a
customer datacentre, and a named employee posted to a third party — for a NOC
affiliate's staff list that is a confidentiality problem quite apart from the
air gap. Fixed with `App\Support\LocalAvatarProvider`, which draws initials as
an inline SVG data URI (deterministic colour per name, Vazirmatn for Persian
initials, zero requests).

> **A file scanner can only find URLs that exist as text on disk.** Anything
> assembled at runtime is invisible to it. That is why
> `AirgapVerificationTest` asserts against the *rendered HTML* of every panel
> screen as well as against the command — rendered output is the only place
> runtime-assembled URLs become visible. Note it filters to fetching
> attributes only: an `<a href>` to an external site is navigation and costs
> nothing until clicked, and flagging those would bury the real findings.

`FilamentInfoWidget` was also dropped: it put the framework's branding and
exact version number on the customer's dashboard, which is both wrong-branded
and a free CVE list for an attacker.

**This is the ninth defect found by looking rather than testing, and the third
in the air-gap family** (after `->font()` and the preview iframe). The pattern
is consistent: everything that reaches outward is invisible in a sandbox with
working internet. The only reliable detector is to watch the network, or to
cut it.

### 5k. Procurement and materials — تهیه، بازرسی، انبار، سایت

The second C in EPCC. Five documents covering the chain the user named:

| Persian | document | prefix |
|---|---|---|
| تهیه | requisition → PO | `-MR-`, `-PO-` |
| بازرسی | inspection record | `-IRN-` |
| ورود به انبار | goods receipt | `-GRN-` |
| خروج از انبار | material issue | `-MIV-` |
| ورود به سایت | site delivery | `-SDN-` |

**One movement table, not four.** GRN/MIV/SDN/MRN are four pieces of paper but
the same fact: a quantity of one lot moved somewhere at a time and somebody
signed. Four tables would mean four sequence allocators, four RLS policies and
a balance that UNIONs four shapes. The ledger is **append-only** — a wrong
receipt is corrected with a reversing movement, never an UPDATE, because a
warehouse's only real asset is being able to say what it held on the day of an
audit.

**The sign convention lives in `MovementType::sign()`, not in the data.** A
stored signed quantity means every reader must know the convention, and
somebody eventually inserts a negative receipt. Note `SITE => 0`: the material
left the warehouse at ISSUE, and counting it again would double-deduct. That
mutation (M114) kills three tests.

**ISSUE and SITE are two steps on purpose.** ISSUE is a stock question; SITE is
a completion question. Material can sit on a laydown area for weeks between
them, and collapsing them hides it exactly when somebody is looking for it.
`test_issued_but_not_yet_on_site_is_still_a_shortage` pins this.

**Lots exist because the user asked for heat-number traceability.** Stock is
not "300 m of pipe" but "120 m of heat A-4471". The MTC is a **document in the
CDE**, not a file path, so it inherits revisions, transmittals and access
control — a material certificate outside the register is one nobody can find
at handover. `isFullyTraceable()` requires both an identifier *and* the
certificate: a heat number with no MTC behind it is not traceability.

**Inspection is ADVISORY — the user's explicit choice.** A failed or missing
inspection records a warning and lets the receipt through. That matches how
sites run (material lands at 2am, the TPI signs on Sunday) and a system that
refuses the receipt gets bypassed with a paper note nobody types in. The price
is that "received but not passed" must be loud, so `inspection_result` is
denormalised onto the lot and `uninspectedLots()` drives a panel on the screen.
**Advisory applies to the verdict, not to who may give it** — a contractor
still cannot inspect its own material, or the record looks like assurance while
carrying none. NULL is treated as needing attention: not inspected is not the
same as passed.

**Two separate SoD rules, two different messages.** The raiser may not approve
their own MR; and the technical and commercial approvals may not be signed by
the same person. They are different failures and a buyer needs to know which
one they hit. Mirrors `cert.approve` XOR `cert.submit`.

**Expediting keeps the promise and the forecast in separate columns.** A system
that lets the forecast overwrite the promise makes every order look on time.

**RLS is commercial here, unlike the punch list.** A punch list is shared — the
whole project walks down together. Procurement is not:

- a **vendor** sees the PO addressed to it and nothing else (vendors on one
  project are frequently competitors and a PO carries prices)
- **requisitions** are the buyer's planning: employer/PMC/MC read them, vendors
  never do
- **stock and movements** are operational, so every participant reads them —
  the employer is entitled to know whether the valve is on site, which is the
  weekly spreadsheet this module exists to kill

**The MC link (user asked for it).** `subsystemMaterialStatus()` compares
ordered against *delivered to site*, computed live, never stored — same rule as
`closurePercent()`. A subsystem that buys nothing reports complete rather than
short, the same call as closure returning 100 for an empty punch list.

Module key is `proc`, in the `full` and `special` plans. Screens:
`/projects/{code}/procurement` and `/projects/{code}/materials`.

**UML (`docs/uml/`).** Five PlantUML sources plus a single self-contained viewer,
`docs/uml/uml.html` — inline SVG, **zero external references**, so it obeys the
same air-gap rule as `tour/tour.html` and opens from a file:// path on a machine
with no network:

| file | what it answers |
|---|---|
| `01-domain-model.puml` | the 7 tables, their multiplicities, and *why* lots and the ledger are shaped that way |
| `02-state-machines.puml` | MR, PO, and the physical custody of a lot side by side |
| `03-sequence-receive-to-site.puml` | one heat from inspection to the MC gate, including the lock and the derived PO state |
| `04-reversal-and-rls.puml` | correcting a booking without erasing it; what a vendor sees (0 MRs / 3 POs / 3 lots) |
| `05-component-view.puml` | layering, and the rule that value objects depend on nothing |
| `06-breakdown.puml` | **AS BUILT** — ADR-004 facility / area / subsystem + the composite FK |
| `07-proposed-ingestion.puml` | **PROPOSED, not built** — ADR-005 engineering data ingestion |

Regenerate with `plantuml -tsvg docs/uml/*.puml` then re-run the inliner
(the HTML embeds the SVGs; editing a `.puml` alone does **not** update it).
Diagram text is **English** per the standing documentation rule, while the
column and label names are quoted verbatim from the schema — the diagrams were
written against a live `information_schema` dump rather than from memory, so
they are safe to trust when the code and this file disagree.

**Note for whoever installs the toolchain:** `graphviz` and `plantuml` are *not*
in the base image and are wiped by a sandbox reset. `sudo apt-get install -y
graphviz plantuml` restores them (`apt-get` without `sudo` fails on the dpkg
lock — the user is uid 1000 but has passwordless sudo).

### 5l. Physical breakdown — facility / area / subsystem (ADR-004)

`project → facility → (optional) area → subsystem`. Decision record and the full
as-built table: `docs/ADR-004-Physical-Breakdown-Plant-Pipeline-Subsystem.md`;
diagram `docs/uml/06-breakdown.puml`.

**What a facility is.** One table, `facilities`, with `kind ∈ FacilityKind` =
PLANT | PIPELINE | OFFSITE | MARINE | UTILITY. Not sibling `plants` and
`pipelines` tables: what they share is being a *commissioning parent*; what
differs is *spatial addressing*, and that lives in a per-kind validated
`addressing jsonb`. Sibling tables would push every upward query into a
two-branch `COALESCE` plus an XOR CHECK — the classic shape of a missing
abstraction. Same pattern already proved twice here: `McCertificate.state` and
`MovementType`.

**`FacilityKind::all()` vs `selectable()` — the distinction matters.** `all()`
drives the CHECK constraint, so a PIPELINE row is storable and importable.
`selectable()` omits PIPELINE, so nobody can create one through the UI while KP
stationing is undesigned. Storable-but-not-offerable is the honest state; a
CHECK that rejected PIPELINE would have to be migrated later, and one that
offered it would promise reporting that does not exist.

**Areas are optional, on purpose.** Plant 3D's own refinery example has 13
areas, so omitting the level would break lossless import; but an Iranian booster
station with 12 subsystems should not have to invent 12 areas. Hence
`subsystems.area_id` is nullable and the fixture is **deliberately uneven** —
`PH-14-PL-01` has areas `AR-22`/`AR-33` *and* `SS-5501` hanging directly off the
facility, while `PH-14-PL-02` has no areas at all. A fixture where every branch
looks the same cannot fail informatively. Same rule as `closurePercent()`
returning 100 for an empty punch list: **absence of structure is not an error.**

**Numbering is per facility.** `UNIQUE(project_id, code)` → `UNIQUE(facility_id,
code)`. Real projects renumber per plant, and forcing project-wide uniqueness
across a 4,000-subsystem job invents collisions that do not exist on site.
Consequence to remember: **the bare code no longer identifies a subsystem.** The
admin register shows Facility as a *non-toggleable* column for that reason, and
`Subsystem::fullCode()` composes `"{facility} / {code}"` at read time. It is not
a stored column — a composed code in a column drifts the moment a facility is
renamed, and issued certificates already snapshot their identifiers.

**The one constraint to not remove.** `subsystems_area_within_facility` is a
*composite* FK `(area_id, facility_id) → areas (id, facility_id)` (backed by
`areas_id_facility_id_unique`), `ON DELETE SET NULL`. Two independent FKs would
happily allow a subsystem in facility *A* pointing at an area in facility *B* —
silent cross-facility corruption that every roll-up would then report
confidently and wrongly. Deleting an **area** nulls `area_id` and keeps the
subsystem; deleting a **facility** cascades, because a subsystem with no
commissioning parent is meaningless.

**Migration trap (cost an hour, will recur).** The backfill wrote nothing and
the migration died with `23502 … facility_id contains null values`. `subsystems`
is under `FORCE ROW LEVEL SECURITY` and a migration has no `epcc.company_id`
GUC, so the backfill `SELECT` matched zero rows — **silently**, because RLS
filters rather than errors. Fix: `DISABLE ROW LEVEL SECURITY` around the
backfill, then restore **`ENABLE` *and* `FORCE`** — `ENABLE` alone leaves the
owner exempt, and role `epcc` owns these tables. Safe only because PostgreSQL
DDL is transactional.

**Tests:** `tests/Feature/BreakdownTest.php`, 25 tests / 69 assertions, covering
structure, per-facility code reuse, `fullCode()`, cross-facility integrity,
area-delete vs facility-delete semantics, `FacilityKind` (including
known-but-not-selectable), the addressing jsonb, `Area::displayCode()`, RLS
reads and writes, and that the migration left `relrowsecurity` *and*
`relforcerowsecurity` true on all three tables. Mutations M118–M123 all caught.

## 5m. Engineering reference data — ASME sizes, schedules, end types, templates (phase 0)

**ADR-007 is ACCEPTED AND BUILT.** This is the first piece of ADRs 006–010 to exist as code.
It is deliberately the first: the line-number parser, the port compatibility engine and the
PCF importer all need the size vocabulary before they can validate anything.

### What it is

Four versioned JSON packs under `standards-packs/reference/`, read through one memoised
singleton. **Not database tables.** `NPS 6" = DN 150 = OD 168.3 mm` is true on every project
in every company in every year — putting it in a table means either ~500 duplicated rows per
project or the system's first cross-tenant table plus a permanent RLS exception. The
protection actually needed is *nobody can write, including the owner company*, which a file
on disk gives absolutely and a permissive RLS policy only pretends to.

| Pack | Size |
|---|---|
| `pipe-sizes.ref.json` | 36 sizes, 1/8″–48″ |
| `pipe-schedules.ref.json` | 355 (size, schedule) pairs, 18-rung ladder |
| `end-types.ref.json` | 13 PCF end types |
| `component-templates.ref.json` | 20 templates, 41 port definitions |

Access: `App\Support\Reference\PipeReference`, singleton in `EpccServiceProvider`, directory
from `config('epcc.reference_dir')`. `App\Support\Reference\PipeSize` is the readonly value
object. **Every lookup throws** (`UnknownSizeException`, `UnknownScheduleException`) — except
`resolveLabel()`, which returns null because line-number parsing legitimately asks "is this
token a size at all?" where "no" is a normal answer.

### The four NPS columns, and why none can go

At the user's explicit instruction, and each has a job the others cannot do:
`nps` `"2 1/2"` is what the engineer reads · **`npsDecimal` `2.5` is the only summable one —
this is what makes dia-inch computable (ADR-010)** · `dn` `65` is the integer key for ADR-008's
`int4range` bands · `odMm` `73.0` is the physical dimension. A future "simplification" to
fewer columns silently breaks dia-inch reporting.

### STD is not SCH 40 — the trap that justified this whole ADR

Published tables disagree, and **several print STD values under a column headed SCH 40**.
Verified in the shipped data and asserted in three independent layers:

| NPS | SCH 40 | STD | SCH 80 | XS |
|---|---|---|---|---|
| 6″ | 7.11 | 7.11 | 10.97 | 10.97 |
| 10″ | 9.27 | 9.27 | **15.09** | **12.70** |
| 12″ | **10.31** | **9.53** | 17.48 | **12.70** |
| 24″ | **17.48** | **9.53** | 30.96 | **12.70** |

STD diverges from SCH 40 from 12″; XS diverges from SCH 80 from 10″. Above those, STD is
pinned at 9.53 and XS at 12.70 regardless of diameter. **A test that spot-checks 2″ and 6″
passes on a completely wrong large-bore table.**

### TRAPS

- **PHP coerces numeric string array keys to integers.** `array_keys()` on the decoded wall
  table returns `40` as an **int**, so `schedulesFor()` handed back a mixed `int|string` list:
  strict `in_array()` silently fails, and feeding a key back into `wall()` is a `TypeError`.
  Fixed with `array_map(strval(...), …)`. Caught by the suite on first run.
- **The reachable alias-fallback bug runs the other way.** Asserting STD ≠ SCH 40 at 12″+ does
  **not** stop a "helpful" fallback, because STD is never the missing one. **ASME defines STD
  at 22″ and 26″ but no SCH 40 there at all** (likewise XS but no SCH 80 from 26″ up) — a
  fallback returns 9.53 mm for a schedule that does not exist. Survived the first suite; found
  only by mutation M1.
- **Instance identity does not prove memoisation.** A singleton that re-decodes 500 rows per
  lookup is still a singleton. The test now warms the cache, deletes the files, asserts the
  lookup still works, **and** asserts a fresh instance against the same empty directory throws
  — otherwise it would pass on an eager-loading implementation. Found by mutation M14.
- **A PCF bore is meaningless without its unit.** `UNITS-BORE` may be `INCH`, `MM` or
  `INCH-SIXTEENTH`. A bore of `96` is 6″ in sixteenths and **not a pipe size at all** in
  inches. `resolveBore()` therefore takes the unit as a required argument and throws on an
  unrecognised one rather than defaulting.
- **Persian digits must be folded.** `۲ ۱/۲` → `2 1/2`. Without it, a Farsi-locale user typing
  a perfectly valid size gets `UnknownSizeException`.

### Validation, three layers

Generation-time checks in the emitting script; `validate_packs.py` grew
`check_reference_schema()` + `check_reference_integrity()` (NPS labels re-parsed with
`Fraction` and compared to `npsDecimal`, `odIn × 25.4` reconciled to `odMm`, monotonic ladder,
the STD/XS pins, `numbered ⇒ weldable`, `TEE` must have 3 ports and be `qualifierDerived`,
`EQUAL_TEE`/`REDUCING_TEE` **forbidden**, `NOZZLE` must carry `ownerKind`); then 49 PHPUnit
tests including `test_it_touches_no_database()`, which fails if reference data is ever moved
into a table. **15 data mutations and 15 PHP mutations were run; all 30 caught.**


## 5n. Why one database, not one per project (ADR-011)

Asked by the user on 2026-09-15. Answer: **no for the hosted SaaS, yes at instance level for
on-premise.** Measured rather than asserted, and one finding settled it.

**The fixture already contains the breaking case.** `EPC-PARS`, `NIOC-AFF` and `PMC-TEHRAN` each
participate in **two projects** — normal for an Iranian EPC contractor, not an edge case. Under
database-per-project a single human becomes two independent user rows with two password hashes
(verified in a spike), and the post-login landing page — *my documents across my projects* —
cannot be produced by a query at all:

```
ERROR:  cross-database references are not implemented
```

That is a hard PostgreSQL limit, not a config problem. `plans.max_projects` also proves the
**commercial unit is the company, not the project**, so the billing boundary and the storage
boundary would point in opposite directions.

**Isolation is already there.** Binding a session shows the same company gets strictly one
project's rows when bound to that project, both when bound to neither, and a non-participant
gets zero. Separation would buy isolation that exists, and would swap a database-enforced rule
(fails closed) for a connect-to-the-right-database rule in application code (fails open).

**RLS applies to `COPY`, not just `SELECT`** — so a per-project export is just a bound session.
The usual "but we need per-project handover" argument does not require separation.

The one genuine capability the shared database lacks is **per-project point-in-time restore**.
Schema-per-project solves it and stays cheap to reach later, because every table already carries
`project_id`, RLS is already project-aware, and there are **zero** `DB::connection()` call sites.


## 5o. The RLS escape hatch is a performance defect (ADR-012) — FIXED 2026-10-11, awaiting runtime verification

> **Update 2026-10-11 (P-17):** the defect below is fixed by migration
> `2026_10_11_110000_make_rls_project_scope_sargable` — every one of the 33
> tenant policies now opens with a sargable participation semi-join
> (`project_id IN (participated/owned projects, narrowed to the bound one)`)
> instead of the `(GUC IS NULL OR project_id = GUC)` disjunction; membership
> branches, WITH CHECK text, delegation and deny policies are untouched, and
> eight `(project_id, …)` indexes were added. Verified in the sandbox against
> PostgreSQL 16.2 (300 k rows / 200 projects): RLS-only-scoped reads drop
> from a 153 ms whole-table seq scan to 26 ms, index plans hold once the
> query carries the project predicate (house controllers always do), and the
> cross-project / isolation probes all pass. `RlsSargabilityTest` pins the
> semantics and a scale-independent plan-shape guard. The history below is
> kept as found. Full record: ADR-012 §9.

**Found 2026-09-15 at 200 projects / 2.64 M rows. Present in production code today, invisible at
fixture scale, and it couples tenants: one customer's page slows down when an unrelated
customer's project grows.**

Every tenant policy has this shape:

```sql
(NULLIF(current_setting('epcc.project_id', true),'') IS NULL      -- escape hatch
 OR project_id = NULLIF(current_setting('epcc.project_id', true))::uuid)
AND EXISTS (SELECT 1 FROM project_company pc WHERE …)
```

`A IS NULL OR col = A` is **not sargable**. No index on `project_id` can ever be used:

```
Seq Scan on punch_items   Rows Removed by Filter: 1315440   -- to return 25 rows
Execution Time: 870 ms  (1,690 ms once the table doubled)
```

Adding `(project_id, sequence)` changed nothing — **the index was never the problem.**

**The trap: the fastest fix is the broken one.** Deleting the `OR` branch gives 870 ms → 0.16 ms
and **silently returns 0 rows** for the cross-project landing page (company bound, no project
bound). No error; every project-bound test still passes. A benchmark alone would have chosen it.
`coalesce(setting, project_id)` is correct but still opaque to the planner (183 ms, parallel seq
scan).

**The fix that is both:** the policy keeps only membership (`project_id IN (SELECT … FROM
project_company WHERE company_id = …)`) and the *query* adds `WHERE project_id = :current`.
Measured: register page **0.144 ms**, cross-project view **211,200 rows**, non-participant **0**,
participant asking for a project it is not in **0**.

**The curve goes flat** — a 540 k-row project pages in the same 0.13 ms as a 5 k-row one, at both
1.3 M and 2.6 M total rows. Page latency follows page size, not table size. **No partitioning, no
sharding, no database-per-project.**

Not yet applied: it changes 24 security policies. Isolation *between companies* stays
database-enforced; isolation *between projects of the same company* moves to the query layer —
a deliberate decision, not a side effect. Plan in ADR-012 §8, and **write the failing
cross-project test first**, because the current suite would pass the broken version.


## 5p. Per-project backup and deletion (ADR-013) — proven on a scratch copy, not yet built

User asked whether one project can be backed up and then completely deleted. **Yes — the full
cycle (export → delete → restore → verify) was run end to end on a byte-for-byte copy of the live
database.** 93 rows / 26 tables exported, delete took **53 ms** via 23 cascades, zero orphans,
other projects untouched, restore matched the manifest exactly and every FK re-validated.

**Four traps, and the first two make the naive answer wrong:**

1. **`pg_dump` as the app user silently truncates.** `FORCE ROW LEVEL SECURITY` applies to the
   owner, so the dump **aborts mid-way, exits 0, and leaves a 29 KB file** where the real dump is
   166 KB. A backup script checking `$?` reports success. Per-project backup therefore requires a
   superuser/`BYPASSRLS` role — the backup job is a **privileged component**.
2. **`pg_dump --where` is PostgreSQL 18.** On 17.11 it is `unrecognized option`. Row-filtered
   export must be built table by table with `\copy (SELECT … WHERE project_id=…)`.
3. **A topological sort of the 25 tables silently drops the document register.**
   `documents.current_revision_id ↔ document_revisions.document_id` is a genuine cycle, so those
   four tables have no topological position and fall out of the recursion — the export completes,
   reports success, and contains **no documents**. Fix: explicit reviewed order + restore under
   `SET session_replication_role = replica`, then re-validate. **The per-table row-count manifest
   is what catches a silently-empty table.**
4. **Deleting the rows does not delete the files.** No FK reaches the filesystem: after a clean
   cascade with zero orphans, the project's 4 blobs are still on disk. Blob paths are
   project-scoped (`documents/<project-uuid>/…`) and no sha is shared across projects, so it is a
   directory removal — but it must happen **before** the rows, or the paths are gone.

**Also:** `authorization_denials` and `gate_evaluations` carry `project_id` with **no FK**, so they
are never cascaded and must be deleted explicitly. And `projects_code_unique` means a deleted
code becomes reusable, so two unrelated `PH-14`s can end up in the archive.

Deleting PH-14 destroyed 1 MC certificate, **2 payment certificates**, 5 transmittals and 3
inspections — contractual evidence. ADR-013 therefore proposes three separate operations (export /
archive / ceremonial two-person hard delete) and recommends **archive as the default**.


## 5q. Project archive — BUILT (the answer to "what happens when a project finishes?")

ADR-013 asked whether a finished project should be archived or hard-deleted. **The decision was
archive**, and it is now built. A hard delete remains a separate, ceremonial operation that is
deliberately *not* implemented yet.

**What archiving is.** A project moves `ACTIVE ↔ ARCHIVED`, reversibly. Archived means:
read-only for everyone including the owner, hidden from the portfolio by default, and **not
counted against `plans.max_projects`**. Nothing is deleted, nothing is moved, every certificate and
transmittal stays exactly where it was and stays exportable. There is deliberately **no `DELETED`
state** in `ProjectState` — deletion is not one dropdown position away from archiving.

**Why the quota exclusion is the commercial crux.** A customer on a one-project plan who finishes a
job and cannot start the next one without deleting the first will delete the first. The licence
terms would be quietly instructing them to destroy contractual evidence. Archiving only works as an
alternative to deletion if it is free of the quota — see `ProjectSetupController` (the count is now
`->active()`), and the refusal message now tells them archiving is the way out.

**Two enforcement layers, and both are necessary.**

| Layer | File | Fails how |
|---|---|---|
| Service (refuses first) | `app/Services/ProjectArchiveService.php` | `ValidationException`, translated, actionable |
| RLS (backstop) | migration `2026_09_15_120000_add_project_archive_state.php` | `SQLSTATE 42501` on INSERT/UPDATE; **silence** on DELETE |

Neither alone is enough. The service is forgettable — a new write path that skips `assertWritable()`
gets no protection from it. RLS is mute — see the trap below. So the service exists to produce a
sentence a user can act on, and RLS exists so that forgetting it is merely rude rather than
destructive.

**`epcc_project_is_writable(uuid)` is `STABLE SECURITY DEFINER` and must stay that way.** Without
`SECURITY DEFINER` the function is itself subject to RLS on `projects`, so a session scoped to
project A cannot see project B's state, the lookup returns NULL, and the freeze **fails open**.

**The DELETE hole, found by trying it.** The freeze policy is `FOR ALL USING (true) WITH CHECK
(...)`. `USING (true)` is deliberate — a RESTRICTIVE `USING` clause is ANDed into `SELECT` too, and
an archive you cannot read is just a slow delete. But **`WITH CHECK` is never evaluated for
DELETE**, because there is no new row to check. With only that policy, deleting the punch list of
an archived project reported `DELETE 9` and removed all nine rows. Fixed with a second policy per
table, `FOR DELETE USING (epcc_project_is_writable(project_id))`, which constrains only DELETE and
leaves reads alone. **22 tables × 2 policies.** Verified: archived → `DELETE 0`, rows intact;
reopened → `DELETE 9`.

**UI.** Archive/reopen live on the project page, owner company only (`TenantType::OWN`), with the
reason recorded and shown back as `Archived on <date> by <user> — <reason>`. The portfolio hides
archived projects but always shows a clickable count — hiding without saying so is how a finished
project starts to feel lost.

Tests: `php artisan test --filter=ProjectArchiveTest` — **30 tests**, including the DELETE
regression, the silent-failure documentation, the quota exclusion and the bilingual refusal.


## 5r. Piping lines + numbering + the AFC gate (ADR-006 phase 1) — BUILT

The first piece of the engineering-object spine. A **line** is the unit the whole piping discipline
hangs off: components, joints, welds, NDT, hydrotest and progress all resolve to a line. Phase 1
builds the register, the project-configurable number, and the gate that says *"this line may be
built"*.

### The numbering engine is data, not code

The number format is **per project**, stored as jsonb on `project_piping_config`:

```
{size}-{service}-{class}-{subsystem}-{sequence}-{coating}   →  8-P-A1-PH-14-SS-2201-001-CT2
```

Each token declares `source` (`attribute` | `parent` | `counter`), an optional `width` for padding
and an `optional` flag. **Padding is render-time only** — `sequence` is an integer in the database,
so `MAX(sequence)+1` stays a number and never sorts as `"10" < "9"`.

**Do not parse a number by splitting on the separator.** The separator occurs *inside* token values:
`explode('-', '8-P-A1-PH-14-SS-2201-001-CT2')` yields **9 fragments for 6 tokens**, because the
subsystem code `PH-14-SS-2201` contains three of them. `parse()` builds an anchored regex from the
injected vocabularies instead.

Two PCRE facts the tests now pin:

- **Alternation is first-match, not longest-match.** Usually backtracking hides this (`A1|A1B`
  against `A1B-…` retries and succeeds). It stops hiding it when the *next* token can absorb the
  difference — with `PH-14|PH-14-SS` against `PH-14-SS-2201`, both splits match and the wrong one
  wins silently. Hence vocabularies are sorted **longest-first**. Mutation M1 proves it.
- A relaxed diagnostic token must be lazy `.+?`, and **only one token may be relaxed at a time**.
  `[^-]+` cannot cross a separator, so relaxing everything at once just fails again.

**`compose()` throws; `parse()` never throws.** Composition with a value outside the project
register is a refusal — otherwise an unrecognisable number reaches a drawing. Parsing is diagnosis:
it returns one of four outcomes (no-match / valid / matched-with-`unknownValues` /
matched-but-`unconfirmed`), because `isValid()` and `isFullyChecked()` are different questions when
a number arrives from someone else's P&ID.

### Two doors, and why imports must not feed the counter

`create()` allocates: it locks the **subsystem** row and takes `MAX(sequence)+1`.
`register()` imports: it stores the supplied number **verbatim** and leaves **`sequence` NULL**.

That NULL is load-bearing. An imported `…-777` must not push our next allocation to 778 — we would
be inheriting a foreign numbering scheme's gaps by accident. A non-conforming number is stored with
`number_tokens` NULL and flagged, never rejected and never "normalised": ADR-006 §10.2 forbids
inventing or rewriting someone else's tag. Mutation M10 pins it.

### What AFC actually means, and the B-code trap

AFC — *Approved For Construction* — is the moment the office tells the site **this is safe to
build**. A gate that can be passed without real approved evidence is worse than no gate, because
every downstream report then claims a check happened.

`CdeState::isApproved($state, $suitability)` requires **both**:

| Condition | Why |
|---|---|
| `cde_state === PUBLISHED` | SHARED is issued *for review*, however it is coded |
| suitability starts with `A` | **B1–B5 mean "approved with comments"** — published, valid, *not* fit to build |

Both halves are needed and neither is redundant. **Mutation M8 caught the gap here**: the obvious
"not approved" fixture is SHARED+S2, but S2 already fails the A-check, so the state condition was
never exercised and could have been deleted with the suite still green. The test that separates
them is **SHARED + A1** — right code, wrong container. A null or empty suitability is not approval
either: absence of a code is absence of a decision.

Waving a B-code through is precisely the rework mechanism the gate exists to stop.

**Two defects were found by writing these tests, before any of this ran:** `confirmAfc()` called
`CdeState::isApproved()` — *a method that did not exist* — on `$revision->state`, *a column that
does not exist* (it is `cde_state`, with `suitability` a sibling column).

### States

`DRAFT → AFC_CONFIRMED → RELEASED`, with backward edges to `DRAFT` only. `revertToDraft()` demands
a reason and **nulls** `afc_confirmed_at` / `released_at` — a line pulled back must not keep a
stale approval timestamp that a later report would read as still-approved (mutation M12). Four DB
CHECK constraints enforce known states and AFC/release provenance independently of the service, so
a future write path that bypasses `PipingLineService` still cannot forge an approval.

### UI — `/projects/{code}/piping`

Register, both doors, the gate buttons, and per-line **blockers**: the screen says *why* a line
cannot pass (`Missing: ISOMETRIC, PID` / `Not approved: <doc no.>`), not merely that it has not.

Two UI defects found by driving the real screen with curl after the service tests were green:

1. `UnknownTokenValueException` escaped as a **500**. The engine was right to refuse; the
   controller was wrong to crash. An operator choosing a service the project has not set up is
   making a correctable mistake and is now told which value and which token.
2. The form offered **free text** for vocabulary-controlled tokens. Now they are `<select>`s built
   from the live register, and a token the pattern needs but the project has not populated renders
   as a disabled "not set up for this project yet" notice rather than a box that can only fail.

Note `back()` is wrong for the error path — a form POST may carry no referer, and the redirect to
`/` burns the flashed error. Redirect to the register explicitly.

### Tests

| Suite | Tests | Notes |
|---|---|---|
| `LineNumberingTest` | 24 | pure unit, no DB, ~1 s |
| `PipingLineTest` | 31 | service + RLS, real DB |
| `PipingLineHttpTest` | 6 | the screen, authorization, the two defects above |

**13 mutants killed, 0 survivors** (after fixing the two the first pass exposed): sort order,
`preg_quote`, lazy relaxation, padding, compose validation, regex anchors, both halves of the
approval predicate, the missing-evidence check, import sequencing, counter scope, revert clearing,
participation check.


## 5s. The numbering editor and evidence attachment (ADR-006 phase 1b) — BUILT

§5r left phase 1 *correct but not operable*: the number format could only be changed from tinker,
and evidence could only be attached programmatically. Both are now real screens.

### `/projects/{code}/piping/config` — the numbering editor

Owner-company only. Edits the token list, the separator, and the three project registers
(services, coatings, insulation types). Two blank token rows are always rendered, so adding a
token needs no JavaScript.

**Why this screen needed guard rails more than most.** A number format is the one setting where a
plausible-looking mistake does not fail on save — it fails weeks later, on the hundredth line.
Four rules, each verified rather than assumed:

| Rule | What happens without it |
|---|---|
| Pattern must contain a counter | **Probed the engine first:** composing a counter-less pattern twice with identical inputs returns the identical string, so the second `create()` dies on the uniqueness check with *"number already taken"* — a message naming the symptom and hiding the cause. The project silently caps at one line per subsystem. |
| Counter width may grow, never shrink below what was issued | Padding is render-time, so narrowing does **not** corrupt stored data — which is exactly why it is dangerous. Nothing breaks until the project crosses the threshold, then line 100 renders beside `001` and a text sort interleaves them. |
| Register values may not contain the separator | Every number built from the value becomes unparseable: the regex cannot tell the operator's dash from a structural one. |
| A value used in an existing line number cannot be removed | Removing it renumbers nothing; it just makes those numbers unrecognisable to `parse()`. Paired with a test proving an **unused** value can still be removed, so the rule does not freeze the register solid. |

Well-formedness (one counter maximum, no duplicate token names, non-empty separator) is
**delegated to `NumberPattern`'s constructor** rather than reimplemented, so the two cannot drift.
The service only translates those into a `ValidationException` a form can render.

**Trap:** `AmbiguousPatternException` and `InvalidPatternException` both extend `RuntimeException`
directly and are `final` — neither is a subclass of the other. Catching only `InvalidPatternException`
let the two-counter case escape as a 500. Catch both.

### Evidence attachment, and the gate that could not be escaped

The register now has a document picker per draft line, showing each linked document with its CDE
state and suitability, `✓` or `•` by whether it actually passes.

**Driving the screen found a real defect.** Attaching is *not* exclusive — several documents can
be linked under the same kind, and `unapprovedEvidence()` checks **all** of them. So a B-coded
drawing attached by mistake locked the line out of AFC **permanently**, with no way back except a
database edit. Attaching the correct A-coded isometric afterwards did not help: the bad link was
still evidence.

`detachEvidence()` fixes it, with two constraints:

- **Draft lines only.** Detaching evidence from a confirmed line would erase the justification for
  a decision already taken. Revert to draft first — that path demands a reason and is logged.
- **The link must belong to the line.** Caught by **mutation M21**, which survived the first pass:
  nothing stopped a hand-edited URL pairing line A with line B's evidence link. Both rows sit in
  the same project, so **RLS is perfectly happy** — the ownership check is the only thing between a
  curious URL and quietly stripping evidence off a line the user never opened.

A strict gate must still be escapable by *correcting the input*. That is the difference between a
gate and a trap.

### Confirmed end-to-end through the UI

Attach B-coded ISO + approved P&ID → gate refuses, naming the document and explaining that a B
code is *approved with comments* → detach the B-coded one → attach the A-coded one → **AFC
confirmed**.

### Tests

`PipingConfigTest` 15 · `PipingLineHttpTest` 10 (was 6) · `PipingLineTest` 32 (was 31, +2 archive
guards, −1 duplicate I had added twice).

**Mutants 14–22, all caught** after M21 was fixed: counter-less pattern, narrowing guard,
owner-only, separator-in-value, in-use removal, archive guard, detach-on-confirmed,
detach-cross-line, and `data-tt` on the register table.

### `data-tt-exempt`

`TableToolsTest` enforces that every view with a `<thead>` opts into filter/sort. The config
screen's token grid legitimately must not: **the row order *is* the data** (it is the order tokens
appear in the number), so sorting would corrupt what is being edited and filtering would hide rows
about to be submitted as a set. Rather than weaken the guard, the view declares `data-tt-exempt`
and says why. Verified the guard still bites: removing `data-tt` from the real register table
still fails the test, and there is exactly **one** exemption in the codebase.



## 5t. Units of measure (ADR-014) — BUILT

**User request:** «قابلیت تغییر واحدها مثل فشار، دما و غیره رو ایجاد کن».

### What it does

An engineer types `285 psi`; the owner reads `1965.01 kPa (285 psi)`; a contractor who prefers barg
reads `19.65 barg (285 psi)`. **Nothing in the database changed between those two readings.**

### The storage shape — copy this for every future physical quantity

Three columns per value, not one:

| Column | Example | Role |
|---|---|---|
| `design_pressure` | `285` | **source of truth** — what the datasheet says |
| `design_pressure_unit` | `psi` | **source of truth** — a number without this is not a pressure |
| `design_pressure_kpa` | `1965.005828` | derived mirror, for `WHERE`/`ORDER BY`/indexes |

Storing only the canonical loses the engineer's number: 285 psi round-trips to **285.0006** at
`decimal(12,4)`, so a 150#/300# rating lookup keyed on "285" or "740" misses. Storing only the
entered pair makes "every line above 10 barg" a full scan with a unit-dependent predicate — which
ADR-012 already measured as 0.12 ms vs 1690 ms under RLS.

**A value with no unit gets no canonical.** Guessing is how a psi number lands in a barg column.

### Four rules the engine enforces

1. **Temperature is affine.** `canonical = value × factor + offset`. Multiply-only is wrong by 32
   degrees everywhere (it maps 0 °C to 0 °F). One code path: offset defaults to 0 and collapses.
2. **A difference is not a temperature.** A 50 °C rise is 90 °F, not 122. `convertDifference()`
   uses the factor alone. Nothing calls it yet — it exists so the first delta field finds it.
3. **Gauge never converts to absolute.** They differ by *site* atmospheric pressure, not a
   constant. The converter refuses and the message names atmospheric pressure, so the reader knows
   it is a missing input rather than a missing feature.
4. **Absolute zero is checked on the CONVERTED value**, so −500 °F (−295.6 °C) is caught while
   −400 °F (−240 °C) passes. Enforced in the service *and* as a `CHECK`, so an import path that
   skips the service still cannot write impossible data.

### The menu is narrower than the engine (user decision, 2026-09-17)

Choosable: **pressure → `bar` or `psi`; temperature → `C` or `F`.** Nothing else.

Everything else is retired with `"selectable": false` in the pack — **not deleted**. The engine
still converts kPa, kg/cm², barg, K and the rest, forever, because values already stored and
values arriving from imports must stay readable. Deleting a unit turns historic data into an
unreadable number; hiding it does not.

**Consequence worth remembering: canonical ≠ default display.** Pressure is stored in kPa and read
in bar. Falling back to the canonical unit would show an unconfigured project a unit that is not in
its own dropdown, so the pack carries `default_display` per quantity and `UnitRegistry` has
`defaultDisplayUnit()` separate from `canonicalUnit()`. If you add a quantity, set both.

A refused choice says "kPa is not one of the units this project uses — choose one of: bar, psi",
never "unknown unit", which would be false.

`validate_packs.py` asserts the agreed menu, that every quantity offers at least one unit, and that
`default_display` is itself selectable. Widening the menu is an edit to that file, not a drift.

### Preference resolution

```
user override  →  project default  →  pack canonical
```

`users.unit_preferences` is **nullable**; `project_piping_config.unit_preferences` defaults to `{}`.
**Null ≠ `{}`.** Null on a user means "inherit"; `{}` means "I have chosen". Collapsing them would
freeze a user's display at whatever the project default was the day they first opened the screen.

Project defaults are employer-only and blocked on an archived project. A *personal* preference is
neither gated — it changes no stored value.

### Gotchas found while building this

- **`unitsFor()` returns whole unit definitions, not codes.** Passing them to a `string $code`
  callback is a 500 on page render, not a type error at compile time.
- **`$user->fresh()` returns null after updating a preference.** `users` carries RLS and a bare
  re-read outside a tenant scope sees nothing. `setUserPreferences()` returns the updated model;
  use it. Same trap as the one already recorded for `fresh()` outside `runAs()`.
- **`decimal(16,6)` rounds the mirror.** 150 psi stores as `1034.213594`, not `1034.2135935`.
  Comparing an in-memory value against a stored one fails on the last digit — compare a stored
  read against a stored read. **Reports must print the entered value**, never the mirror.
- **RELEASED has a `CHECK` demanding AFC provenance.** A test that forces `release_state` directly
  must supply `afc_confirmed_at`/`_by` too.
- **The auth proxy on 8099 does not forward POST bodies.** Test write paths directly against 8000
  with a real login, or the CSRF failure looks like a token bug.

### Pack validation

`standards-packs/reference/schema/units.schema.json` + `check_units()` in `validate_packs.py`.
Beyond shape, it verifies: the canonical unit exists and has factor exactly 1.0; no alias collides
with another unit's code; offsets appear only on temperature and datums only on pressure; the six
quantity keys the PHP names still exist; and anchor conversions (285 psi, 1 bar, 1 kg/cm², 1 in,
1 ft, 1 lb, 100 °F, 0 K). **Verified by breaking the pack six ways — all six were caught.**

### Files

`app/Support/Units/{Quantity,UnitRegistry,Measurement}.php` · `app/Services/UnitPreferenceService.php`
· `PipingLineService::{canonicalValues,updateDesign}` · migration `2026_09_15_160000_…` ·
`resources/views/piping/index.blade.php` · `lang/{en,fa}/epcc.php` under `units.*` ·
`tests/Feature/{UnitRegistryTest,UnitPreferenceTest}.php` (63 + 37).

**Mutation testing: 43 mutants on the units layer, 0 survivors.** Two survived first pass: M28 (the
cross-quantity check was masked by the datum check — only PRESSURE has non-NONE datums, so
isolating it needed `mm→kg` and `barg→bara`) and M38 (`updateDesign` had no archive-gate test).



## 5u. Components and ports (ADR-006 phase 2) — BUILT

**The user's question this answers:** «چطور سیستم تشخیص بده که لوله دو port و Tee سه port داره؟»

**It never asks.** The port count, the port roles and the default end types all come from the
component template in the reference pack. `ComponentService::place()` takes a template code and
creates the ports itself; there is no parameter anywhere that accepts a port count, and
`test_the_service_exposes_no_way_to_set_a_port_count` exists to keep it that way.

### The gesture

Pick a component type, pick an open port to attach it to. Everything else is derived:

| Derived | From |
|---|---|
| number and roles of ports | the template |
| the connecting port's size | **inherited from the parent port** — never typed |
| the other ports' sizes | the template's `sizeRule` |
| which end is "branch" / "small" | the port ROLE, not its number |

Size inheritance is what makes *"6″ pipe onto a 2″ branch"* structurally impossible rather than
merely discouraged. An explicit `nominal_size` passed to `attach()` is **discarded**, and a test
asserts the discard.

### Schema

`components` (per line, `UNIQUE(piping_line_id, sequence)`) and **one** `ports` table with an
`owner_kind` discriminator. The nozzle side lands at phase 3b; the column and its CHECK exist now
so that arrival is an INSERT, not a migration. ADR-010 §3.2 rejected sibling tables because every
joint query would then need a two-branch COALESCE.

CHECKs worth knowing: `ports_exactly_one_owner` (a row cannot claim both a component and a nozzle),
`components_size_pair_complete` (NPS string and decimal travel together or not at all — a decimal
without the string cannot be displayed, a string without the decimal cannot be compared, and
dia-inch needs the comparison), `components_length_not_negative`.

`is_connected` is denormalised **on purpose**: "every open end on this line" is the single
most-used query in the system (ADR-009 §2.3) and drives the worklist, the progress metric and the
import validator.

### Rules enforced

- branch ≤ run on a TEE/OLET (`BRANCH_LE_RUN`)
- a REDUCER's two ends must differ — a 6×6 "reducer" is a spool nobody ordered
- a per-port override on a `SAME_AS_FIRST` component (a "6×4 valve") is **ignored**, not honoured
- a length on a component whose template has none is dropped
- NOZZLE is in the pack but **not placeable on a line** — it belongs to equipment
- an unrecognised size is refused, never silently nulled
- RELEASED lines and ARCHIVED projects refuse modelling

### Gotchas found while building this

- **There is no `epcc_can_read_project()` helper.** I invented it from memory and the migration
  failed on `CREATE POLICY`. The real read rule is spelled out inline from `current_setting` —
  copy it from `create_piping_lines`, do not reconstruct it.
- **`->sortBy([fn, fn])` silently does nothing useful.** The array form of `sortBy` expects
  *property/comparison pairs*, not a list of key closures. It presented as P2 listed before P1 in
  the open-ends panel. Use one closure returning a composite sort key.
- **Form vocabulary must map to port ROLES, not port numbers.** The branch is port 3 on a TEE but
  port 2 on an OLET, and a REDUCER has no branch at all. The controller resolves the role to a seq
  from the template; a positional guess would put a branch size on a reducer's large port.

### Two display bugs the screenshot caught that no test would have

Both were found by *looking* at the rendered page, not by running the suite — worth remembering
when a feature is "done and green".

1. **Open and connected ports were near-identical pills.** Both used `var(--line)` borders on a
   dark background. Colour alone also fails a colour-blind reader. Fixed with a dashed amber
   border and a `○` / `●` glyph, plus a legend next to the heading, so the state is readable
   without relying on hue.
2. **RTL reordered the inch mark.** `P2 RUN 6"` rendered in Farsi as `"P2 RUN 6` — the quote
   floated to the visual start of the line. Latin-plus-digit tokens inside an RTL paragraph need
   `<bdi>`; inside an `<option>`, where markup is not allowed, they need a trailing **U+200E LRM**
   instead. Six places on this page were affected. **Check every mixed-script token in FA, not
   just the prose.**

Screenshots of both languages: `docs/screens/model-page-{en,fa}.png`.

### Files

`app/Models/{Component,Port}.php` · `app/Services/ComponentService.php` ·
`app/Http/Controllers/ComponentController.php` · `resources/views/piping/model.blade.php` ·
migration `2026_09_17_120000_create_components_and_ports.php` · routes `piping.model*` ·
`lang/{en,fa}/epcc.php` under `component.*` · `tests/Feature/ComponentModellingTest.php` (39).

Reachable from the line register: each row has a **Model** button.

**Mutation testing: 13 mutants, 0 survivors** (M44–M56).


## 5v. Joints, compatibility and dia-inch (ADR-006 phase 3) — BUILT

The model stops being a parts list here. Every connection is now a row with a number, a state and
a measurable size — the entity Plant 3D does not have, because there a connection is geometry and
here it is a construction object.

### The table

`joints`: uuid pk, `project_id`/`company_id`/**`piping_line_id`** (denormalised — a joint never
moves between lines, and every read is line-scoped), `port_a_id`/`port_b_id`, nullable
`joint_seq`, `numbering_policy`, `joint_type`, `state`, `fitted_by_code`+`fitted_at`, frozen
`nominal_size`/`nominal_size_decimal`/`schedule`/`thickness_mm`, `shop_field`, `spool_id`,
`isometric_sheet_no`, `compatibility_state`+`compatibility_notes jsonb`, `source`, `external_ref`.

Constraints that carry weight:

- **`CHECK (port_a_id < port_b_id)`** plus `UNIQUE(port_a_id, port_b_id)`. Without the CHECK,
  (A,B) and (B,A) both satisfy the UNIQUE and the same weld is counted twice in dia-inch.
  `JointService::orderedPair()` sorts before every write so no caller can get it wrong.
- **Two separate unique indexes on `port_a_id` and on `port_b_id`.** The pair-unique does not give
  this: (A,B) and (A,C) are distinct pairs, so without them port A could be welded to two things.
- `joints_unnumbered_policy_has_no_seq` — a NOT_APPLICABLE joint must not be carrying a number.
  Switching a weld to a flanged connection otherwise leaves the old number on reports forever.
- `joints_fitted_needs_evidence` — FITTED demands **both** `fitted_by_code` and `fitted_at`, the
  same shape as the AFC gate. Who-but-not-when is not auditable.
- Partial unique `joints_line_seq_unique WHERE joint_seq IS NOT NULL`, partial index
  `joints_awaiting_number_idx` for the chase-list.

### Three rules worth not re-deriving

**Dia-inch: the smaller diameter governs, and it is never stored.** `min(portA, portB)`, computed
every time. A stored copy drifts from the ports and the error does not crash — it inflates
progress, which on a job paid by dia-inch is an invoice. Only an approved progress snapshot
freezes it. Flanged joints contribute **nothing**: bolt-up is real work but it is not welding.

**Frozen vs computed is a deliberate split.** `nominal_size`/`schedule`/`thickness_mm` are frozen
onto the joint at creation — a joint accepted at 6"/SCH40 must keep saying so even if a port is
later edited. Dia-inch is the opposite. The distinction: those columns record what was **built**,
dia-inch **measures** it.

**A number nobody uses is a lie that costs.** Welded joints get a per-line sequence from a shared
counter (welded + threaded), allocated under `lockForUpdate()` on the line row. Flanged joints get
`numbering_policy = NOT_APPLICABLE` and **no** number — they are not welds awaiting one. Next
number is **`max()+1`, never `count()+1`**: joints get deleted during modelling and a reissued
number means two different welds on two drawings.

### PortCompatibility — a pure function with three outcomes

`app/Support/Piping/{PortCompatibility,Verdict}.php`. No DB, no locale — the verdict carries
reason **codes**, and translation happens in `Verdict::messages()`, so tests compare verdicts
without string-matching a language file.

| Verdict | Example |
|---|---|
| INVALID | BW onto FL · size mismatch · unknown end code · port joined to itself |
| WARNING | schedule break at equal bore · SW/SW gender unverified |
| VALID | BW/BW equal bore · **PL onto BW** (a field-cut pipe) · anything against `**` |

The schedule check compares the **resolved wall from the reference pack**, not the schedule name.
STD vs SCH 40 at 6" is the same wall and must not nag; at 12" it is 10.31 vs 9.53 and must. Two
tests pin both halves, which is what stops it being "optimised" into a string comparison later.

### What phase 3 fixed in phase 2

`ComponentService::remove()` can now reopen the counterpart port. It separates every joint
touching the component **first**, then deletes its ports — the other order cascades the joints
away and leaves the neighbour flagged connected with nothing attached, invisible to the open-ends
worklist. `markConnected()` is gone; `attach()` returns a `joint` key alongside the component.

### Files

`app/Models/Joint.php` · `app/Services/JointService.php` ·
`app/Support/Piping/{PortCompatibility,Verdict}.php` · migration
`2026_09_18_090000_create_joints.php` · `lang/{en,fa}/epcc.php` under `joint.*` ·
`resources/views/piping/model.blade.php` (joints table + metrics header) ·
`app/Http/Controllers/ComponentController.php` · `tests/Feature/JointTest.php` (**46**).

**Mutation testing: 23 mutants, 0 survivors** (M57–M78), harness restored at **`mutate.sh`**.

Screenshots: `docs/screens/joints-{en,fa}.png`.

### Two things the mutants and the demo caught

- **M64 found a missing test, not a missing guard.** The self-joint check existed; nothing
  asserted it. A PCF import with colliding END-POINT coordinates would have booked dia-inch for a
  weld that does not exist.
- **The demo script's first version was engineering-wrong, and the engine said so.** Welding a
  flanged valve straight onto a pipe was refused; the fixture needed a flange, exactly as site
  would. When a refusal looks like a bug, check the pipework before the code.


## 6. The preview iframe (read before debugging "login is broken")

The preview serves the app in an **iframe whose top-level document is a
different site**, so its cookies are third-party and the browser blocks them.
Symptom: login succeeds server-side, the redirect arrives anonymous, the form
re-renders blank, and **nothing is logged**.

**Five rounds of cookie-attribute tuning failed.** The browser's policy is not
observable from the server, so it cannot be satisfied — the dependency had to be
removed instead. Current mechanism (both positions load-bearing):

| Middleware | Position | Job |
|---|---|---|
| `PreviewSessionFallback` | **first** in `web`, before `EncryptCookies` | Converts a signed `sid` token from the URL/body into a genuine session cookie |
| `PreviewUrlRewriter` | **last** in `web` | Appends the token to links, forms, redirects, Livewire URIs and JSON `redirect` |

Traps, all paid for in debugging time:

- The forged cookie **must be encrypted and carry the `CookieValuePrefix` HMAC**,
  or `EncryptCookies` silently discards it.
- The injected script must observe **`childList` only** — watching attributes
  retriggers on its own writes: infinite loop, white page.
- **Exceptions bypass the whole middleware pipeline**, so `PreviewUrlRewriter::apply()`
  is also called from `$exceptions->respond()`.
- **`URL::forceScheme()` does not touch `$request->fullUrl()`** — `redirect()->back()`
  emitted `http://` and the browser blocked it as mixed content. Fixed by marking
  the connection secure in `ConfigureForPreviewProxy`.
- **`$middleware->replace()` does not touch group middleware** — it fails
  *silently*. Use the `*InGroup` variants.
- **Diagnose from the `sessions` table, not the log:**
  `select to_timestamp(last_activity)::time, count(*), count(user_id) from sessions group by 1 order by 1 desc;`
  Many rows with 0 authenticated per page load ⇒ the cookie is not coming back.
- **Test over `http://` with a preview `Host`.** Driving tests at `https://`
  makes the request secure by construction and silently disables the condition
  under test — one guard here was inert until a mutation test caught it.

The whole mechanism is gated on a preview host **and** `SESSION_URL_FALLBACK`
(default **off**). On a real deployment it is inert.

---

## 7. Testing discipline

```bash
cd app && php artisan test                          # 667 passed / 2751 assertions (~1050 s)
python3 standards-packs/validate_packs.py           # 3 standards + 4 reference packs
node app/tests/Browser/sidebar-toggle.test.cjs      # 17 assertions, needs a fixture
node app/tests/Browser/sidebar-animation.test.cjs   # 19 assertions, computed styles
node app/tests/Browser/table-tools.test.cjs         # 42-47 per page, needs /tmp/tt.html
#   fixtures: SB_FIXTURE= / TT_FIXTURE= override the default paths. Capture a
#   logged-in page first - these drive the REAL shipped script in jsdom.
```

The jsdom tests need `jsdom` at `/home/user` (wiped by every reset — **`restore.sh`
now reinstalls it**) and a captured logged-in page; override with `SB_FIXTURE=`
for the sidebar harnesses and `TT_FIXTURE=` for the table harness. **A missing
`jsdom` prints nothing at all**, which reads like "no tests to run" rather than
a failure — if a harness produces no output, check `node_modules` first.
The app's `package.json` sets `"type": "module"`, hence the `.cjs` extension.

- **A guard test that passes may be inert.** Mutate the fix away and watch it go
  red. **153 mutations have been confirmed caught** this way (123 + 15 pack-data + 15 PHP in phase 0); the practice has
  already exposed three false-confidence tests (the mixed-content guard, a
  sidebar entitlement check, and "the contractor cannot verify its own fix"),
  a guard made inert by its own documentation, and a test that encoded the
  wrong model entirely.
- **`display:inline-block` on a `<td>` silently breaks the whole table.** It
  replaces `display:table-cell`, so the cell leaves the column layout and every
  following column shifts by one - the header ends up over the wrong data. Cell
  COUNTS still match, the DOM still looks right, and jsdom cannot see it
  because jsdom has no layout engine. Diagnosed by measuring
  `getBoundingClientRect()` per cell in real headless Chromium. `.mono` (an
  LTR-run helper meant for `<span>`) had been applied to `<td>` on two screens.
- **Per-page markup drifts, and a one-fixture harness cannot see it.** The
  sidebar harnesses ran against a fixture from a SINGLE page, so three newer
  screens that nested the shell differently were invisible to 345 passing
  browser assertions. `ShellStructureTest` now asserts the nesting order
  (`.app` > `aside.sb` > `.wrap` > `.topbar`) on EVERY screen via a data
  provider. When a partial has a required position, test the position.
- **`@{{ $var }}` silently prints braces.** `@{{ }}` is Blade's escape syntax
  for JS templating. Written as a literal `@` separator it disabled the
  variable and shipped `ips.iran{{ $packVersion }}` to the page. A regex sweep
  for `{{ $` in rendered HTML now covers every screen.
- **A working endpoint is not a reachable feature.** The certificate PDF route
  passed every test while the download link sat inside an `isIssued()` branch,
  so a draft had no way to reach it. Found by loading the live page, not by the
  suite. When you add an endpoint, assert the UI actually links to it.
- **A guard test can be caught by the WRONG GUARD.** `expectException()` only
  proves *something* refused. The self-verification test passed with its guard
  deleted, because the acting company was an `EPC` — a tenant type that is not
  a verifier at all — so a different rule threw. Assert on the **message**, and
  choose fixture actors that can only fail the rule under test.
- **A test can encode the WRONG MODEL and still pass.** `the employer sees every
  letter on its project` asserted a count of 3 and was green — it was asserting
  that the employer could read another company's unsent draft. When a guard
  fails after you fix a defect, first ask whether the *test* was wrong.
- **A jsdom harness can encode one page's shape.** `table-tools.test.cjs` has
  now been fixed three times for this: it assumed the register's column layout,
  then a minimum row count, then a CDE-state column. Assert against what the
  markup *declares* (`data-sort`, `data-facet` counts) rather than magic
  numbers, and use `skip()` so a rule that does not apply to a page can never
  be mistaken for a rule that passed.
- **The oracle must use the same collation as the page.** The harness sorted
  with `<` and flagged correct Persian ordering as a bug: "گ" precedes "م" for
  a reader but follows it by code unit. Both sides now use `Intl.Collator`.
- `DatabaseTransactions` collides with the seeders — use `migrate:fresh --force`
  in `setUp()`.
- CSRF cannot be exercised through HTTP feature tests (`PreventRequestForgery`
  short-circuits on `runningUnitTests()`); call the handler directly.
- `assertRedirect()` is too strict once a query parameter is appended — assert on
  the `Location` header with `assertStringStartsWith`.

---

## 8. Known traps (non-obvious, will cost you an hour each)

- **A bidi-isolated NUMBER is not enough — isolate the whole phrase.** `<bdi>6</bdi> welds ·
  <bdi>2</bdi> fitted` renders in Farsi as **"۶ جوش ۲۰ مونتاژشده ۲۸۰"**: the `·` separator is a
  neutral character sitting between a digit run and a word, so the algorithm attaches it to the
  digits and it reads as part of the next number. The digits were right; the punctuation moved.
  Wrap `number + label` together in one `<bdi>`, and use a separator inside its own element.

- **A mutation run killed by a timeout leaves the mutant IN THE SOURCE.** The harness restores the
  file after each test run; kill it mid-run and the last edit survives. It then looks like working
  code — `if (false) {` sat in `JointService::join()` and the next partial run reported SKIP
  ("pattern did not apply") rather than a failure. After any interrupted run:
  `grep -rn "if (false)" app/app/` and check `git diff` before believing anything.

- **A SKIP from the mutation harness is not a pass.** It means the pattern never applied, so
  nothing was broken and the test suite proved nothing. Treat SKIP as loudly as SURVIVED — the
  harness exits non-zero on either.

- **An equivalent mutant is not a surviving test gap.** `min(null, 6.0)` is already `null` in PHP,
  so deleting the null guard in `diaInch()` changes no observable behaviour. Before writing a test
  to kill a survivor, check the mutation actually alters the result — otherwise you are adding a
  test that asserts the language spec. Retarget the mutant instead (`return 0.0`).

- **`LineReleaseState` is a class of string constants, not an enum.** `LineReleaseState::RELEASED->value`
  throws "Attempt to read property value on string". Use the constant directly.

- **Forcing `release_state = RELEASED` needs TWO provenance pairs, not one.** `afc_confirmed_at`
  + `afc_confirmed_by` **and** `released_at` + `released_by`. Supplying only the AFC pair fails
  with a 23514 that looks exactly like the guard you are trying to test firing.

- **A standalone bootstrap script needs its own `<?php` tag and absolute paths.** `php artisan
  tinker --execute="require '/tmp/x.php'"` printed the file instead of running it (no opening
  tag), and `__DIR__` inside a `/tmp` script resolves to `/tmp`, not the app.

- **Outside a tenant binding, `firstOrFail()` on an RLS table looks exactly like "the seeder never
  ran".** The rows are there; the role cannot see them. Use
  `TenantContext::forIdentityLookup(...)` to resolve the project and user, then `runAs(...)`.
  Confirm with `sudo -u postgres psql` before re-seeding — re-running the seeder hits
  `companies_code_unique` and buries the real cause.

- **When the engine refuses your demo data, check the pipework before the code.** Welding a
  flanged valve directly onto a pipe was refused by `PortCompatibility`; the model was wrong, not
  the rule. The fixture needed a flange, exactly as site would.

- **PCRE alternation is first-match, and backtracking usually hides it.**
  `A1|A1B` against `A1B-…` *works* — the engine tries `A1`, fails the next
  separator, retries `A1B`. So a naive test passes and you conclude ordering
  does not matter. It matters when the following token can absorb the
  difference: `PH-14|PH-14-SS` against `PH-14-SS-2201` matches both ways and
  keeps the **wrong** split, silently attributing a line to the wrong
  subsystem. Sort vocabularies longest-first. See §5r.
- **A test can pin a rule for the wrong reason.** The AFC gate needs
  `PUBLISHED` **and** an A-family suitability. The obvious negative fixture,
  SHARED+S2, fails the A-check on its own — so the `PUBLISHED` half was never
  actually exercised and deleting it left the suite green. Mutation testing
  found it; the fixture that separates the two conditions is **SHARED + A1**.
  When a rule is a conjunction, write one test per conjunct that satisfies
  every *other* conjunct. See §5r.
- **RLS `WITH CHECK` does not apply to DELETE.** A RESTRICTIVE policy with a
  `WITH CHECK` clause blocks INSERT and UPDATE and lets every DELETE straight
  through — there is no new row to check, so the clause is never evaluated.
  A read-only guard therefore needs a *second* policy `FOR DELETE USING (...)`.
  Found by trying it: an "archived" project's punch list deleted cleanly,
  `DELETE 9`. See §5q.
- **A blocked UPDATE/DELETE under RLS is SILENT.** INSERT raises 42501 naming
  the policy, but UPDATE and DELETE simply match zero rows: no error,
  `rowCount = 0`, and Eloquent's `save()` returns **true**. The data is safe and
  the user is told the opposite. Never let RLS be the only thing refusing a
  write that a human is waiting on — refuse in a service first.
- **A `SECURITY DEFINER` helper is mandatory when a policy reads another
  RLS-protected table.** `epcc_project_is_writable()` reads `projects`; without
  `SECURITY DEFINER` it sees only the currently scoped project, returns NULL for
  every other one, and the policy **fails open** — the most dangerous direction.
- **`__()` was only localised inside the Filament panel.** `SetUserLocale` was
  registered on the admin panel alone, so on every other route the translator
  used the default locale. The hand-written views hid this for months because
  they take language from their own `?lang=` closure — the page was Persian and
  only the `__()` strings were English. It surfaced the moment a *service* threw
  a translated exception. Now registered on the `web` group too, before
  `PreviewUrlRewriter` (which must stay last).

- **`pg_dump` exits 0 after an RLS abort.** Under `FORCE ROW LEVEL SECURITY` the
  dump fails part-way and still returns success, leaving a truncated file. Never
  trust the exit code — compare the output size or the row counts against a
  manifest. See §5p.
- **A topological sort over the schema drops any FK cycle.** `documents` and
  `document_revisions` reference each other, so a recursive dependency ordering
  returns 21 of 25 tables and loses the whole document register without error.
  Order such lists explicitly, and load with
  `SET session_replication_role = replica`.
- **`x IS NULL OR col = x` in an RLS policy disables every index on `col`.** It reads
  like a harmless convenience ("unbound means all") and it silently forces a
  sequential scan forever. At fixture scale a seq scan is the *correct* plan, so
  this is invisible until a million rows exist. Check `Rows Removed by Filter`
  in `EXPLAIN (ANALYZE)` — if it is orders of magnitude larger than the rows
  returned, the predicate is not sargable. See §5o.
- **Benchmark a security policy and you will select the insecure version.** The
  fastest form of the tenant policy is the one that returns zero rows for the
  cross-project view. Every correctness probe must be run alongside the timing,
  in the same script, or the fast-and-wrong answer wins.
- **The backup was archiving itself.** `tar -czf source-backup.tar.gz .` from the
  repo root includes the *previous* `source-backup.tar.gz`, so each refresh
  nests the last one and the file roughly doubles. It also swept in republished
  Filament assets (`app/public/{js,css}/filament`, ~3 MB) and compiled Blade
  views, all of which `restore.sh` regenerates. Exclude the tarball itself, the
  published assets, `storage/framework/views` and `storage/framework/testing`;
  then **diff the entry list against the old one** — a pure size comparison
  cannot tell "captured more source" from "captured more garbage". Current:
  **3,469,495 B / 418 entries**, extraction verified in `/tmp` before replacing
  the old file.
- **Numeric string keys are integers in PHP.** `json_decode(..., true)` turns
  `"40"` into array key `40`, so `array_keys()` on a schedule table returns a
  mixed `int|string` list. Strict `in_array()` then fails silently and passing a
  key to a `string`-typed parameter is a `TypeError`. Cast at the boundary with
  `array_map(strval(...), …)`.
- **An assertion about data only tests the direction the data exercises.**
  `PipeReferenceTest` asserted STD ≠ SCH 40 at 12″+, which felt like complete
  coverage of the alias question. It was not: a fallback from a missing schedule
  to its "equivalent" survived, because STD is never the missing one. The
  reachable case is the reverse — ASME defines STD at 22″/26″ but no SCH 40
  there at all. Only mutation testing found it.
- **Anything that reaches the internet is invisible in a connected sandbox.**
  A URL assembled at runtime (Filament's avatar provider) exists in no file, so
  grep and any static scan report a clean build. Capture a browser net-log, or
  assert on rendered HTML. `php artisan verify:airgap` is the standing check.
- **Render at a phone width before believing a page works.** A page can be
  200, structurally perfect and still paint nothing; in RTL an overflow does
  not clip, it evicts the document from the viewport. Measuring unique colours
  in a screenshot is a cheap, reliable blank-page detector (1 colour = blank).
- **A document that asserts something about a moment must snapshot it.** Any
  number a certificate, transmittal or approval renders from a live query will
  drift after the fact, and the drift is not random — it flatters, because the
  work continues in the direction the document was hoping for. Ask of every
  figure on an issued artefact: *is this a fact about then, or a report about
  now?* (§5e). Test it by producing the artefact twice with a real change in
  between; a single render can never show this.
- **`pkill -f "artisan serve"` kills the calling shell.** Use the process tools.
- **`artisan serve` caches `bootstrap/app.php`** — restart it; `config:clear` is
  not enough.
- **Sandbox resets wipe the runtime, not the source** (7× so far). Snapshots cap
  at ~10,000 files / 128 MB and truncate *silently*, which is why
  `app/vendor` is a symlink into `~/.cache/epcc-vendor`.
- **Seeded attachments will blow the file cap if nothing purges them.** Every
  `migrate:fresh --seed` mints new project UUIDs and writes real blobs under
  `storage/app/private/documents/{project_id}/{ab}/{cd}/`. Nothing removed the
  previous run's tree, so it reached **5,066 project folders / 12,963 files**
  and pushed the workspace to 13,263 — past the cap, which truncates in
  silence. The content-addressed fan-out makes this a file-**count** problem
  (~31,000 directories) long before it is a disk-space one (58 MB).
  `tests/bootstrap.php` now purges that tree **before and after** every suite,
  and `BlobIntegrityTest` re-verifies each surviving blob against its SHA-256
  so the purge can never quietly delete live data.
  **Check `find /home/user -type f -not -path "*/vendor/*" -not -path "*/.cache/*" | wc -l`
  when anything writes files in a loop.** It should be in the low hundreds.
- **Never pin `APP_URL` to a sandbox host** — it is stale after the next reset.
  It stays `http://localhost:8000`.
- **The pack ID is `ips.iran`, but it is addressed by basename `ips-iran`** in
  the database and forms.
- **`WithoutModelEvents` in a seeder breaks `HasUuid`.**
- **The `?as=` tenant-switch parameter is deliberately dead.** Do not reflect
  arbitrary query parameters into links — `ViewServiceProvider::CARRIED_QUERY`
  is an allowlist for exactly this reason.

---

## 9. Suggested next steps

**ADR-006 phase 1 — BUILT (2026-09-15).** `piping_lines`, the per-project numbering engine and
the AFC gate, with a working register screen at `/projects/{code}/piping`. See **§5r** for the
engineering content, the B-code trap and the 13 killed mutants. **Next is phase 2: ports and
components** (`components` → `component_ports`), then 2b the manual modelling UI, then 3 joints
with `diaInch()`.

**Phase 1b closed all three items phase 1 left open** (see §5s): the numbering editor exists, the
register has a document picker with detach, and `assertWritable()` turned out to be wired into all
six piping write paths already — it just had no test, which it now does (two, in `PipingLineTest`).

Left open by phase 1b, in the order I would take them:
1. **The pattern editor cannot reorder tokens.** Rows are edited in place and blank rows append;
   changing `{size}-{service}` to `{service}-{size}` means retyping both. Drag-and-drop needs
   JavaScript, but up/down buttons would not. Minor, and invisible until someone tries it.
2. **No preview of the next number while editing.** The screen shows the *current* sketch; it
   cannot show what the number would look like under the pattern being typed without a round trip.
3. **`insulation_types` is editable but unused** — no token reads it yet. Harmless, but it is the
   kind of half-wired field that later gets mistaken for dead code and deleted.

**ADR-007 (`docs/ADR-007-…md`) — ACCEPTED AND BUILT (2026-09-15, phase 0).** The engineering
reference packs: 36 sizes, 355 schedule pairs, 13 end types, 20 component templates, behind
`PipeReference`. See §5m for the traps. **This is phase 0 of the consolidated build order in
ADR-010 §5.**

ADR-006 is now **PARTLY BUILT** (phases 1, 1b, 2 and 3 of 7). ADRs 008, 009 and 010 remain PROPOSED (analysis only). Three questions at the end of
ADR-010 are still unanswered by the user: equipment tag uniqueness (per project vs per
facility — I lean per facility), whether an instrument register is needed now, and whether
equipment tags are imported-and-validated rather than allocated.

**ADR-004 (`docs/ADR-004-…md`) — ACCEPTED AND BUILT (2026-09-13).** `project → facility →
(optional) area → subsystem`. Investigated rather than assumed: Plant 3D has **no
System/Subsystem, no MC, no punch, no handover** — it is a design authoring tool whose
"hierarchy" is a fixed 3-node folder tree plus `Area`/`Unit` as **string tag subparts** in a
SQLite `.dcf` PnPDatabase, so compatibility means a documented **import mapping**, not a copied
schema. Built Option B: one `facilities` table with a `FacilityKind` discriminator, an
**optional** `areas` level (= Plant 3D Area = AWP **CWA**), per-kind addressing in validated
`jsonb`. `subsystem_id` did **not** move — all 6 dependent tables untouched. The four open
questions are now answered in ADR §5; the load-bearing decisions:

- Numbering is **per facility** — `UNIQUE(project_id, code)` became `UNIQUE(facility_id, code)`,
  so `PL-01/SS-01` and `PL-02/SS-01` are both legal. The admin register therefore shows Facility
  as a non-toggleable column: the bare code alone is now ambiguous.
- `subsystems_area_within_facility`, a **composite** FK `(area_id, facility_id) → areas
  (id, facility_id)`, makes "area belongs to another facility" unrepresentable rather than
  merely discouraged.
- `PIPELINE` is in `FacilityKind::all()` (importable) but excluded from `selectable()` — KP
  stationing is deferred, and the `addressing` jsonb means adding it is data, not a migration.
- `fullCode()` composes `"{facility} / {code}"` at read time; storing it would drift on rename.

Six mutations (M118–M123) confirm the new rules. **M118 first reported SURVIVED and that was
the mutation's fault, not the test's** — dropping a constraint with `psql` proves nothing when
`setUp()` runs `migrate:fresh` and rebuilds it. Mutate the **migration source**.

**ADR-006 (`docs/ADR-006-Piping-Line-Component-Joint-Model.md`) — PROPOSED, all ten questions answered (§10, §11). Ready to build; phase 0 is ADR-007.**
The user corrected a category error in ADR-005: isometrics and support drawings are not things
to *file*, the system needs **their content**. Model: `subsystem → piping_lines → components →
component_ports → joints`, with the port model adopted from Plant 3D's `PartPort` /
`P3dPartConnection`. Key findings: Plant 3D stores a connection as a **relationship row**
(part1/port1/part2/port2) and has **no joint number, no weld, no NDT** — the joint is *geometry*
there and a *construction object* here. **PCF is the import path**: ports are explicit
(`END-POINT x y z bore ENDTYPE`), a TEE really does emit 3 keypoints, and **welds are already
first-class** with `CATEGORY FABRICATION|ERECTION` = shop/field. Line numbering is
**per-project configurable** (the PMS is the authority, not the standards pack) and must
**parse as well as compose**, so the pattern is stored as typed tokens, not a `{}` string.
Compatibility returns **three** verdicts (VALID/WARNING/INVALID) — a boolean would make every
spec break either a lie or a blocker, the same reasoning as advisory inspection.

**The answers changed the shape.** Joint numbering is **per line and conditional**: welded and
threaded joints need a number, flanged ones do not. That makes `joint_number` nullable for *two
different reasons*, which must not be conflated — so `numbering_policy` (REQUIRED |
NOT_APPLICABLE) is stored, guarded by a **partial unique index** plus a CHECK. Spiked on this
PostgreSQL first (no partial-unique precedent existed in the schema): unnumbered flanges and
unnumbered imported welds coexist, duplicates rejected, a *numbered* flange rejected. Import
**must not invent numbers** — an unnumbered welded joint is a valid row and needs its own
worklist. Joints gained a state machine (**MODELLED → FITTED**, `fitted_by_code` + `fitted_at`
mandatory on entry); **`fitted_by_code` is a string, not a `users` FK** — verified there is no
personnel table and `users` holds office accounts, so a pipe fitter has no login and must not be
forced into the identity RLS policies. Supports are **part of the line but their own register**
(no ports, so no fake component rows). Spools are an **optional grouping** (nullable `spool_id`),
not a level — same reasoning as optional `areas` in ADR-004. `isometric_sheets` was **deleted**:
components derive from the **MTO** (`mto_item_no`, the missing link to
`material_requisition_items`), and the sheet is just a string on components and joints; pipes
carry `length_mm` under a type-conditional CHECK.

**Second round resolved the rest.** Joint number is a **simple integer sequence per line**,
welded and threaded sharing one counter, allocated under `lockForUpdate()` on the parent line —
stored as an int, padded only in the view (storing `"007"` turns sorting and next-number into
string surgery). **Flanged joints stay unnumbered** (my recommendation, accepted): a number
nobody uses gets quoted in reports and then has to be broken when the bolt-up register arrives
with its own scheme; they lose nothing meanwhile, since they are still rows, still
compatibility-checked. Supports get the **same typed-token numbering engine** as lines, fed by
the Standard Support / Support Details / Support List documents.

**ADR-007 (`docs/ADR-007-Reference-Data-Engineering-Standards.md`) — PROPOSED, new.** The user
asked where universal constants live «که به دیتابیس فشار وارد نکند». Answer: **versioned JSON
reference packs** beside `standards-packs/`, read-only, **no RLS** — and the reasoning matters:
RLS on reference data could only ever be "everyone can read", a policy that fails open, whereas
the real guarantee needed is *nobody can write, including the owner*. A file gives that
absolutely. It also dodges the ADR-004 trap where a seeder cannot read an RLS-forced table.
Split: **universal** (NPS/DN/OD, schedules, end types, flange ratings) → reference packs;
**per-project** (piping classes from the PMS, services, coatings) → normal tenant tables.

**ADR-010 (`docs/ADR-010-Equipment-Nozzles-and-Dia-Inch.md`) — PROPOSED, new.** Closes ADR-009's
three questions.

- **Dia-inch: the smaller diameter governs.** `min(portA, portB)`. Measured on a 5-weld sample:
  **19.0 vs 27.0** under the other reading — a **42% overstatement**, and on a job progressed or
  paid by dia-inch that is a commercial number. Computed, **never stored on the joint** (it would
  drift from the port sizes), *except* frozen into an approved progress snapshot. The test must
  contain **reducing** welds — an equal-bore fixture passes under either convention and proves
  nothing, the same trap as testing schedules only at 2".
- **Component templates get two tiers.** Universal set (PIPE/ELBOW/TEE/…/NOZZLE) ships read-only
  in the reference pack — a tee has three ports everywhere and that is not a project opinion.
  Projects may add their own (Victaulic coupling, vendor connector) but **may not shadow a
  universal code**; same closed-vocabulary / configurable-subset split as `FacilityKind::all()`
  vs `selectable()`.
- **Equipment: a nozzle is a port owner, so `joints` needs NO change.** Verified with a spike —
  one `ports` table, `owner_kind ∈ {COMPONENT, NOZZLE}`, a CHECK enforcing exactly one owner FK.
  A COMPONENT↔NOZZLE joint inserted with the joints table untouched; a mixed-owner row rejected
  by `check_violation`. Mirrors Plant 3D, where `AssetOwnership` links equipment to nozzles and a
  nozzle is a `NozzleSubPart`, not a line component. **Rejected** the alternative (separate
  `nozzle_ports` + `port_a_kind`/`port_b_kind` on joints) because every joint query would become
  a two-branch UNION — the same smell that argued for one `facilities` table in ADR-004.
- `equipment.subsystem_id` means equipment **joins the existing completion machinery for free**:
  punch, MC and material status are already keyed to subsystems. Biggest immediate win: a 6" 300#
  RF nozzle against a 6" 150# RF flange becomes a **hard INVALID at entry**, instead of being
  discovered at bolt-up with the crane hired.
- Equipment lands at **phase 3b**, not phase 1 — lines keep free-text endpoints until then and
  upgrade to nozzle FKs without migrating a single joint.

**ADR-009 (`docs/ADR-009-Manual-Modelling-and-Component-Templates.md`) — PROPOSED, new.**
Answers "how does manual entry work, and is the model PCF or Plant 3D?".

- **The user never types a port count.** Ports are a property of the component *class*, declared
  once in a **component template** shipped as reference data — verified that this is exactly how
  Plant 3D works: the catalog template holds properties "shared by all sizes", and
  `PLANTPARTCONVERT` is the command that *adds ports* to a custom block before it can be a
  piping component. Chain maps 1:1 — Plant 3D catalog → our `component_templates`; spec →
  `piping_classes`; placed part → `components`.
- **Manual flow is "pick a type, pick an open port".** Simulated end-to-end: adding a 6"×6"×2"
  TEE materialises 3 ports with roles RUN/RUN/BRANCH; attaching a PIPE to P3 inherits the 2"
  size and creates the joint implicitly. Port count, sizes, schedule, end type, wall thickness
  and the expected branch component are all **derived**. **The "open ends" list is the whole UI**
  — same query drives the worklist, progress and the import validator.
- **Structural refusals vs engineering warnings**: attaching to a taken port or typing a
  mismatched size is *impossible*; a spec-break schedule change or a branch component that
  differs from the class table is a *warning/deviation*. Same split as advisory inspection.
- **PCF vs Plant 3D is a false choice — they are different layers.** Conceptual model from
  **Plant 3D** (ports belong to a class; a connection is a relationship row). Import format
  **PCF, primary** — text, vendor-neutral, emitted by CADWorx/AVEVA/SmartPlant too, and it
  already carries welds with `CATEGORY FABRICATION|ERECTION`. Reading `.dcf` would tie us to
  Autodesk **and Windows** and still would not give welds. Commercially decisive for Iran, where
  CADWorx and AVEVA are common.
- **NPS is stored in four columns** at the user's instruction: `nps_label` "2 1/2",
  `nps_decimal` 2.5, `dn` 65, `od_mm` 73.0. The decimal column is **load-bearing, not
  redundant** — it is the only one that can be summed, and **dia-inch of accepted welds** is the
  stated purpose. Tested: summing the string column raises `ValueError` and sorting it puts
  `12` before `2 1/2`.
- **ADR-008's four questions all closed** (ADR-009 §4): branch rules stay 2-D; **equal and
  reducing tees are ONE `TEE` type** with the reduction *derived from port sizes* (a stored
  `REDUCING_TEE` could contradict its own ports); **no class inheritance** — `parent_class_id`
  dropped; **published classes lock**, edits create a revision and lines keep pointing at the
  revision they were issued against.
- The user corrected the size-band example (no size is in two bands). **Half-open ranges and the
  exclusion constraint stay** — they now encode that intent exactly, and guard it against
  transcription error rather than against the user.

**ADR-008 (`docs/ADR-008-PMS-Piping-Class-Rules.md`) — PROPOSED, new.** How a PMS piping class
expresses size-dependent rules («۱/۲ تا ۴ اینچ SCH80، ۴ تا ۱۰ اینچ SCH40») and the branch table.

- **Half-open DN ranges `[from, to)`, never inclusive text.** The user's own sentence has 4" in
  *both* bands — obvious to an engineer, fatal to a database. Keyed on **DN integers** because
  NPS is a label (`1 1/4`, `1.25`, `1-1/4`, `۱¼`), not a number.
- **One table `piping_class_rules` with a `rule_kind` discriminator** — schedule, end prep,
  valve type, flange type, gasket, bolt spec all share the shape. Same pattern as `MovementType`
  and `FacilityKind`.
- **`EXCLUDE USING gist (class WITH =, rule_kind WITH =, dn_range WITH &&)`** makes overlapping
  bands unrepresentable. **Verified on PG 17.11:** half-open bands accepted, DN100 resolves to
  exactly one rule (SCH 40), DN80 to SCH 80, and the *inclusive* spelling of the same sentence
  is **rejected** with `exclusion_violation` naming DN100. Needs `btree_gist` — **already
  installed in the dev DB** by the spike; the migration must `CREATE EXTENSION IF NOT EXISTS`.
- Overlap is impossible but **gaps are not**, so coverage is checked with PG 17 `range_agg`:
  one contiguous fragment = complete, more than one = holes. Becomes a **publication gate** on
  the class.

**The branch table spike changed the design — record this.** I first tried the same exclusion
constraint in two dimensions. It **rejected two perfectly legitimate PMS rules** (`[15,600)×
[15,600)→TEE` plus `[50,600)×[15,50)→WELDOLET`), because a specific rule's footprint sits inside
the general one. Every real branch table is written as *general rule + specific exceptions*, so
**overlap there is a feature, not corruption**: `UNIQUE` on the exact footprint only, and
resolution by **specificity — narrowest `header span + branch span` wins**. Verified: three
rules match the 6"×1" cell and SOCKOLET (tightest) is correctly chosen, while 6"×6" gives TEE.
`branch_dn ≤ header_dn` cannot be a row CHECK (it is a property of the query, not the row) so it
lives in the resolver with its own exception.

**Two-layer validation, deliberately separate:** ASME says what *exists* (INVALID if not),
the PMS says what is *specified* (DEVIATION if not). A 6" SCH 60 pipe is real and wrong — one
layer alone would either lie or miss it. Same philosophy as advisory inspection.

**A real trap caught while verifying that data.** Published B36.10M tables *disagree* on
large-bore walls because some print **STD** values under a column labelled **SCH 40**.
Verified: **STD diverges from SCH 40 at 12" and above** (12" is 10.31 vs 9.53) and **XS diverges
from SCH 80 at 10" and above** (fixed at 12.70). So STD/XS/XXS are **first-class schedules, not
aliases**, and the tests must assert the *divergence* — a fixture checking only 2" and 6" would
pass on a completely wrong large-bore table.

**Benchmarked before proposing** (2M rows, real RLS policy, role `epcc`): indexed fetch of one
line's ports **0.45 ms** — the policy's `EXISTS` is hashed once, not per row — but a full-scan
aggregate is **2,248 ms vs 204 ms without RLS, an 11× penalty**. So: normal screens are safe,
and **piping progress roll-ups must be incrementally maintained, never aggregated live.** That
is a *new* rule — `subsystemMaterialStatus()` (WarehouseService:441) computes live today, which
is fine at its current scale but must not be copied into the piping module.

**ADR-005 (`docs/ADR-005-Engineering-Data-Ingestion.md`) — PROPOSED, depends on ADR-004.** The
user wants the system usable *before* construction starts and *before* material reaches site,
fed by Excel and by Navisworks exports, carrying PMS, MTO, isometrics, line list and support
drawings. **The decisive finding: NWD/NWF/NWC cannot be parsed** — proprietary, Windows-only,
spec not public, and Navisworks itself exports only DWF/FBX/KML (geometry without properties;
Freedom cannot export at all). So the ingestion path is the **property export** the model owner
produces from Navisworks Manage, never the model file. Do not promise NWD upload.
**PCF is the best available source** — plain text, ISOGEN's own input format, emitted by Plant
3D / CADWorx / AVEVA / CAESAR II, giving every component with bore, item code, coordinates and
weight: an MTO nobody typed, parseable with no library and no licence.
Design: **one neutral `engineering_items` baseline** carrying `source_kind` + `confidence`, fed
by several importers; **versioned immutable `import_batches`** (never truncate-and-reload, or a
re-import silently deletes the baseline a PO was raised against — and keeping batches yields the
Rev B→Rev C diff for free); staged `upload → preview → commit` so a 40k-row file that fails at
row 39,999 leaves nothing behind; **`import_profiles`** so a new client's column headings are
configuration, not code; **PMS as an advisory validator**, matching the inspection choice already
made. Already present and reusable: `openspout` 4.32 + `league/csv` (installed), `jobs` /
`job_batches` / `failed_jobs` (migrated, `app/Jobs/` does not exist yet), and the CDE for
isometrics/support drawings. Five phases in §6 of the ADR; **Phase 1 is independently useful**.
Five open questions — the most useful thing the user can supply is **a real sample of each file
type**. A browser 3D viewer is explicitly **out of scope**.


> **Full itemised status — what is done and what is not — lives in
> `docs/TODO.md`.** It is the answer to "where are we?"; this section is only
> the short priority order.

Roughly in value order. None is started.

1. ~~**Filament v4 admin panel**~~ — **done**, see §5i. Five resources
   (Document, PunchItem, Transmittal, User, Subsystem). `companies` is
   deliberately uncovered (it is not an RLS-scoped tenant table).
2. ~~PDF export~~ — **done**, see §5f. Remaining: the payment certificate
   (صورت‌وضعیت) and the punch register still have no PDF.
3. **Procurement, HSE, Schedule** module groups.
4. **Installer + air-gap verification** (`verify-airgap`, AG-01…AG-06).
5. **Extend QA/QC**: RFSU certificates (A+B gate — `blocksReadyForStartUp()` is
   already written and tested but nothing calls it), **subsystem bulk import**
   (the reason the admin resource has no create form — see §5i-3),
   punch photos on `DocumentFileStore`.

~~Transmittals (FR-ENG-05)~~ — **done**, see §5d.
~~QA/QC + punch list (FR-COM-04/05)~~ — **done**, see §5e. `awp` is now the only
module still in `PLANNED_MODULES`.

---

## 9a. Git remote — and why the config keeps disappearing

> **State as of 2026-09-18 (end of phase 3): PUSHED AND IN SYNC.** Remote `main` and local
> `main` are both at **`c442de8`** (phase 3 — joints, compatibility, dia-inch), **376 files**.
> The eight-commit backlog that had built up since `edc2925` is gone: the range
> `edc2925..c442de8` covers phase 1, phase 1b, ADR-014 units, the units menu narrowing,
> phase 2 components/ports, the RTL/legibility fixes and phase 3.
>
> Verified after pushing, not assumed: `git ls-remote` returns the same SHA as `git rev-parse
> HEAD`; the pushed tree contains **no** `.env`, `.netrc`, credentials file or
> `source-backup.tar.gz` — only `app/.env.example`, whose secret-shaped keys are all empty.
>
> **The token was not persisted, by design.** It was passed inline to a single `git push` via a
> one-shot `https://x-access-token:TOKEN@…` URL and never written to `.git/config`,
> `.git-credentials` or the `origin` remote (confirmed by grep). `origin` is registered with the
> plain HTTPS URL, so it is usable for `fetch`/`ls-remote` but a future push will ask for a
> credential again — which is the intended posture. Expect to mint a fresh fine-grained PAT
> (**Contents: Read and write**, scoped to `epcc-platform`) next time; assume this one is spent.


**`github.com/iman-taheri59/epcc-platform`** (private). Current `main` =
**`c442de8`**, 376 files. `app/.env` and `source-backup.tar.gz` are gitignored
and have been confirmed absent from the remote tree.

**The recurring trap:** `.git/config` is on the snapshot exclusion list (along
with `.git-credentials` and `.netrc`), so **every sandbox reset wipes the remote
URL and the committed identity**. Symptoms, in the order you will hit them:

1. `git commit` fails with *"empty ident name"* — fix with
   `git config user.email … && git config user.name …` (repo-local is fine).
2. `git push origin main` fails with *"repository does not exist"* — the
   `origin` remote is simply gone, not misconfigured.

**Do not paste the token into the remote URL.** Push with a one-shot URL so it
never lands in a file that could be committed or archived:

```bash
git push "https://x-access-token:${TOKEN}@github.com/iman-taheri59/epcc-platform.git" HEAD:main
git remote add origin https://github.com/iman-taheri59/epcc-platform.git   # tokenless
```

Pipe the output through `sed "s|${TOKEN}|***|g"` — git echoes the full URL on
error, and that output otherwise ends up in the transcript.

**Verify the push against the API, not the push output.** This repo has twice
reported `size: 0` and a stale `pushed_at` for a non-empty tree. Compare
`git/ref/heads/main` to `git rev-parse HEAD`, then list
`git/trees/main?recursive=1` and check the files you expect.

**A fine-grained PAT is scoped to a repo LIST, and a missing repo looks like a
404, not a permission error.** A token that authenticates perfectly
(`/user` → 200, correct login) can still return **404 Not Found** for
`/repos/<owner>/<repo>` and `403 Write access to repository not granted` on
push — because the repository was simply never added to the token's
*Repository access* list. 404 rather than 403 is deliberate on GitHub's part:
it avoids confirming that a private repo exists.

Diagnose it in one call before assuming the token is broken or expired:

```bash
curl -s -H "Authorization: Bearer $PAT" \
  "https://api.github.com/user/repos?per_page=100&affiliation=owner" \
  | python3 -c "import json,sys; [print(r['full_name'], r['permissions']['push']) for r in json.load(sys.stdin)]"
```

This listed exactly one repo — `iman-taheri59/awp-epcc`, an **unrelated
project** (Laravel at the repo root, Docker, `phases-*` branches, last pushed
2026-09-07) whose history shares no commit with ours. Pushing there would have
needed `--force` or a nonsense merge and would have damaged someone else's
work. **If the reachable repo is not the one you expect, stop and ask** — the
fix is on GitHub (add the repo, Contents: Read and write), not in the shell.

**Push status:** `main` = **`04fe0ad`**, pushed 2026-09-15 and verified through
the API (branch sha, five spot-checked new paths, HANDOFF §5q present). Local
and remote are level; nothing is outstanding.

**Token hygiene:** tokens have been pasted into the chat twice. Treat every one
of them as compromised and rotate it once the push is confirmed — a PAT with
repo scope on a private commercial codebase is the whole product.

## 10. Session log

### 2026-10-12 — requirement recorded: branch welds are first-class joint types (P-21)

Owner question: «آیا لوله‌ای که به‌عنوان انشعاب به هدر متصل می‌شود
کامپوننت به حساب نمی‌آید؟» — answer: no, a P2P connection adds no
component; the connection is a weld (plus optional pad material), and the
branch pipe is line run. Follow-up instruction: «به عنوان یک نیازمندی ثبت
کن». Recorded as **proposal P-21** (register + detail section): by the time
the welding/joints phase (roadmap P5) is designed, the joint register must
carry `BRANCH_STUB_IN` / `BRANCH_STUB_ON` as first-class joint types —
branch welds counted/reported separately from butt welds, dia-inch kept
clean of them (or deliberately weighted), pad thickness traceable from the
ADR-008 class rule, and class-contradicting joints surfaced as deviations.
Cross-linked in ADR-008 §9.2 and roadmap P5. Nothing built — it is queued on
the P5 design ADR.

### 2026-10-12 (cont.) — standing duty established: systematic requirements review; first piping pass

Owner critique: requirements were only extended reactively — the P2P gap
(standard PMS vocabulary, absent from every requirement doc until supplied
by the owner) is the proof. Directive recorded: **before each build phase,
the requirement set of the target domain is audited for gaps, contradictions
and staleness; cheap hygiene fixed on the spot, decisions become numbered
proposals.** First pass delivered in `docs/REQUIREMENTS-REVIEW-PIPING-EN.md`
(findings R-1…R-8):

- **R-1 FIXED** — ADR-008 §4 stale `→ component_type` definition: pointer
  to §9.1 added.
- **R-2 FIXED+P-22** — ADR-006 joints: no branch-weld types, and the
  two-port model cannot express a weld on the header wall. Vocabulary
  pointer added; §13 forward requirement written; wall-attach modelling
  registered as decision P-22 (leaning: synthesised wall port, PCF
  `TEE-SET-ON` style).
- **R-3 FIXED** — ADR-009 deviation matrix gained the two P2P rows (fitting
  present where class says P2P, and mirror); attach geometry waits on P-22.
- **R-4 FIXED** — ADR-010 §6 gained open question 4: branch-weld dia-inch
  (leaning: branch nominal, reported separately per P-21).
- **R-5 P-23** — MTO requirements have zero branch-connection coverage:
  reinforcement pads (plate) and coped stub ends. Scope decision, waits.
- **R-6 FIXED** — FA roadmap synced (P1 status + P2P/stub/pad addendum, P5
  branch-weld bullet).
- **R-7/R-8 OK** — ADR-010 §4 row 008 and ADR-006 §11.2 re-checked against
  the P2P decision; no conflict.

Protocol registered in `IMPROVEMENT-PROPOSALS-EN.md` ("Standing process —
requirements review"). Next passes: one discipline per session, oldest ADR
first; P2 (equipment/nozzles) still blocked on ADR-010's questions.

### 2026-10-12 (cont.) — research: how Plant 3D and PCF handle P2P branches

Owner asked how Plant 3D / the PCF format treat a pipe-to-pipe branch.
Researched against Autodesk support/KB/forum sources, the PCF Reference
Guide v13, Hexagon CADWorx/ISOGEN docs, and Bentley AutoPIPE threads;
recorded in `docs/RESEARCH-PLANT3D-PCF-P2P-BRANCHES-EN.md`. Findings:

- Plant 3D: **Stub-in** is a first-class routing option (pipe-to-pipe, no
  tee, weld directly on the line); the weld is internally a **"tap weld"**
  with an ordinary butt-weld SKEY (WW/WS) and a **TAP** end code on the
  branch pipe (end-type PL, cut like BW). No automatic reinforcement pad.
- PCF: no stub-in entity exists — the idiom is the **tap connection**: the
  branch pipe's END-POINT starts at a point on the header wall and ISOGEN
  resolves it by projection onto the header centreline within the header's
  end points. Set-on fittings are `TEE-SET-ON`; set-on P2P without a
  fitting is CADWorx `OTAP` (SKEYs TTSO/TSSO) — still tap semantics. Cut
  length is decided at iso time (ISOGEN Option Switch 2).
- Interoperability: wall connections are the fragile part of PCF — olets
  get mapped to welded tees by consumers, and Plant 3D stub-ins are a known
  import failure in AutoPIPE. Importer (roadmap P7) must resolve taps by
  projection and never require a header-side port.
- **P-22 recommendation updated:** tap semantics — the joint carries the
  branch-side port plus a frozen reference to the header component and the
  connection point; not a synthesised wall port. Reinforces P-23 (pads
  exist only in our class rules, invisible to Plant 3D/PCF).

### 2026-10-12 (cont.) — ASME Section IX آپلود شد؛ شمارهٔ گروه هم از استاندارد گرفته شد (کامیت‌های `05737c7`, `4b3bd0d`)

Owner uploaded ASME BPVC Section IX 2021 (branch `sec.ix-upload`,
`ASmE SEC IX 2021.txt`). Its Table QW/QB-422 publishes BOTH the P-No and
the Group number, so the pack now carries complete welding identity for
every library material — the earlier note that "Group No stays
rule-level" is superseded. Transcribed rows (pp.147–191, API 5L block
pp.189–191) live in `SECTION9_QW422` inside the pack builder, which
annotates every row with `group_no` and ASSERTS the extracted Table A-1
P-No equals Section IX's (drift fails the build; verified equal on all
57 rows). Group numbers of note: A106 C = 2, A516 70 = 2, API 5L
X56/X60/X65 = 2, X70 = 3; the rest of the target set = 1. Rule remains:
materials OUTSIDE the library must carry `p_no` AND `group_no` manually.

### 2026-10-12 (cont.) — owner requirement: P-No و Group No برای متریال خارج از کتابخانه (commit `05737c7`)

Owner: «P no. و group no. متریال هم در صورتی که در کتابخانه متریال سیستم
وجود ندارد، باید وارد بشه». Implemented as: the Section IX P-Number is
READ FROM THE STANDARD ITSELF — Table A-1 of B31.3-2024 prints a P-No
column (extracted position-based like the rest of the table; values as
printed: carbon steels "1", A335 P11 "4", P22 "5A", P5/P9 "5B", P91
"15E", austenitics "8"), so library materials carry it automatically.
The table publishes NO Group number, so Group No remains rule-level data.
PIPE_MATERIAL rules now accept `p_no` (printed form, e.g. "5A") and
`group_no` (positive integer); when a material is OUTSIDE the library
(`s_mpa_override`), BOTH are mandatory — bilingual refusal otherwise.
Unit tests pin the P-No anchors from the raw table rows; feature tests
cover the mandatory rule and format refusals.

### 2026-10-12 (cont.) — P-24 Step B COMPLETE: design basis, material rule, publish-gate pad validation

Step B finished in three commits on top of the materials pack (`55272b2`):

- `551b160` — migration `2026_10_12_120000`: `piping_classes` gains
  `design_pressure_mpa` / `design_temperature_c` (owner decision: class
  attributes); rule-kind CHECK extended with `PIPE_MATERIAL`. The service
  gained `setDesignBasis()` and validates PIPE_MATERIAL values against the
  pack — spec+grade must resolve (`A106 B`, `API5L X42 PSL2` via the ISO
  alias table) unless `s_mpa_override` is given; PSL ambiguity refused.
- `ae5351c` — `App\Services\BranchConnectionPadGate`: the publish gate
  walks EVERY pack DN pair inside each branch rule's footprint, sizes each
  pipe with its band's schedule/material/corrosion rules (effective wall
  0.875×nominal, S(T)/E/W/Y from the B31.3-2024 pack, conservative
  lowest-Ej default), and runs the §304.3.3 calculator: PAD cells must
  pass with the recorded thickness (else the message quotes the required
  minimum), NONE cells must pass bare, and uncheckable cells (para
  304.3.1(b) limits, missing rules, out-of-table temperatures) refuse the
  publish. Bilingual report lists each failing cell.
- `tests/Feature/PipingPadGateTest` — 5 tests on matrices computed from
  the packs (worst margins +17.4 / +761.9 adequate; −94.3 / −62.7
  refused), plus missing-CA refusal and the manual-override path.

Owner verification on Laragon is the remaining step for the whole P-24
chain (Step A calculator → pack → gate). Housekeeping still open: strip
the 12 MB PDF from the `b31.3-upload` branch (history rewrite, needs
sign-off).

### 2026-10-12 (cont.) — P-24 Step B: ASME B31.3-2024 materials reference pack built (commit `55272b2`)

The owner-uploaded ASME B31.3-2024 PDF (594 pp, on the `b31.3-upload`
branch, fetched into `.cache/`) is now the source of the platform's
material facts for pad validation. Built and committed:

- `scripts/build_b313_materials_pack.py` — position-based Table A-1 (SI,
  pp.206–315) extractor. Bench-verified traps solved during the build:
  the table has per-page temperature ladders (13/19/32-column sections),
  stacked segments sharing one column grid (merged per page), line-number
  columns repeated inside the stress block, and API 5L X-grades published
  under ISO names (L290 = X42 … L485 = X70). Regenerable whenever a newer
  edition is uploaded.
- `standards-packs/reference/b313-materials.ref.json` — 57 Table A-1 rows
  (A53 A/B, A106 A/B/C, API 5L A/B + L245…L485 PSL1/PSL2, A333 1/6, A335
  P5/P9/P11/P22/P91, A312 TP304…TP347H, A516 55–70, A285 A/B/C) plus
  Table 304.1.1-1 (Y), Table 302.3.5-1 (W) and the Table A-3 (Ej) subset,
  and the 0.875 mill-tolerance factor (owner decision 2026-10-12).
- `App\Support\Reference\MaterialReference` + `B313Material` +
  `UnknownMaterialException` — ADR-007 file-not-table pattern: memoised,
  every lookup throws; S(T) interpolated between columns with hard
  refusals above the last column / above max use temperature; Ej by
  spec+type or description fragment; Y/W with below-range semantics.
- `tests/Unit/MaterialReferenceTest` — 17 tests anchored on Appendix H
  (H301: API 5L Gr A S = 110 MPa @ 200 °C) and raw table rows.

Every extracted value was checked row-by-row against the PDF text stream
(some values in older editions differ — e.g. A285 C is 98.3 MPa @ 375 °C
in the 2024 edition, A312 TP304 is 129 MPa @ 200 °C). No PHP runtime in
the sandbox; the suite runs on the owner's Laragon tier. Next: class
design-basis columns + pipe-material-grade rule kind (migration), then the
publish-gate PAD validation. Still pending on GitHub: remove the 12 MB PDF
from the `b31.3-upload` branch (history rewrite needs owner sign-off).

### 2026-10-12 (cont.) — ASME B31.3 §304.3.3 pad-thickness validation (requirement P-24, Step A built)

Owner requirement: pad thickness recorded in the PMS branch table must be
validated with the ASME B31.3 para 304.3.3 area-replacement calculation
(A1 vs A2+A3+A4, zone limits d1/d2/L4, weld credit per 328.5.4, stress
ratio reductions). Formulas researched against the 2004 code text and
multiple published calculators; requirement recorded in ADR-008 §9.3.
Built now: `App\Services\BranchReinforcementCalculator` (pure service,
`evaluate()` + `requiredPadThickness()` bisection) with
`Tests\Unit/BranchReinforcementCalculatorTest` — fixtures from a published
worked example (pass/fail run-wall variants, pad recovery) plus
hand-verified cases (zone capping, narrow pad, stress ratio, 45° lateral,
refusals). Formulas independently re-verified with a Python mirror. Step B
(PMS wiring) queued on P-24 after runtime verification. Follow-up 2026-10-12:
`pressureDesignThickness()` added — B31.3 eq (3a) with the t ≥ D/6 refusal,
covered by three new tests including an end-to-end mm fixture (eq 3a →
reinforcement check). Owner offered to upload the standard if needed.

### 2026-10-12 (cont.) — Step B parameter inventory: what exists, what is missing

Owner asked for the parameter audit because the branch table is per piping
class. Audited against live code (not memory): EXISTS — OD per DN and wall
per DN×schedule in the ADR-007 reference packs; `PIPE_SCHEDULE` and
`CORROSION_ALLOWANCE` class rule kinds. MISSING on the class — design
pressure/temperature (only per-line today), pipe material grade, allowable
stress S(T), E, W, Y (B31.3 eq 3a inputs), mill-tolerance convention.
Table + two gating owner decisions recorded in the P-24 entry and ADR-008
§9.3: (a) class-level design conditions vs worst-line; (b) direct S/E/W/Y
class inputs (recommended) vs a bundled ASME Table A-1 pack.

### 2026-10-12 (cont.) — Step B decisions settled by the owner

(a) Design pressure/temperature = **class attributes** (per-line columns
stay for line checks). (b) Material data = **Table A-1 reference pack**
built from the ASME B31.3 standard, which the owner will upload; manual
entry remains as override. (c) Mill tolerance = **12.5%** (T = 0.875 ×
nominal). Recorded in P-24 and ADR-008 §9.3. Next build steps once the
standard arrives: extract Table A-1 for common grades, Y and W tables,
Appendix H fixtures; then class design-basis columns + grade rule +
publish-gate validation. Also landed before the decisions: eq (3a)
`pressureDesignThickness()` in the calculator with three new tests
(commit c9fbd88).

### 2026-10-11 (ninth) — piping P1 built: PMS piping classes, the EXCLUDE constraint and the branch table

Continued per «فعلاً بدون انجام تست ادامه بده». ADR-008 build phases 1–2
landed as piping phase P1:

- **Migration** `2026_10_11_120000_create_piping_classes_and_rules`:
  `piping_classes` (per-project code, `dn_span` int4range, DRAFT/PUBLISHED),
  `piping_class_rules` with the load-bearing
  `EXCLUDE USING gist (piping_class_id WITH =, rule_kind WITH =, dn_range WITH &&)`
  over half-open DN bands, and `piping_class_branch_rules` where overlap is
  legal (general + narrower exceptions) and `UNIQUE` catches only the exact
  duplicate footprint. All three tables get FORCE RLS with the sargable
  participation preamble from the P-17 fix. The migration asserts btree_gist
  and fails with an actionable DBA message.
- **Service** `PipingClassService`: create/addRule/addBranchRule translating
  exclusion/unique violations into bilingual validation errors; `publish`
  refuses any hole via `(span − range_agg(dn_range))` per rule kind;
  `ruleFor`/`branchFor` are `@>` lookups that THROW — `NoRuleForSizeException`
  and `BranchLargerThanHeaderException`, never null; published classes are
  read-only.
- **Support** `PipingRuleKind` (seven kinds, one table), `PipingClassState`.
- **Tests** `PipingClassTest` (9 tests) pin the ADR's own fixtures: DN100→SCH40
  / DN80→SCH80 / uncovered throws, overlap refused, gapped publish refused
  then accepted, published read-only, TEE/SOCKOLET/WELDOLET specificity,
  branch-larger-than-header distinct, duplicate footprint refused, priority
  tiebreak, non-participant RLS mirror.
- Docs: ADR-008 status → phases 1–2 implemented + §9 record; piping roadmap
  §3 row and P1 phase marked; statuses await `php artisan test` on Laragon.
- **Addendum (owner decisions):** the branch outcome is now a closed
  vocabulary — `BranchConnectionType` — with **P2P (Pipe-to-Pipe)** carrying
  its two kinds **stub-in / stub-on** (`P2pKind`, required on P2P cells,
  forbidden on fittings) and the owner's pad rule: `reinforcement = PAD`
  MANDATES `pad_thickness` in millimetres (CHECK + service validation).
  Five tests cover it; live sandbox verification caught and fixed a CHECK
  NULL trap (`NULL IN (...)` passes a CHECK) on the way. ADR-008 §9.1
  records all of it.

Next in sequence: runtime verification on Laragon when the owner runs the
suite; after that ADR-008 phase 3 (wire the PMS into component attach /
joint compatibility) or piping P2 (equipment/nozzles) once the three
ADR-010 questions are answered.

### 2026-10-11 (eighth) — P-17: the ADR-012 HIGH defect fixed — all 33 tenant policies made sargable

Continued per «فعلاً بدون انجام تست ادامه بده». The RLS escape hatch
(`(GUC IS NULL OR project_id = GUC)`, §5o) was removed from **every** tenant
policy by `2026_10_11_110000_make_rls_project_scope_sargable`:

- The preamble is now one sargable semi-join: `project_id IN
  (participated ∪ owned projects, narrowed to the bound project when one is
  bound)`. Membership branches, WITH CHECK clauses, child-delegation
  policies and archive/deny policies are byte-identical to before; `down()`
  restores the defective shape from the same spec.
- Deliberate tightening recorded per ADR-012 §6.1: the preamble admits only
  participated/owned projects, making standing rule 7 database-enforced for
  reads; the wider role branches (vendor/recipient/actor) only ever apply to
  companies already on the project, so no legitimate access changes.
- Eight `(project_id, …)` indexes added where missing (`punch_items`,
  `subsystems`, `mc_certificates`, inspections, lots, movements,
  `mto_staging_rows`, `gate_evaluations`).
- **Mechanism verified live** against sandbox PostgreSQL 16.2 (300 k rows /
  200 projects, 1-of-200 selectivity, EXPLAIN ANALYZE as the non-superuser
  app role): the defective shape forces a 153 ms whole-table seq scan on an
  RLS-scoped read; the sargable shape runs it in 26 ms, and index plans hold
  whenever the query carries the project predicate (house controllers always
  do) — cross-project (99 k rows), foreign-project (0) and foreign-company
  (0) probes all correct.
- `tests/Feature/RlsSargabilityTest.php`: cross-project visibility +
  binding + non-participant isolation, write-path pinning, a
  scale-independent plan-shape guard (no `IS NULL` disjunction may appear on
  a fact-table scan filter), and a 60 k-row volume semantics test.
- Docs: ADR-012 status → FIX IMPLEMENTED + §9 record; P-17 register +
  detail updated; §5o retitled with a dated update block.

Status: IMPLEMENTED — awaiting runtime verification on the owner's Laragon
machine. Next in sequence: piping P1 (ADR-008 visual line register).

### 2026-10-11 (sixth) — the owner develops on Windows + Laragon; documented as a first-class tier

The owner confirmed the workstation is Windows with **Laragon** — Docker is
not required. Added `docs/LARAGON-DEVELOPMENT-ENVIRONMENT.md`: PHP 8.4
side-by-side in Laragon, the php.ini extension + upload-limit list mirroring
`restore.sh`, PostgreSQL role/database creation with the non-superuser rule
asserted, the forbidden-SQLite `.env` block, the exact artisan sequence
(`key:generate → migrate:fresh --seed → ProcurementSeeder → filament:assets`),
demo login (`karimi@nioc.example` / `password`), the no-parallel-test rule,
and a troubleshooting table. One real defect surfaced by this: **P-20** —
`PdfRenderer::binary()` resolves browsers through POSIX `command -v`, so PDF
export is silently unavailable on Windows; recorded as a proposal, not fixed
blindly (needs the runtime). HANDOFF §0 rule 4 now names three tiers:
Docker (`dev-up.sh`), sandbox-degraded (preview + tests + `sandbox-pg.sh`),
and Laragon.

### 2026-10-11 (seventh) — Slice 6 built: PO attribution, amendment lineage, scope allocation and the order-gap board

Per the standing instruction «فعلاً بدون انجام تست ادامه بده», Slice 6 was
built without waiting for runtime verification (the owner will run
`php artisan test` on Laragon). What was added:

- **Migration** `2026_10_11_100000_add_po_attribution_and_order_gap`:
  `purchase_order_items.material_item_id` FK to the Material Library,
  `purchase_order_items.supersedes_id` self-FK with a unique index (a line
  is superseded at most once), and `po_item_allocations` with FORCE RLS and
  the participant policy copied from the accepted-MTO template, plus a
  `quantity > 0` CHECK.
- **`OrderGapService`**: `attribute()` (exact identity; unit must equal the
  catalogue base unit — mismatch is a validation failure, never a
  conversion), `amend()` (new row, old row untouched and readable, head
  locked inside a row lock), `allocate()` (explicit quantities, refuses to
  exceed the line quantity, no proration, only on attributed in-force
  lines), and `board()` (per-material SHORTAGE / COVERED / OVER_PLAN plus
  the UNMATCHED bucket, integer milli-unit arithmetic, lineage heads on
  issued/in-force orders only).
- **`OrderGapController` + routes + screen** at
  `/projects/{code}/procurement/order-gap` (GET board; POST attribute /
  amend / allocate), bilingual validation messages, inline `$t` view array
  and the house shell/tabletools contract; sidebar item `project.ordergap`
  under the `proc` module.
- **`OrderGapTest`** (10 tests): exact attribution + unit-mismatch refusal,
  draft-excluded until issued, cancelled-excluded, covered vs over-plan
  with zero tolerance, amendment replaces (110 counted, not 200; old row
  readable; double amendment refused), allocation recorded exactly with
  over-allocation refused and draft/unattributed refused, unmatched bucket
  never guessed, non-participant RLS mirror returns an empty board, and the
  HTTP screen renders for a participant.

Effective-state predicate: `ISSUED` or `PARTIALLY_RECEIVED` (issued and not
cancelled) — reusing `ProcurementState::poAcceptsReceipts` semantics, no new
state vocabulary. ADR-015 status updated to IMPLEMENTED — awaiting runtime
verification. The prototype in `prototype/order-gap-board.html` remains the
validated UX reference (P-06).

### 2026-10-11 (fifth) — runtime provisioning: the PostgreSQL half is now in-sandbox

The user chose runtime provisioning over parallel doc work. Probed every
acquisition route empirically: **apt** (mirrors unreachable), **GitHub release
assets** (redirect to `release-assets.githubusercontent.com` — blocked),
**getcomposer/packagist/php.net/deb.debian.org** — all blocked; only the five
allowlisted hosts answer. Consequence: PHP 8.4 cannot enter this sandbox
(`php-wasm` also fails the requirement: no PHP-8.4-plus-pdo_pgsql build for
Laravel exists there), and the Laravel tier remains Docker-only
(`scripts/dev-up.sh`). The database half, however, is now real **here**:

- `scripts/sandbox-pg.sh` provisions PostgreSQL **16.2** on 127.0.0.1:5432 from
  the binaries bundled in the `pgserver` PyPI wheel; data in `.cache/pgdata`.
- The wheel ships no contrib, so the script compiles **btree_gist** from the
  official `REL_16_2` source via codeload (PGXS build, ~5 s) and creates it in
  both databases.
- CI discipline enforced by the script itself: role `epcc` asserted
  `superuser=false bypassrls=false`; databases `epcc` and `epcc_test` owned by
  it; connection over TCP verified.
- Feature proof run **as the app role**: FORCE RLS enable + the ADR-008 shape
  `EXCLUDE USING gist (cls WITH =, kind WITH =, dn_range WITH &&)` rejects an
  overlapping DN band with `exclusion_violation` — the exact constraint the PMS
  phase needs.
- **Recorded gap:** the sandbox PG is 16.2 while compose/CI target 17. No
  17-only feature is used by any current migration, but a new migration must
  not adopt one silently; the Docker tier stays the reference.

### 2026-10-11 (fourth) — ADR-015 open questions closed by the user

All four Slice 6 decisions confirmed via structured questions and recorded as
binding in ADR-015 §5: allocations at **subsystem level**; states
**DRAFT/ISSUED/AMENDED/CANCELLED** with in-force as a predicate; allocation
authority **deferred** with the MTO-acceptance policy (recorded, not implicit);
amendments as **new row + `supersedes_id`**. P-05 closed in the proposals
register. Slice 6 now has a complete requirements record and a validated
screen; what remains is the build, which needs the full PHP/PostgreSQL runtime
— the next step is restoring that environment (Docker tier).

### 2026-10-11 (third) — Slice 6 screen language validated as a prototype (P-06 BUILT)

Piping confirmed as the priority discipline (closed 2026-10-05 decision, not
relitigated). Step-by-step sequence agreed with the user; this step: the
**Order Gap Board prototype** — Slice 6's screen language built before any
service code, per the pattern that twice caught localisation/layout defects
early. `prototype/order-gap-board.html`: FA-first/RTL, five synthetic PH-14
rows exercising every accepted gap state — two shortages (one with an issued
gap and one with no PO yet), covered, over-plan with a visible unallocated
remainder, and the unmatched-material bucket — plus the two rules people get
wrong: the draft PO is explicitly *not* counted (issued/in-force only), and the
unmatched row is *kept*, never guessed. Linked from the prototype sidebar
(`nav.gap`), pinned by `prototype/test/order-gap-board.test.js` (19 assertions),
wired into `npm run test:prototype` and `scripts/run-tests.sh`; ADR-015 gained
§8 recording the UX validation. Full runnable suite green: pack validator +
five jsdom harnesses. The four ADR-015 open questions go to the user next; no
schema work starts in this sandbox (no PHP/PostgreSQL — the no-untested-RLS
rule from ROADMAP §3.1 holds).

### 2026-10-11 (second) — full documentation & requirements review pass

Answered "did you review all documents and requirements?" honestly — the first
answer was no — and then did the pass: **all ~11,600 lines under `docs/`** plus
README, REBUILD and the pack/reference JSON set. SRS and Architecture read in
full; every ADR's status block and key sections checked; DOCUMENTATION-AUDIT,
coverage map, spike results, Iran-First addendum, roadmaps, UI-UX and
product-planning docs structurally reviewed. Findings:

- The audit's central warning holds: **parent-document drift is the biggest
  non-code risk**. Dated corrections applied on the spot (recorded as P-16 in
  `docs/IMPROVEMENT-PROPOSALS-EN.md`): SRS reconciliation banner; Architecture
  §12 AD-1 marked historical; ADR-006's "Nothing is implemented" annotated;
  ADR-005 dependency unblocked; **ADR-001/002 raised to Accepted-and-closed**
  (they said "Proposed" while HANDOFF §1 and TODO §5 already treated them as
  binding); Iran-First §10 backend-stack item marked closed.
- Two items stay OPEN and are escalated: **P-15** deep SRS alignment
  (release-phase tags per FR — the SRS marks nearly everything `M`, which makes
  the Iran-first MVP un-prioritisable), and **P-17**: ADR-012's RLS escape-hatch
  defect — the only known HIGH-severity issue in the codebase, deliberately
  unfixed until a full-runtime session can guard it with EXPLAIN + correctness
  tests. It should lead that session, ahead of Slice 6.
- P-18: coverage-map recount (~15–20% wording vs the real ~40–45%) pairs with
  P-15.
- ADR-010's three open questions (equipment tag scope, instrument register,
  imported-vs-allocated tags) confirmed as the blockers for piping phase P2.
- DOCUMENTATION-AUDIT-EN §5.1–5.12 ("better requirement recommendations" —
  BPM, visibility matrix, read-audit sampling, signatures, OCR phasing,
  offline sync contract, SSO/MFA, BIM, pack editor, procurement depth,
  schedule, HSE scope) are adopted as standing rule-5 input and referenced by
  the proposals register rather than re-derived.

Prototype/test state unchanged and green this session (pack validator +
jsdom suites); no Laravel code touched.

### 2026-10-11 (later) — rule 5 added; first improvement-proposals pass

The user added a fifth standing rule: whenever a better alternative exists for a
requirement, a piece of code or a capability, it must be voiced. It is recorded in
§0 and operationalised through `docs/IMPROVEMENT-PROPOSALS-EN.md` (status-tracked).
First pass found and **fixed on the spot**: the stale §3 line claiming PDF export
and PROCUREMENT are absent (both exist); `test:prototype` omitting `render.test.js`
(324-combination suite); `prototype/test/run-all.sh` missing two of the four jsdom
suites (now a thin wrapper over `scripts/run-tests.sh`); README missing the ADR-015
row. Verified, not just read: `PunchCategory::blocksReadyForStartUp()` is defined
but called nowhere — the RFSU gate exists as dead code (proposal P-01). Recorded,
not yet built: replacing the stock Laravel `app/README.md` and the Laravel-Boost
`app/AGENTS.md` boilerplate with project-specific entry points (P-02/P-03), an
English `TODO-EN.md` (P-04), recommended answers for the four ADR-015 open
questions (P-05), a static Order-Gap-Board prototype screen before building
Slice 6 (P-06), a demo-seed command for air-gap sales demos (P-07), a sandbox-tier
CI job (P-09), and archiving the session-log table out of this file once it grows
again (P-10). All ten proposals with rationale and status are in the proposals doc.

### 2026-10-11 — standing operating rules, Slice 6 requirements ADR, sandbox dev-environment slice

The user set four standing operating rules (handoff kept current; documentation in
English and continuously updated; requirements recorded continuously as English ADRs;
a development environment with a real display server and test execution). They are
now permanent as **§0** above.

Concretely: traced the Slice 6 requirement provenance (it lives in
`docs/MTO-REQUIREMENTS-FA.md` / `-EN.md` §A5 and §3.2, referenced from here, README
and TODO) and promoted it to a first-class requirements record — **ADR-015
(PROPOSED)** — grounded in the real schema findings: `purchase_order_items` has no
`material_item_id` FK, no amendment lineage, and no effective-state vocabulary
(`PurchaseOrderState` exists only as a migration comment). Built the degraded-tier
development environment this sandbox allows (no PHP/Composer/PostgreSQL/Docker):
`scripts/run-tests.sh` runs every suite the machine can run — pack validator (venv
under `.cache/`, PEP-668-safe), all four jsdom harnesses — and says loudly what it
skips; `scripts/preview-server.mjs` is a zero-dependency live preview of the
air-gap-safe prototype (0.0.0.0:8080, path-traversal blocked, `/healthz` probe).
Verified here: all 3 standards packs + 5 reference packs valid; 324-combination
render suite plus sidebar/piping-workspace/MTO-acceptance jsdom suites green;
preview serving `index.html` and `piping-workspace.html`. The full Laravel/RLS
suite remains Docker-tier (`scripts/dev-up.sh`) and was not run here.

### 2026-10-05 — external repo handoff, backlog reconciliation and MVP roadmap

Cloned the private GitHub repo in a fresh Arena workspace, confirmed local and remote `main` are in
sync at `61093dd3f9a8e146161e288e2857c9dc372e6b4d`, and kept the PAT out of git config/remotes.
Workspace footprint stayed small (~15 MB; no `vendor`/`node_modules` committed). The current sandbox
has Node/Python but no PHP, Composer or PostgreSQL, so the full Laravel/RLS test suite was not run
here. What could be verified was verified: `python3 standards-packs/validate_packs.py` passed for all
3 standards packs and 5 reference packs, and `node prototype/test/sidebar.test.js` passed 19/19.

Reconciled `docs/TODO.md` with the newer state already recorded in this handoff: procurement is no
longer a zero-page module, ADR-006 phases 1/1b/2/3 are built, physical breakdown/reference data/units
/components/ports/joints are now listed as done, and the open backlog is split into real gaps instead
of stale module labels. Added `docs/ROADMAP-TO-MVP.md` with the recommended sequence: first restore a
real Laravel/PostgreSQL test environment, then finish small PDFs, RFSU/PAC/FAC, PMS rules, engineering
imports, equipment/nozzles and HSE. Also saved the initial Arena analysis as
`docs/ARENA-INITIAL-ANALYSIS-FA.md`. User then set a standing documentation rule: every new
document created from now on must have an English counterpart. Added the corresponding English
versions `docs/ARENA-INITIAL-ANALYSIS-EN.md` and `docs/ROADMAP-TO-MVP-EN.md`; keep this bilingual
pairing rule for future docs.

Follow-up documentation audit: reviewed all 15 ADRs and the parent docs (`SRS`, `Architecture`,
`Prototype-Coverage-Map`, `Spike-RLS-Results`, `Infra-Cost-Model-Iran`, `Iran-First`). Added
`docs/DOCUMENTATION-AUDIT-FA.md` and `docs/DOCUMENTATION-AUDIT-EN.md`. Key findings: parent docs
have drifted behind the real Laravel/Iran-first implementation; ADR-003 main is superseded by Annex
A; ADR-006 is stale because phases 1/1b/2/3 are now built; SRS needs release-phase tags and the pack
list aligned to `ips-iran`/`iso`/`awp`. Requirement recommendations recorded there: defer visual BPM,
phase OCR/search/digital signature/offline sync, keep the visibility matrix constrained for MVP, and
do not promise direct NWD parsing. User then clarified the product priority: all EPCC disciplines
must remain in scope, but Piping should be completed first. Added
`docs/PIPING-DISCIPLINE-COMPLETION-ROADMAP-FA.md` and
`docs/PIPING-DISCIPLINE-COMPLETION-ROADMAP-EN.md`; updated TODO/roadmap/SRS/Architecture and ADR
status notes accordingly. User then requested synthetic data for testing/preview and noted the UI feels
cluttered. Added `docs/UI-UX-IMPROVEMENT-PLAN-FA.md` and `docs/UI-UX-IMPROVEMENT-PLAN-EN.md`: use
realistic demo data, shift from register-first to task-first UX, build a Piping Workspace first, add
summary cards, blocker-first views, detail drawers, deviation inbox and test-pack board. User also added that product planning and sales infrastructure must be completed: Iran-first requirements now, international readiness later. Added `docs/PRODUCT-PLANNING-AND-SALES-INFRA-FA.md` and `docs/PRODUCT-PLANNING-AND-SALES-INFRA-EN.md`, covering on-prem/air-gap sales, offline licensing, demo seed, sales collateral, implementation methodology, support diagnostics, and international commercial readiness. Built the first static, air-gap-safe Piping Workspace preview at `prototype/piping-workspace.html` using synthetic PH-14 data: bilingual FA/EN, RTL/LTR, summary cards, blocker-first filters, readiness bars, deviation inbox, test-pack board and a line detail drawer. Verified it contains no external refs and the existing pack validator/sidebar tests remain green. Follow-up: user reported the demo was not responsive; fixed the prototype with a compact mobile nav, stacked filters, card-style line rows under 760px, responsive metrics and full-width drawer. Second follow-up: filter checkbox labels overflowed and Persian mode still showed English literals such as “All subsystems”; localized those UI strings and made checkbox text wrap safely; also replaced remaining Persian-mode English labels in the filter/tabs/panels where they were not deliberate domain acronyms. Second pass made the filter bar a constrained grid, added a Persian static fallback for the subsystem option before JS runs, and made checkbox labels impossible to overflow on narrow widths. Added `prototype/test/piping-workspace.test.js` so Persian filter labels, language switching, mobile-card structure, drawer behaviour and air-gap safety are pinned by jsdom (16 assertions). Made the new Piping Workspace discoverable from `prototype/index.html`, added `npm run test:prototype`, and updated `README.md` so reviewers know which preview to open and which tests to run.


Runtime restoration is now fixed and repeatable in this sandbox. `restore.sh` now creates `app/.env` when missing, forces Laravel onto PostgreSQL (`epcc` / `epcc_test`, user `epcc`, password `epcc_dev`), generates the app key, migrates/seeds, and publishes Filament assets; this closes the prior SQLite/PDO-driver restore failure. After the fix, `bash restore.sh` completed, and the full Laravel/PostgreSQL suite ran green: **856 passed / 3153 assertions**. Also added the first real Laravel version of the Piping Workspace at `/projects/{code}/piping/workspace`, linked it from the sidebar before the line register, and backed it with real project data: summary cards, blocker-first worklist, AFC evidence gaps, joint fit-up progress and subsystem-grouped test-pack readiness. New HTTP assertions pin EN/FA rendering, tenant isolation, sidebar discoverability and blocked-line worklist behaviour.


Next main slice: turned test-pack readiness from a derived placeholder into a real Laravel object. Added `piping_test_packs` with RLS/archive-freeze policies, `piping_lines.test_pack_id`, `PipingTestPack` and `PipingTestPackService`. The workspace can now create hydrotest/test packs, assign/unassign lines, show unassigned-line counts, and move packs through `DRAFT → READY → TESTED → ACCEPTED`; `READY` is blocked until the pack has at least one line and all assigned lines are released. Added HTTP coverage for pack creation, assignment, and refusing readiness while a line is not released. Full suite after this slice: **858 passed / 3166 assertions**. Note: Laravel DB tests must not be run in parallel against the same `epcc_test` database; doing so produced expected migration/drop-schema races, then sequential reruns were green.

### 2026-10-12 (cont.) — P-24 flange step: ASME B16.5-2025 pressure-temperature ratings gate

Owner uploads (branches `b16.5-upload`, `b16.47-upload`, `sec.II-part2`):
ASME B16.5-2025 (274 pp), B16.47-2020 (large-diameter flanges) and Section
II Part D 2025 Customary (1533 pp). Built and committed from B16.5:

- `scripts/build_flange_ratings_pack.py` — extracts all 45 SI rating tables
  (Tables 2-1.1 .. 2-3.19, 903 rows) with each table's material block
  (forgings/castings/plates -> group). Build-time invariants: strictly
  rising temperature ladders, non-increasing pressure per class (0.1-bar
  print-rounding tolerance), contiguous class dropout, printed anchors —
  and a cell-by-cell audit of the Group 1.1 SI table against its U.S.
  Customary twin (every converted value must land inside the SI step
  bracket; the dual-unit tables round independently, so equality is not
  the standard's own semantics).
- `standards-packs/reference/flange-ratings.ref.json` — ratings in bar /
  deg C, classes 150..2500, material index for 35 ASTM specs
  (A105, A350 LF2, A182 F304/F316/F11/F22/F91/F92, A216/A217/A351/A352,
  B462 N08020, ...).
- `App\Support\Reference\FlangeRatingReference` (ADR-007 pattern):
  material -> group resolution and step-rating lookup; every lookup throws
  above a ladder top or where the table retires a class (ellipsis).
- PMS wiring: FLANGE_TYPE values are
  `{"rating_class": 300, "spec": "A105", "grade": "F316"|null}` —
  validated at entry (class on the B16.5 ladder, material resolvable);
  the publish gate rates every FLANGE_TYPE cell against the class design
  basis (`validateFlangeRatings`): design pressure (MPa -> bar) must not
  exceed the group's rating at the design temperature. Bilingual refusals.
- Tests: `Tests\Unit\FlangeRatingReferenceTest` (anchors incl. A105
  Cl 150 = 19.6 bar at <=38 deg C — the 285 psig classic — and a whole-pack
  monotonicity re-check) and `Tests\Feature\PipingFlangeRatingGateTest`
  (under-rated refused, adequate published, unknown spec/class refused at
  entry, above-ladder and retired-class refused at publish).

Also this session: verified merge #6 (roadmap reconciliation) brought no
content change to main (tree identical to our branch base), and restored
the fork-only `CHAT-TRANSFER-HANDOFF-EN/FA.md` dropped by that merge
(commit `0b1a830`). Follow-ups: B16.47 large-diameter ratings, Section II
Part D data (Tcr/yield/density), JSON schema + CI validation for the two
new packs, and the materials-library coverage review (owner-requested).
Runtime verification pending on the owner's Laragon tier.

### 2026-10-12 (cont.) — `workspace` branch audited: parallel session's reference library ported (commit `bf15816`)

The owner published a `workspace` branch: a full export of a parallel Arena
session (repo snapshot dated 2026-10-06, based on the same `48b1e5d` root)
plus evidence zips and an ASME B16.9-2018 PDF. That session had built a
mature reference library and an evolved app layer, but NOTHING of it ever
merged to main — the export was its only surviving record.

Ported verbatim into this branch (commit `bf15816`):
- 11 reference packs — highlight: `allowable-stress` = FULL B31.3-2024
  Table A-1 SI (798 rows / 138 specs, duplex A790/A789, EFW A671/A672,
  nickel alloys) closing the gaps named in the materials-library audit;
  `flange-pt-ratings` v2.0.0 (45 B16.5-2025 groups + 27 B16.47 curves,
  derived Class 800); `flange-bolting`, `fitting-dimensions` (B16.9-2018),
  valve packs, fluid-service, actuators, `materials` v1.8; plus
  `component-templates` upgraded to its strict superset (+BOLT/+NUT).
- 16 per-pack schemas and the session's 2,835-line validator (superset of
  ours). Green this session: 3 standards packs + 16 reference packs valid.
- Tests: the session's 21 fitting-dimensions regression probes, plus a new
  `test_flange_ratings_cross_check.py` pinning the cross-provenance audit:
  this branch's PDF-extracted flange pack vs the ported transcribed one =
  4,725 shared B16.5 cells, 4,725 exact matches, zero mismatches. 22/22
  standards tests pass.

NOT ported (open, owner decision — P-25): the session's app-level work
(different PMS architecture, MR entry, NDT requirements, engineering
screening, fitting review) stays archived in the export. Follow-ups also
recorded: B16.47-2025 request if its curves enter service; conform this
branch's own packs to the ported schema convention later.

### 2026-10-12 (cont.) — P-25 steps 2+3: engineering screening + fitting review ported from the parallel session

Owner instruction: evaluate the parallel session's code step by step and
reuse what matches this session's logic. Step 1 (compatibility
assessment) landed as `docs/PARALLEL-SESSION-INTEGRATION-ASSESSMENT-EN.md`
(commit `3bdff9b`). Steps 2 and 3 were MERGED because the screening
evidence layer is keyed to fitting-definition rows — one functional unit.

Ported verbatim (module files, 3 migrations with house-style RLS, 4 test
files = 32 tests, 7 design documents):
- `App\Support\Reference\FittingDimensions` — the PHP accessor over the
  ported `fitting-dimensions` pack (ASME B16.9-2018).
- `ProjectFittingDefinition` model + `ProjectFittingDefinitionService`
  (append-only definitions with supersedure: revises/root/correction
  reason, unique source index).
- `FittingReviewService` — review policies (1-5 steps), runs, decisions,
  built on the shared `AuthorizationPipeline` (byte-identical in both
  sessions) and `AuthorizationDenial`.
- `App\Services\Engineering\MaterialScreening` — read-only, versioned,
  bilingual declaration screener for PIPE/FLANGE/VALVE/GASKET/BOLTING
  against the ported packs ("never certifies, never edits, never
  approves") + `MaterialScreeningEvidence` capturing sha256-fingerprinted
  snapshots per review run.
- Migrations `2026_09_28_140000` / `2026_09_29_090000` /
  `2026_09_29_180000` (definitions; policies/runs/decisions; screening
  snapshots). No collision with this branch's migrations; every imported
  class verified present here before copying.
- Docs: B16-9 source review/reader/size-scope/cap applicability,
  fitting-review workflow, material screening + integration notes.

NOT ported in this step (deliberately): the controller/routes/views UI
(its own later step), finding dispositions/responses (next candidate),
and everything in the assessment's conflict zone / deferred zones.
Verification gate: `php artisan test` on the owner's Laragon tier.

### 2026-10-12 (cont.) — P-25 step 4: material-requisition (MR) entry ported from the parallel session

Owner: «بررسی کن که گام بعدی رو کامل کن». Step 4 of
`docs/PARALLEL-SESSION-INTEGRATION-ASSESSMENT-EN.md` — the MR entry
module — ported under the one-verifiable-step rule.

**Ported (verbatim, their tree at `.cache/ws/x_ws/epcc-platform`):**
- Services: `MaterialRequisitionEntryService`,
  `MaterialRequisitionAccessService`, `PmsAccessService`. The PMS
  access service is portable because their tree keeps its policy table
  in a standalone migration (`2026_09_29_235700_create_pms_author_policies`),
  independent of the conflicting PMS schema.
- `ProcurementService` replaced with their strict superset (17-line
  diff): MR docblock + a numbering bug-fix — requisition numbers now
  come from the `projects.material_requisition_sequence` counter with
  `firstOrFail` instead of max-of-max (concurrent-safe, no gaps reused).
- Migrations: `2026_09_29_235700` (PMS author policies) and
  `2026_09_30_042713_add_material_requisition_authoring` (sequence
  column + `mr_author_policies`), both with house-style RLS
  (append-only policy rows, per-company author policy tables).
- `MaterialsController` replaced wholesale — the diff is additions
  only: 3 constructor injections (incl. the already-ported
  `ProjectFittingDefinitionService::assertAccess`), procurement screen
  plan gate (`hasModule('proc') && allowsPack`), MR raise + author-access
  endpoints, and a JalaliDate refactor replacing Morilog.
- Routes: 2 POSTs (`/projects/{projectCode}/procurement/requisitions`,
  `/projects/{projectCode}/procurement/author-access`).
- Views: new `materials/mr-entry.blade.php`; two additive merges into
  `materials/procurement.blade.php` (mr-entry include + item details
  expand cell using `mr.details` / `mr.policy_basis`).
- Lang: `mr`, `fitting_review`, `project_fittings`, `material_screening`,
  `project_materials` (en + fa) — the last four also complete the
  step-2+3 port whose services reference these keys; `epcc.php` taken
  from theirs (pure superset).
- Tests verbatim: `MaterialRequisitionEntryTest` (HTTP-level, hits
  `/projects/PH-14/procurement/...`) + `MaterialRequisitionMigrationTest`.
- Docs: `MATERIAL-REQUISITION-ENTRY-2026-09-30.md` + their
  `ADR-018-Material-Management-Operational-Completion.md`. **ADR
  numbering divergence recorded:** our tree runs ADR-001…015 (015 = PO
  Attribution); their tree used 015–018 for different topics. Their
  ADR-018 kept under their number because ported code cites "ADR-018"
  and there is no filename clash; their ADR-015/016/017 docs are NOT
  ported (filename clash with our 015) — a doc-consolidation note is
  queued.

**Verified before port:** `MaterialRequisition` / `MaterialRequisitionItem`
models byte-identical across sessions (untouched); our `AuthSeeder`
already seeds the plans blocks their plan gate needs (EPC-PARS = full
plan with `proc` module); all `use App\…` imports of the copied services
resolve in our tree; brace/paren balance clean on every copied file;
test URLs match the added route paths.

**Verification gate (owner's Laragon):**
`php artisan migrate:fresh --force && php artisan db:seed --class=AuthSeeder && php artisan db:seed --class=EpccDemoSeeder && php artisan test --filter=MaterialRequisition`

### 2026-10-12 (cont.) — P-25 step 5 assessed; standards-library port stopped at design gate

Owner approved the next step («بله»). Reconciled the parallel export's
`Standard`, `ProjectStandard`, `StandardCitation`, `StandardsLibrary`,
`2026_09_20_100000_create_standards_library` and later document-reference
freeze migration against this branch's `StandardsPackRepository`. Recorded
findings and proposed choices in `docs/ADR-019-Standards-Library-Reconciliation-EN.md`.
The file-backed numerical packs and the metadata catalogue serve different
purposes and can coexist. However the exported migration comments on missing
`itp_stages.reference`; citations only support `ITP_STAGE` and `printed()`
uses absent ITP snapshot APIs; the later `source_edition` migration needs ITP
triggers; the exported tests seed ITP. Therefore no code/migration/test was
copied: the one-step rule requires stopping on this dependency conflict.
Recommended owner choice: port catalogue + project adoption as an explicitly
adapted future step, leave citation/ITP deferred; alternative: defer all.
Publication must pin edition and snapshot. No tests executed here per owner.
Earlier steps 2+3 and 4 still await Laragon verification.

### 2026-10-12 (cont.) — P-25 step 5 option A: catalogue and project adoption

Owner selected option A («گزینه اول»). Implemented the adapted standards
catalogue (`Standard`, `ProjectStandard`, `StandardsLibrary`) with a new
`2026_10_12_130000` migration: global identity catalogue + project-specific
RLS applicability and edition pinning. Removed all ITP/citation dependencies
from the parallel code and migration; no `standard_citations` or ITP host.
Added `StandardsCatalogueTest` for identity, editions, withdrawal and RLS.
Original parallel tests depend on ITP and cannot be ported verbatim.
ADR-019 updated with decision and scope. `StandardsPackRepository` untouched.
No tests run here per owner's instruction. Laragon gate:
`php artisan migrate:fresh --force && php artisan db:seed --class=EpccDemoSeeder && php artisan db:seed --class=AuthSeeder && php artisan test --filter=StandardsCatalogueTest`.

### 2026-10-12 (cont.) — P-25 step 6: PMS field-group design checkpoint

Owner asked to continue while runtime tests remain pending. Wrote
`docs/ADR-020-PMS-Field-Groups-Reconciliation-EN.md`, a proposed
four-group reconciliation for fluid-service classification, severe-cyclic
condition, material identity keys and NDT requirements on OUR PMS schema.
Recommended first group: fluid service (A), subject to the owner deciding
single vs multiple categories per class. The existing per-DN PIPE_MATERIAL
rule should not be duplicated on the header. No migration or app logic
changed in this step; no tests executed. Next owner decision: first group
and its cardinality; step 7 baseline/model-import evaluation remains pending.

### 2026-10-12 (cont.) — PMS fluid-service cardinality decided

Owner confirmed: each piping class may refer to one fluid-service category.
ADR-020 updated: one class-level field, not a multi-category link; severe
cyclic stays a separate condition. Corrected the fluid-service reference
pack prose from "SEVEN" to "SIX" to match its six enumerated codes; no
classification records were fabricated. Before implementing the gate, decide
how existing published classes lacking a category are handled. No PHP
runtime tests were possible in this environment.

### 2026-10-12 (cont.) — PMS fluid-service group A implemented

Owner clarified that the project is in development and no important DB data
needs migration. Added nullable class-level fluid-service category with DB
CHECK for the six reference-pack codes, draft-only bilingual setter, and
mandatory publish gate; existing rows not backfilled. Existing PMS fixtures
now explicitly choose NORMAL, and a new test refuses missing classification
and the SEVERE_CYCLIC condition as a category. ADR-020 records limitations:
no automatic Category D eligibility or line-level consistency check claimed.
PHP files parsed and reference JSON parsed; runtime Laravel tests require
PHP/Laragon.

### 2026-10-12 (cont.) — P-25 step 7: baseline / model import assessed

After the owner confirmed that the development database contains no important
data and asked to continue, inspected the actual archived parallel source
from the `workspace` zip. `docs/ADR-021-Baseline-Model-Import-Reconciliation-EN.md`
records the result: **no-go on wholesale port**. The exported baseline's
`baseline_batches`/`engineering_items` duplicate the authority of this
branch's immutable `accepted_mto_batches/rows`; the model importer adds
missing PCF parsing and touches protected component/joint state. Recommended
next isolated step is parser-only, or owner can defer step 7. No app code
copied and no PHP tests run. Earlier Laragon gates remain open.

### 2026-10-12 (cont.) — P-25 step 7 follow-up: pure PCF reader only

Owner approved parser-only («پیشنهاد خودت عالیه»). Copied five pure PCF
classes + source fixture from the archived workspace. Retained the 13
parser tests verbatim; excluded the six vocabulary tests because this
session's P2P stub-on/stub-in semantics conflict with the parallel
`TEE-SET-ON` → `OLET` mapping. Did NOT port vocabulary, baseline schema,
model-import application logic, controller or routes. ADR-021 records this
gate and future upload bounds/unit checks. All six PHP files parsed; no
PHP runtime available here. Laragon: `php artisan test --filter=PcfParserTest`.

### 2026-10-12 (cont.) — PCF branch classification, no model writes

Continued after parser-only step. ADR-022 records why parallel
`TEE-SET-ON`/`TEE-SET-IN` → `OLET` is incompatible with the owner's P2P
semantics. Added read-only `PcfBranchClassification` with explicit P2P
STUB_ON/STUB_IN, TEE, WELDOLET, SOCKOLET mappings; ambiguous OLET and
unknown tokens stay unresolved. Added pure PHPUnit test; neither the model
importer nor the parallel vocabulary was ported. PHP tests still pending
on Laragon.

### 2026-10-12 (cont.) — PCF read-only admission boundary

Added `PcfAdmission` wrapper around the verbatim PCF parser: 5 MB / 100k
line / 20k component limits, explicit supported bore and coordinate units,
unique unit declarations, line reference, finite coordinates and positive
bores. Added pure PHPUnit cases for accepted and rejected inputs; ADR-023
records the contract. No upload API or DB/model writes. PHP syntax parsed;
Laravel tests pending on Laragon (`php artisan test --filter=PcfAdmissionTest`).

### 2026-10-12 (cont.) — Cross-source baseline design checkpoint

Owner requested continuation. ADR-024 reconciles the parallel immutable
model/MTO claims with this branch's accepted MTO snapshots, without a new
schema or duplicate authority. Found that `OrderGapService::board()` sums
all accepted revisions for a project; successive accepted revisions of a
scoped document can double-count gross demand. Proposed append-only
effective-revision selection (accepted rows cannot be updated/deleted),
explicit material identity and unit/scope mapping, and human resolution
without automatic source precedence. Owner must choose scope/supersession
semantics before a code change. No PHP tests run here.

### 2026-10-12 (cont.) — Recovered previous MTO revision/scope decisions

Owner asked whether earlier sessions had already decided the effective MTO
revision and scope overlap. Yes: archived parallel ADR-005 §2.2 and the
2026-10-05/06 accepted decisions, reconciled in this branch's
`docs/MTO-REQUIREMENTS-EN.md` §§3.3–3.6, say latest accepted revision
per document/scope for current baseline; historical immutable rows are
not added; siblings require disjoint scope or exact-revision additive
evidence; parent/child scopes overlap; scope/hierarchy revisions pinned.
Gross approved MTO and net model stay separate, with no percentage
tolerance hiding a positive shortage. Updated ADR-024 to distinguish
these existing owner decisions from implementation details still open.
The parallel `BaselineService` mutates SUPERSEDED and suppresses small
disagreements; its behavior cannot simply be copied into this branch.
No code or runtime tests in this research step.

### 2026-10-12 (cont.) — Targeted documentation drift review

Owner requested review of documentation against current capabilities. Audited
MTO-REQUIREMENTS EN/FA, ADR-005, ADR-015 and ADR-024 against app source.
Corrected historical branch/test-count wording, stale claims that PCF parser,
PMS access and MR sequence were absent, and Slice 6's obsolete todo status.
Explicitly flagged the current OrderGapService's all-revisions/all-scopes
summation defect instead of claiming full multi-revision correctness;
clarified read-only PCF is not model import. English docs updated and the
existing FA counterpart kept in sync. No app code or runtime tests in this
documentation step. Historical HANDOFF entries remain evidence of their
original dates, not current feature status.

### 2026-10-12 (cont.) — GitHub CI first real integration run

Synchronized the session branch with its pushed HEAD without overwriting
working files, committed subsequent changes as `d1e827c`, pushed and opened
PR #7 as a CI-only review gate (do not merge yet). Run 38343223088:
prototype + development-image jobs passed; standards job failed because
CI did not install required `jsonschema` (reproduced locally without that
package; passes with it); Laravel job failed during migrate/seed before
PHPUnit; compose boot also failed. Runner log downloads are unavailable
from this sandbox's network, so the CI migration step now emits a readable
GitHub error annotation on failure. Next: rerun CI, inspect bootstrap
annotation, fix root cause and then run the actual Laravel suite.

### 2026-10-12 (cont.) — GitHub CI exposed step-2+3 schema collision

PR #7 second run 38343518174: standards/rule-engine and prototype green;
Laravel+compose blocked during migration at `2026_09_29_180000` with SQLSTATE
42703 (`project_fitting_definitions.size_designation` absent). The ported
screening snapshot migration expects the parallel general-material definition
columns; our fitting table only has CAP/ELBOW dimensions. ADR-025 stops blind
port and requests owner choice (new material declaration host vs defer general
screening). Added independent pure-PCF CI job so parser tests can run even
while database migration is blocked. Full Laravel suite was NOT executed.

### 2026-10-12 (cont.) — Pure PCF PHPUnit 12 compatibility correction

PR #7 CI run 38343989948 executed 18 pure PCF tests: 17 passed, one
`PcfAdmissionTest` errored because PHPUnit 12 no longer recognizes the
legacy `@dataProvider` docblock. Changed to `#[DataProvider('invalidFiles')]`
so the 11 unsafe-input cases actually execute. Full Laravel remains blocked
by the unrelated step-2+3 migration collision (ADR-025).

### 2026-10-12 (cont.) — GitHub CI verification checkpoint

PR #7 run 38344270861 after the PHPUnit 12 provider fix: standards packs
+ conformance, HTML prototype, pure PCF PHPUnit, and development image
all PASSED. The Laravel/PostgreSQL suite and compose boot FAILED at
`2026_09_29_180000_capture_material_screening_snapshots.php` before
PHPUnit could start; schema collision documented in ADR-025. This is a
real integration defect, not a test-green state. PR #7 stays open and
unmerged pending an owner decision on general material screening vs the
existing CAP/ELBOW fitting table.

### 2026-10-12 (cont.) — Parallel branch supplied the missing screening predecessor

Owner asked to inspect previous-session branch. In the `workspace` ZIP,
found `2026_09_29_150000_extend_project_material_declarations.php` and
`ProjectMaterialSchema.php`, both omitted by the earlier selective port.
They supply exactly the `material_family`/`size_designation`/properties
columns and family-aware review policy expected by migration 180000 and
ported services. Previous ADR-025 diagnosis of an *inherent* incompatible
schema was too strong: the immediate CI failure was an incomplete dependency
chain. Copied those files and the original populated migration test
byte-for-byte; no ad-hoc columns or RLS weakening. ADR-025 corrected;
full CI rerun required, and presentation/model-import work remains out of
scope.

### 2026-10-12 (cont.) — Missing predecessor recovered; next PMS schema conflict exposed

PR #7 CI run 38347536130 confirmed `2026_09_29_150000` and the
screening snapshot migration now migrate successfully. Next failure is
`2026_09_29_235700_create_pms_author_policies`: absent
`pms_entry_events` (SQLSTATE 42P01). The archived 235000 predecessor
belongs to parallel PMS schema and cannot be copied over our independent
ADR-008 PMS; 235700 also alters absent `piping_class_notes` and installs
an author event guard. Do not weaken authorization by simply skipping
those guards. ADR-025 records need for a separated policy design or
deferral. Other CI jobs (standards, prototype, pure PCF, image) pass;
Laravel suite still has not started.

### 2026-10-12 (cont.) — PMS author nomination adapted to current schema

Owner approved the suggested path. Adapted migration 235700 to create only
`pms_author_policies` and its append-only/RLS/version/actor protections plus
fail-closed lookup, without touching absent parallel `pms_entry_events` or
`piping_class_notes`. Added `PmsAuthorPolicyTest` (default deny, explicit
nomination, suspension, immutable history). ADR-026 explicitly notes that
`PipingClassService` writes are NOT YET gated by this policy; no claim of a
fully enforced PMS authoring permission. Next GitHub CI must migrate/test;
subsequent write-path integration is a separate step.

### 2026-10-12 (cont.) — PMS policy migration green, next RLS defect fixed

PR #7 run 38361131058 confirmed adapted 235700 migrates. Laravel stopped
later at ADR-012 sargable RLS migration: generic STANDARD_CHECK referenced
nonexistent `mto_staging_rows.company_id` (SQLSTATE 42703). Corrected the
child policy to use parent `mto_revisions` and project/participant check,
matching original delegation; no table or tenant column fabricated.
Other jobs remain green. Next GitHub CI run determines whether full PHPUnit
can finally start; no success claim until then.

### 2026-10-12 (cont.) — CI database prerequisite provisioned

PR #7 run 38361586890 migrated through the RLS fix and reached PMS P1,
which correctly refused to proceed without `btree_gist`. Updated GitHub
CI database bootstrap and Docker Compose PostgreSQL init to install the
extension as `postgres` administrator in both epcc and epcc_test; app
role remains non-superuser and migrations do not CREATE EXTENSION.
Existing Docker volumes need a one-time DBA extension install (init runs
only for fresh volumes). Full PHPUnit remains pending next run.

### 2026-09-17 (later still) — ADR-006 phase 2: components and ports

Built the modelling layer: `components` + a single discriminated `ports` table, `ComponentService`,
a per-line model screen, and the attach gesture. The user's "how does it know a tee has three
ports" question is answered structurally — the template declares them and no API accepts a count.

**Sandbox reset #33 mid-turn.** Wrote `rebuild-env.sh` so the next one is a single command instead
of ten minutes of remembering; it also verifies chromium/poppler and warns that their absence makes
13 tests skip silently rather than fail.

Full suite **852 passed / 3136 assertions**, zero skipped. 13 new mutants on the modelling service,
all caught.

### 2026-09-17 (later) — units menu narrowed to bar/psi and C/F

User: «فقط واحدهای سلسیوس و فارنهایت را برای دما و bar و psi برای فشار را در نظر بگیر».

Retired the other units with a `selectable: false` flag rather than deleting them, so stored and
imported values in kPa/kg/cm²/barg/K keep converting. That exposed a distinction the original
design had glossed over: the canonical storage unit (kPa) is no longer a legal *display* unit, so
the fallback for an unconfigured project had to become a new `default_display` (bar).

**Sandbox reset #32 at the start of this turn** — rebuilt PHP 8.4, Composer, vendor, PostgreSQL,
the database, and (newly) **chromium + poppler-utils + fonts-vazirmatn**, which brought 13
previously self-skipping PDF tests back to life. Full suite now **767 passed / 2998 assertions,
zero skipped** (was 758 passed with 13 silently skipped).

5 new mutants on the narrowing logic, all caught; 4 new pack-corruption probes, all caught.

### 2026-09-17 — units of measure (ADR-014) wired end to end

Built on the previous session's engine: `UnitPreferenceService` (user → project → canonical),
canonical mirror columns populated on every write via `PipingLineService::canonicalValues()`, a new
`updateDesign()` path (there was none — design conditions could only be set at creation), the pack
schema + `check_units()` CI gate, FA/EN keys, and the register UI (two new columns, value+unit
inputs, a units panel with separate "just for me" and "project default" buttons).

Verified end to end over HTTP against a real login: created a line at 285 psi / 650 °F, switched
the reader's units to barg, confirmed the display changed to `19.65 barg (285 psi)` and the stored
row did not change at all.

Full suite **758 passed / 2980 assertions** (was 667 / 2751). Units mutation total **38 run, 0
survivors**; M28 and M38 survived first pass and both exposed real gaps. Pack validator proved by
breaking `units.ref.json` six ways — all six caught.

ADR-014 written (it had been referenced in docblocks but did not exist).

Append one row per session. Keep it terse.

| Date | Change | Result |
|---|---|---|
| 2026-10-07 | **Development environment containerised (TODO §4 priority 0).** `compose.yaml`, `docker/php/Dockerfile` (PHP 8.4, Composer, Node 22, PostgreSQL 17 client, headless Chromium + poppler + Vazirmatn, Python 3), an entrypoint that is the container counterpart of `restore.sh`, `docker/postgres/init/01-epcc-databases.sql`, four `scripts/dev-*.sh`, `.github/workflows/ci.yml` and `docs/DEVELOPMENT-ENVIRONMENT.md`. Two traps found while writing them, both silent. **(1)** Exporting any name Laravel reads: `DB_DATABASE=epcc` sends the suite's `migrate:fresh` at the development database, and `APP_ENV=local` defeats PHPUnit's `force="false"` overrides entirely, so the suite stops running in `testing`. compose now passes only `EPCC_*` names and the entrypoint writes `app/.env`. **(2)** The obvious `POSTGRES_USER: epcc` makes the application role a SUPERUSER, which bypasses RLS even under `FORCE ROW LEVEL SECURITY` and turns every fail-closed tenancy assertion red — so `postgres` administers and a non-superuser `epcc` owns both databases, with CI asserting `superuser=f bypassrls=f`. The Dockerfile refuses to build without the PDF toolchain and `dev-test.sh` fails on a non-zero skip count, because `markTestSkipped()` still exits zero (REBUILD.md §4). | 4 CI jobs (`static`, `prototype`, `laravel`, `image`). No Docker, PHP or PostgreSQL in this sandbox, so the scripts and the entrypoint were exercised against stubbed binaries instead: first boot, second boot, all four `SKIP_*` opt-outs, the unreachable-database exit path, `.env` rewriting for duplicate keys, and both PHPUnit summary shapes for the skip gate |
| 2026-09-15 | **Phase 1b (§5s): the numbering editor and evidence attachment — the two things that made phase 1 *correct but not operable*.** The number format could only be changed from tinker, which is a hardcoded rule with extra steps; evidence could only be attached programmatically, so the gate was demonstrable but not usable. Both are now screens. Probed the engine before designing the editor's guard rails rather than reasoning about them: a **counter-less pattern composes to the identical string twice**, so the second create dies on the uniqueness check with "number already taken" — symptom named, cause hidden, project silently capped at one line per subsystem. Four rules now refuse at the point of editing, including that counter width may grow but never shrink below what was issued (padding is render-time, so narrowing corrupts nothing until the project crosses the threshold, which is exactly what makes it dangerous). Well-formedness is delegated to `NumberPattern`'s constructor so the two cannot drift — which exposed that **`AmbiguousPatternException` is not a subclass of `InvalidPatternException`**; both extend `RuntimeException` and are `final`, so catching one let the two-counter case escape as a 500. Driving the register with curl then found the defect that mattered: **attaching evidence is not exclusive and the gate checks every link**, so one B-coded drawing attached by mistake locked a line out of AFC permanently with no way back but a database edit. Added `detachEvidence()` — draft lines only, because removing the justification for a decision already taken is not a correction. **Mutation M21 survived the first pass**: nothing stopped a hand-edited URL from pairing line A with line B's evidence link, and since both rows live in the same project **RLS is perfectly happy** — the ownership check was the only guard, and it was untested. Also: `TableToolsTest` correctly caught the config screen's token grid, which legitimately must not be sortable because **the row order *is* the data**; declared `data-tt-exempt` in the view with its reasoning rather than weakening the guard, then confirmed the guard still bites | **667 / 2751**, 21 new tests, **mutants 14–22 caught, 0 survivors** |
| 2026-09-15 | **ADR-006 phase 1 built (§5r): piping lines, per-project numbering, and the AFC gate.** The first piece of the engineering spine — every component, joint, weld and NDT record eventually resolves to a line. The number format is **data, not code**: a jsonb token list per project, composed and parsed by an engine with the vocabularies injected. Confirmed against real fixture data that the obvious implementation is wrong — **`explode('-', …)` yields 9 fragments for 6 tokens**, because the subsystem code contains three separators. Two defects existed before a line of test ran: `confirmAfc()` called **`CdeState::isApproved()`, which did not exist**, on **`$revision->state`, a column that does not exist**. Fixing it forced the real question — what *is* approval? Answered from the ISO 19650-2 table already in the code rather than invented: `PUBLISHED` **and** an A-family suitability, because **B1–B5 mean "approved with comments"** and waving them through is exactly the rework the gate exists to prevent. Mutation testing then earned its keep twice: **M1** showed my longest-first-sorting test proved nothing (PCRE backtracking rescues `A1|A1B`, so the real hazard is a *following* token absorbing the difference — `PH-14` vs `PH-14-SS`, wrong subsystem, silently), and **M8** showed the `PUBLISHED` half of the gate could be deleted with the suite still green, because the SHARED+S2 fixture fails the A-check anyway; the test that separates them is **SHARED + A1**. Built the register UI and drove it with curl, which surfaced two more: a legitimate refusal escaped as a **500**, and the form offered free text where a project register governs. Imported numbers keep **`sequence` NULL** so a foreign `…-777` cannot push our counter to 778 | **647 / 2716**, 61 new tests, **13 mutants killed, 0 survivors** |
| 2026-09-15 | **Project archive built (§5q) — the answer to ADR-013's open question, which the user settled as «آرشیو».** `ACTIVE ↔ ARCHIVED`, reversible, with **no `DELETED` state**: deletion stays a separate ceremony rather than one dropdown position away. Archived projects are read-only, hidden from the portfolio behind a clickable count, and **excluded from `plans.max_projects`** — the commercial crux, because a customer on a one-project plan who cannot start job two without deleting job one *will* delete job one, and the licence terms would be instructing them to destroy contractual evidence. Two layers, both necessary and failing differently: the service refuses loudly and translated, RLS is the backstop. Spiked the mechanism before writing it and found the asymmetry that shaped the design — **a blocked UPDATE/DELETE raises nothing**, `rowCount=0`, `save()` returns true, so RLS alone would tell a user "saved" while the edit vanished. Then found a real hole by trying it rather than trusting the design: **`WITH CHECK` is never evaluated for DELETE**, so the freeze policy reported `DELETE 9` and emptied an archived project's punch list — fixed with a second `FOR DELETE USING (...)` policy per table (22 × 2). Also uncovered incidentally: **`SetUserLocale` was registered on the Filament panel only**, so every `__()` outside the admin panel fell back to the default locale; invisible while only views used it (they have their own `?lang=` closure) and exposed the instant a service threw a translated exception | **586 / 2564**, 30 new tests |
| 2026-09-15 | **Phase 0 built: the engineering reference packs (§5m, ADR-007 → ACCEPTED AND BUILT).** First code from ADRs 006-010, and deliberately first: the line-number parser, the compatibility engine and the PCF importer all need the size vocabulary before they can validate anything. Four versioned JSON packs (36 sizes, 355 schedule pairs, 13 PCF end types, 20 component templates) behind one memoised singleton - **not** database tables, because the protection needed is *nobody can write, including the owner company*, which a file gives absolutely and a permissive RLS policy only pretends to. The ADR predicted from published sources that **STD is not an alias of SCH 40 above 10″ and XS is not SCH 80 above 8″**; the shipped data now asserts it in three layers. Two defects: PHP **coerces numeric string array keys to integers**, so `schedulesFor()` returned a mixed `int|string` list (caught by the suite on first run); and the reachable **alias-fallback bug runs the opposite way to the assertion** - ASME defines STD at 22″ and 26″ but no SCH 40 there at all, so a "helpful" fallback returns 9.53 mm for a schedule that does not exist. That one **survived the first suite** and was found only by mutation M1. M14 also showed the singleton test proved nothing: instance identity is not memoisation, so it now warms the cache, deletes the files, and asserts a *fresh* instance still throws | **556 / 2491**, **153 mutations caught** (+15 pack-data, +15 PHP) |
| 2026-09-13 | **Physical breakdown built (§5l, ADR-004 → ACCEPTED).** `project → facility → (optional) area → subsystem`, after establishing that Plant 3D has **no** System/Subsystem, MC, punch or handover — so compatibility is an **import mapping**, not a copied schema. One `facilities` table with a `FacilityKind` discriminator instead of sibling plant/pipeline tables, because what they share is being a commissioning parent and what differs is addressing (per-kind `jsonb`). Numbering moved to **per facility**, which made the bare code ambiguous — so `fullCode()` composes at read time (never stored: it would drift on rename) and the register shows Facility as a non-toggleable column. Integrity rests on a **composite** FK `(area_id, facility_id) → areas(id, facility_id)`, making cross-facility corruption unrepresentable. The fixture is deliberately uneven — one facility with areas *and* a direct subsystem, one with no areas at all — because a uniform fixture cannot fail informatively. Two traps recorded: the backfill silently matched **zero rows** under `FORCE ROW LEVEL SECURITY` (RLS filters, it does not error), and **M118 first reported SURVIVED because the mutation was wrong, not the test** — dropping a constraint in `psql` proves nothing when `setUp()` runs `migrate:fresh`. Mutate the migration source. Pushed as `cf99f0f` (§9a — a reset had wiped `.git/config`, so the remote and the git identity had to be recreated first) | **507 / 1716**, **123 mutations caught** |
| 2026-09-13 | **UML for the procurement module (`docs/uml/`).** Installed `graphviz` + `plantuml` (absent from the base image; plain `apt-get` fails the dpkg lock, `sudo` works) and drew five diagrams — domain model, the three state machines, an inspection-to-MC-gate sequence, reversal + RLS, and the component view. Written against a live `information_schema` dump rather than from memory, so the attribute lists are the real columns. Packaged as `docs/uml/uml.html` with the SVGs **inlined** — checked for external refs and found none, matching the `tour.html` air-gap pattern — and verified by screenshot rather than by byte count | no code change, **482 / 1647** |
| 2026-09-09 | Docs, standards packs, prototype, ADRs, Laravel scaffold, standards engine, conformance corpus | Foundations in place |
| 2026-09-09 | PostgreSQL + RLS spike, multi-project, Octane and PgBouncer spikes | All CLOSED, 12 standing rules recorded |
| 2026-09-09 | Auth + six-gate authorization, `BindTenant`, project setup & team screens | Vertical slice works |
| 2026-09-10 | Preview login debugging, rounds 1–5 (cookie attributes) | **All failed** — wrong layer |
| 2026-09-10 | Cookie-less preview: `PreviewSessionFallback` + `PreviewUrlRewriter`; fixed mixed-content `redirect()->back()` | **Login works in the preview** |
| 2026-09-10 | Entitlement-driven sidebar, view composer, `HANDOFF.md`; fixed `?as=` reflection regression | 147 tests green |
| 2026-09-10 | **Sandbox reset #6** — PHP, PostgreSQL and `vendor` wiped, source intact. `restore.sh` rebuilt it in ~43 s | 147 tests green, preview back up |
| 2026-09-10 | Collapsible sidebar: icon rail (desktop) + off-canvas drawer (mobile), ported from the prototype; pre-paint state restore | 150 PHP tests + 17 jsdom assertions green |
| 2026-09-10 | **Sandbox reset #7.** Toggle was dead — script ran before its button existed; the jsdom test had masked it by re-running the script post-parse. Fixed both. | 151 PHP + 17 jsdom green |
| 2026-09-10 | Desktop rail snapped with no animation: no width transition outside the mobile query, and `display:none` labels are unanimatable. Added `sidebar-animation.test.cjs`. | 152 PHP + 29 jsdom green |
| 2026-09-10 | Language switch invisible — the animation change gave an inline `<a>` `max-width`, which inline boxes ignore. Fixed with `inline-block`; guard added. | 152 PHP + 36 jsdom green |
| 2026-09-10 | **Document register / CDE shipped** (ISO 19650 states, numbering, revisions, RLS). Caught a cross-project RLS leak and a lazy-load-outside-scope trap in the process. | 173 PHP + 36 jsdom green |
| 2026-09-10 | **File attachments shipped** (content-addressed, allow-listed, streamed through authz). Then live verification exposed that participants saw an EMPTY register — the CDE was not common. Migration 130000 makes the CDE state the sharing boundary. | 196 PHP + 36 jsdom green |
| 2026-09-10 | **Filter + sort on every data table** (FR-UX-04): reusable partial, Persian-digit folding, lifecycle-ordered CDE column, sweep test over all views. | 206 PHP + 80 jsdom green |
| 2026-09-10 | **Review & comment cycle shipped** (FR-ENG-06, journey 3): categories, dispositions, closure stats, and a publication gate wired into the state machine. Two real bugs caught by tests (unreflected column default; invalid `FOR UPDATE` + aggregate). | 225 PHP + 125 jsdom green |
| 2026-09-10 | **Transmittals (FR-ENG-05)** + ZIP packager. Found and fixed a **draft-visibility leak** (addressees and the employer could read unsent letters) and the **child-policy RLS recursion** it exposed; corrected a test that encoded the wrong model. Harness fixed for page-shape and collation assumptions | **248 / 836**, 128 jsdom, 36 mutations caught |
| 2026-09-10 | **Sandbox reset #8** — `.cache` (and with it `vendor`) wiped; the workspace also rolled back past the transmittal work. Recovered in full from `source-backup.tar.gz`, which is why it is refreshed at the end of every session | 249 / 838 green after restore |
| 2026-09-10 | Blob-store purge in `tests/bootstrap.php` + `BlobIntegrityTest`; workspace 13,263 → 318 files | File cap no longer at risk |
| 2026-09-10 | **Sandbox reset #9** — PHP, PostgreSQL and `vendor` wiped, source intact (incl. transmittals). `bash restore.sh` rebuilt in ~38 s | 249 / 838 green after restore |
| 2026-09-10 | **QA/QC + punch list + MC certificates (FR-COM-04/05, journey 5).** Added the `MC-KARAN` tenant the fixture lacked; gave `consultant` the `punch.*` it was missing. Caught an **inert test** in mutation testing — "contractor cannot verify its own fix" passed with the guard deleted, because the tenant-type rule threw instead; fixed by asserting on the message and using a verifier-type company. Fixed 3 harness over-assumptions (`data-sort="none"` counted as declared, single-value facets, digits inside identifiers) | **284 / 939**, 345 jsdom (7 fixtures), **46 mutations caught** |
| 2026-09-10 | **Sandbox reset #10** — PHP/PostgreSQL/vendor wiped again; `bash restore.sh` rebuilt in ~45 s and **auto-reinstalled jsdom** (the fix added last session paid off immediately) | 284 / 939 green after restore |
| 2026-09-10 | **PDF export via headless Chromium (§5f) — retires the PDF half of risk IR-R2.** Rasterised and visually verified Persian output rather than trusting a byte count; found and fixed a per-page footer collision and a category column that wrapped to four lines. Mutation testing found the `%PDF-` magic-byte guard was **completely untested** (a fake browser writing garbage would have been served as a certificate) and that `isAvailable()` is only a fast path, not the guard that keeps the ZIP alive | **301 / 1002**, 257 jsdom (5 pages × table tools + 36 sidebar), **54 mutations caught** |
| 2026-09-11 | **Sandbox reset #11** — same wipe; `restore.sh` rebuilt in 58 s and **auto-installed Chromium + Vazirmatn + poppler** for the first time, so PDF export survived the reset untouched | verified live: cert PDF 200, Vazirmatn embedded |
| 2026-09-11 | **Shell layout bug reported by the user** — punch, transmittals and document-review put the sidebar outside `.app` and the topbar as a direct child of it, so content slid under the sidebar and the collapse button went missing. Root cause was markup order, not CSS. Also gave `/gate` the shell (it is linked from the sidebar but had none, stranding the user) while keeping it usable logged-out, moved `$user`/`$acting` into the view composer as defaults, and fixed a literal `ips.iran{{ $packVersion }}` caused by Blade's `@{{ }}` escape | **319 / 1110**, **57 mutations caught** |
| 2026-09-11 | **Register column shift + category letters (both user-reported).** The QA/QC table showed "Subsystem" above the category data: `.mono` sets `display:inline-block` for LTR runs and was on `<td>`, which replaces `display:table-cell` and drops the cell out of the column layout. Cell counts matched, so only per-cell geometry in real Chromium found it; the same latent bug was on the document-review table. Fixed with `td.mono{display:table-cell}`. Also switched punch categories from الف/ب/ج to **A/B/C in both languages**, including the gate message and the MC certificate PDF | **325 / 1149**, **60 mutations caught** |
| 2026-09-11 | **Sandbox reset #12** — mid-task; `restore.sh` rebuilt in 58 s with Chromium/Vazirmatn intact | — |
| 2026-09-13 | **Procurement & materials (§5k).** Built the chain the user named: تهیه ← بازرسی ← ورود به انبار ← خروج از انبار ← ورود به سایت. 7 tables, 7 models, 2 services, 2 screens, 51 tests. Key decisions: one append-only movement ledger rather than four document tables; the sign convention in code not data (`SITE => 0`, or site delivery double-deducts); ISSUE and SITE kept separate so material on a laydown area stays visible; lots keyed to heat number with the MTC as a CDE document; inspection advisory per the user's instruction, paid for with a permanent "needs attention" panel; two distinct SoD rules on the requisition. RLS is commercial here — a vendor sees its own PO and not a competitor's, and never sees a requisition | **482 / 1647**, **117 mutations caught** |
| 2026-09-13 | **AG-06 shipped, and a ninth defect (§5j).** Wrote `verify:airgap`, the pre-flight the customer runs at acceptance, with a BLOCKER/LATENT/BENIGN split so the output stays actionable. Writing it found two leaks the suite could not see: Pusher's CDN, hidden from the first scanner because `echo.js` concatenates the URL at call time, and **`ui-avatars.com`**, which Filament builds in PHP from the user's name and rendered into every admin page - an un-fetchable image on site AND an employee's real name handed to a third party. The avatar one exists in no file on disk and was found with a browser net-log; fixed with `LocalAvatarProvider` (inline SVG initials). Dropped `FilamentInfoWidget` too. The test now asserts on rendered HTML, not just files, because that is the only place a runtime-assembled URL is visible | **427 / 1523**, **113 mutations caught** |
| 2026-09-13 | **The mobile blank page (§5i-3).** Building a screenshot tour for a phone, the first shot came back as a single flat colour: `/documents?lang=fa` at 430px painted **nothing**, while the same page in English was fine. Cause was `min-width:auto` on a flex item — a 1032px table widened `.wrap` past a 485px viewport, and in RTL that pushes the whole document off-screen rather than clipping it. Fixed once in the shell with `min-width:0` + `overflow-x:auto`; both halves needed, since containment alone hides the state and revision columns. Bisected by measuring unique colours per render, which is what separated "page is broken" from "screenshot tool is broken" and then LTR from RTL. Also shipped `tour/tour.html`: a self-contained, data-URI gallery so the work is reviewable on a phone where the live preview cannot open | **416 / 1433**, **111 mutations caught** |
| 2026-09-12 | **Certificate evidence integrity, and clearing two pieces of flagged debt.** Started on the `User::find()` in `PunchController` flagged as unconverted since the identity-table work — and it turned out to be **correct**: the `users` counterparty policy already covers reading an issuer from another company, verified from all four participant sides. But the fixture had **never issued a certificate**, so the whole signatory path was unrendered by any test; the blade guards it with `@if($issuer)`, meaning a failure drops the "issued by" line from signature evidence rather than erroring (**M105**). Then, having finally rendered an issued certificate, downloading it twice showed the real defect: the punch summary was **recomputed live on every render**, so an issued certificate's own numbers drifted as the site worked on — closed 2→3, open A 2→1, always in the flattering direction. Fixed with a `punch_summary` jsonb snapshot written at issue, mirroring `exception_items`; drafts deliberately stay live (M107–M109). Also replaced all **ten** `Subsystem::first()` call sites with an explicit code lookup — proven load-bearing: pointing the helper at a different subsystem fails 8 tests | **414 / 1423**, **109 mutations caught** |
| 2026-09-12 | **Subsystem admin resource, a fixture that could finally tell rules apart, and a panel-wide digit defect (§5i-3).** Built the read-only Subsystem register whose point is the **derived** MC gate — no state column exists, so the table asks `PunchCategory`/`PunchState`/`McCertificate` for the rules and computes counts with `withCount` rather than the model's collection-walking helpers (quadratic on a register); a probe confirmed SQL and model agree row by row. `closurePercent()` returns 100 for an empty list, so an un-walked subsystem says **"not walked down"** instead of claiming completion. **Two mutations survived** and neither was an assertion problem: the fixture had no A-item in VERIFIED and no B-only subsystem, so "VERIFIED still blocks" and "only A blocks" were unprovable. Added SS-5501 and SS-6601, then M96 and M99 died — M96 having survived a test that checked `PunchState::isOpen()` and the model helper while the **table** disagreed with both. Growing the fixture broke three PunchList tests hardcoding `PL-0006`/`count=5`; de-hardcoded rather than renumbered. Screenshot then caught a defect shipping since the first resource: Persian pages mixed **Persian digits in our columns with Latin in Filament's pagination**, on all five resources. Fixed once at the translator (`LocalisedNumberTranslator`, bound in `register()` not `boot()`), converting only wholly-numeric parameters so tags stay Latin — a guard **unobservable through the UI**, so pinned against the translator directly rather than by an inert HTTP test | **410 / 1401**, **104 mutations caught** |
| 2026-09-12 | **Users admin resource, and the identity-table leak it exposed (§5i-2).** Before writing the resource, checked whether `users` was even under RLS: it was not. Bound as EPC-PARS the database returned **all nine users of all eight companies** — the client's reps, the PMC's inspectors and two rival EPCs' engineers — while documents correctly narrowed to 5. Added RLS on `users` + `project_memberships` with a counterparty clause, hitting **policy recursion** (the two policies read each other; re-expressed through `project_company`) and re-learning **rule 3** (`NULLIF` on every GUC read). Login needs a read before a tenant exists, so added the greppable `forIdentityLookup()` hatch — which then had to **snapshot-restore rather than force-clear**, because a nested call was shutting the hatch its caller still needed and silently leaving the disabled fixture account enabled. Then the screenshot: **every `/admin` route redirected to login on a valid session**, because Filament resolves the user before `BindTenant` and `actingAs()` had hidden that from all 21 panel tests. Fixed at the user provider. **M95 proved the first test for it was inert too** — `SESSION_DRIVER=array` means `retrieveById()` never runs in tests | **395 / 1348**, **95 mutations caught** |
| 2026-09-12 | **Transmittal admin resource + the Jalali defect (§5i).** Read the domain classes before writing a line (`TransmittalPurpose::label()` returns a string where `PunchState::label()` returns an fa/en array) — the habit that stopped a repeat of the invented-constant bug. Built a read-only Transmittal resource showing **both streams in one list** with `kind` as a filter, the inverse of the hand-written UI's deliberate split. Then the screenshot showed `سپتامبر 12, 2026` on a fully Persian page: Filament's `->dateTime()` renders **Gregorian**, and on a submission log the date is contractual. Root cause was structural — Jalali formatting existed only as a private `$jdate` closure copy-pasted into each Blade view, so a surface written later could reuse none of it. Extracted **`App\Support\JalaliDate`** and routed all three panel tables and all ten views through it; no `Morilog` call remains in `resources/views`. `DateFormattingTest` guards the **shape of the codebase**, not just output (M87–M89) | **378 / 1305**, **89 mutations caught** |
| 2026-09-12 | **Admin resource scope + punch resource (§5i).** The generated Document form exposed `number`, `sequence`, `company_id` and `current_revision_id` as free inputs — retyping a number collides with the unique index, changing the company makes a document vanish from its author's register. Form reduced to the bilingual titles; create/delete withdrawn. Added a **read-only** PunchItem resource: `state` is a workflow position with rules about who may move it, and `McCertificateService` reads that column, so an editable form would let an admin forge a VERIFIED and unblock a completion certificate. **A grep is not an assertion** — the first no-delete test failed against its own explanatory comment; rewritten against `canDelete()` / `getPages()` | **369 / 1275**, **84 mutations caught** |
| 2026-09-12 | **Filament v4 admin panel (§5i).** Wrote the tenancy test FIRST, and it earned its keep: with the stock middleware stack the panel showed the signed-in contractor **nothing at all** — RLS failing closed — so the "no leak" test passed on a broken screen. Only the mirror test ("still shows its own rows") could tell the two apart. Three more real defects: `->font()` pulls from Google Fonts (**air-gap violation**, now pinned by a CDN-host test), `canAccessPanel` was untested so a **deactivated account could open the admin panel** (M79), and the state column was bound to `currentRevision.state` when the attribute is `cde_state` — an **empty cell on every row** that returned 200 and was found by looking at a screenshot, not by a test (M81). Added `SetUserLocale` + the project's first `lang/` files | **363 / 1256**, **81 mutations caught** |
| 2026-09-11 | **Corrected the meaning of `MC` (§5h).** The user asked "do you know what MC means?" — it is **مدیریت پیمان / Management Contractor**, the employer's contract administrator, not the "Mechanical Completion body" the seeder, two views, the SRS role table and the coverage map all claimed. **No test could have caught it**: a tenant type only has to be a matching string, and the role rules were already right, so the behaviour passed while the screen lied. Added `TenantType` (nine types, one place — they were loose strings in five files), a CHECK constraint on `companies.tenant_type`, and `TenantTypeTest` which pins the words themselves. Renamed the fixture company to مدیریت پیمان کاران and the role to `mc_supervisor` | **356 / 1240**, **77 mutations caught** |
| 2026-09-11 | **Vendor transmittals as a separate stream (§5g).** Asked the four structural questions first (who records, what "separate" means, roll-up traceability, document typing) rather than guessing. Separate `VTR` series, own screen, `source_item_id` chain, two CHECK constraints, `VEN-AZAR` added to the fixture with two seeded letters. **Mutation testing found the HTTP create path was untested** — a controller ignoring the submitted `kind` filed vendor letters into the contractual series and the whole suite still passed. Narrowing the employer RLS clause surfaced a genuine leak: the owner could read supply-chain letters | **349 / 1202**, **74 mutations caught** |

## 2026-10-13 CI integration checkpoint

- PR #7 run 38361941268: standards, pure PCF, image and prototype green;
  Laravel and compose red. Laravel migrated through 235700, staging RLS and
  `btree_gist`, then failed at P1 with duplicate `piping_classes` (already
  created by the 2026-09-15 piping-line migration). P1 now extends the existing
  register in place and retains its RLS/archive policies and referenced IDs;
  legacy classes have no fabricated DN coverage and cannot publish without it.
  This correction is **not yet CI verified**. The author policy still does not
  gate PipingClassService writes. Recheck the next CI run before declaring success.

## 2026-10-13 `pre-work` branch audit

The owner requested a full review and selective transfer. Inspected remote tip
`878d34f`, its two upload commits, 1,881 tracked paths, four source archives,
and the 1,047-path nested repository against the present branch. Detailed
inventory and decisions: `docs/PRE-WORK-BRANCH-INTEGRATION-REVIEW-EN.md`.
No source was copied: the material/fitting core already has a newer integrated
version; the unique response/disposition, PMS history/NDT, baseline and ITP
features depend on a different schema, while logs, backups and screenshots are
not deployable source. Never bulk-merge this branch. Next possible safe slice:
adapt its read-only material-screening CLI with a synthetic fixture and run a
PHP regression, after resolving the current CI PMS migration failures.

## 2026-10-13 selective `pre-work` recovery

Brought over only the independent read-only screening CLI, its synthetic
fixture and its standalone assertions from nested `pre-work` tip `878d34f`.
Wired it into CI's PHP standards job and the local degraded runner; no Laravel
schema/service was replaced. Local PHP unavailable; CI verification pending.
See `docs/PRE-WORK-BRANCH-INTEGRATION-REVIEW-EN.md` for boundaries.

- CI run 38368929870 (commit `4083be8`): the independent standards job,
  including the recovered screening regression and JSON/HTML CLI smoke, is
  green; prototype, pure PCF, development image and compose are also green.
  Laravel job was still running at the last check. Prior run 38362372660 had
  reached PHPUnit but failed on legacy `piping_classes.name_en` inserts and
  unrelated material-reference expectation errors; do not claim the whole
  suite is green. See GitHub Actions for the final run result.

- The previous fully completed Laravel run 38362372660 reached PHPUnit:
  legacy line/component tests failed because the P1 migration required names
  older class creation never supplied; material-reference tests also reported
  independent stale expectations. Added database name-fill trigger and focused
  legacy-insert regression, still awaiting CI. Run 38368929870 was cancelled
  by the newer push before its Laravel job completed; run 38370108973 was
  in progress at last inspection. Do not report either cancelled run as a
  Laravel test result.

- CI run 38370511965 completed: all jobs except Laravel green. PHPUnit
  repeatedly failed because `migrate:fresh` drops tables but does not drop the
  standalone `epcc_piping_class_fill_names()` PostgreSQL function: its second
  CREATE FUNCTION raised SQLSTATE 42723. Changed P1 migration to CREATE OR
  REPLACE FUNCTION, with the trigger still bound to each newly created table;
  this fix is awaiting CI. Three independent `MaterialReferenceTest` cases
  also fail against pack semantics (PSL ambiguity, 816 deg C max use, W
  coefficient), and must be resolved against reference data, not by relaxing
  safety rules to match old test literals.

- MaterialReference PHPUnit failures were stale test expectations, not a
  reason to loosen material guards. Cross-checked the committed A-1 and
  302.3.5 reference-pack rows: API5L L290 has both PSL1/PSL2 (explicit PSL
  required; max use 260 C), TP304 max use 816 C even though a stress column
  exists at 825 C, CrMo W at 524 C is 0.84, and CSEF N+T W at 510 C is 1.0.
  Corrected only the test cases to exercise valid temperatures and explicit
  PSL selection; CI verification pending. Never infer approval from an
  out-of-range column or silently select a PSL.

- CI run 38372294654 completed: five non-Laravel jobs green; Laravel red.
  The repeated-migration trigger error is gone. Remaining annotations: missing
  DI binding for FittingDimensions; two tests calling absent parallel-PMS
  `PipingClassItem` / `PipingClassBody`; and an exact CSEF W=1.0 column at
  510 C rejected because the interpolation routine examined its preceding
  dashed column first. Bound the reader using the same reference directory
  and PipeReference as other readers; fixed exact-column lookup before
  interpolation; removed **only** the two impossible parallel-consumer tests
  from the reader test while retaining pack and current fitting-review tests.
  CI verification of this set pending. No missing parallel PMS table/model was
  fabricated and no engineering applicability guard was relaxed.

## 2026-10-13 CI run 38375775331

Five non-Laravel jobs passed. Laravel completed with 10 annotated failures/errors:
PipingClass publish/read-only stale object and localized gap assertion; an
OrderGap lineage assertion outside RLS tenant scope; three HTTP screening
snapshot requests and one fitting-review HTTP request to the absent
`project-fittings` route; a material requisition test creating absent parallel
`System`; a quantity-boundary response mismatch (302 vs 422); and an exact
CSEF W temperature still rejected. The earlier exact-factor patch was
mistakenly placed in `stressOf()` (and referenced undefined variables); moved
it to the factor interpolator, preserving `stressOf()` checks. PMS draft
checks now refresh state under tenant RLS instead of trusting a stale object;
the gap test checks the actual missing interval rather than a translated kind.
The OrderGap relation assertion now runs in tenant scope; the MR fixture uses
the current facility-to-subsystem schema without fabricating System. These
changes still need CI validation. The four absent-route assertions and the
quantity response mismatch remain open. Do not weaken RLS or add phantom
schema to satisfy them. PMS write-path policy is still not enforced.

## 2026-10-13 run 38378658637 and HTTP integration

CI: five non-Laravel jobs green, Laravel red. Previous fixes removed the
OrderGap lineage failure, stale class publish bypass and exact-factor error.
Remaining issues included missing `project-fittings` HTTP route (four tests),
two RLS sargability fixtures lacking required facility_id, a duplicate-branch
constraint abort that poisoned a containing tenant transaction, a P1 test
expecting publication despite missing corrosion allowance, one MR quantity
HTTP 302/422 mismatch, and one PDF timeout under CI load.

A cohesive, authenticated fitting/material declaration + review HTTP slice was
ported with actual tenant-bound reads, service-authorized writes, archived
project lock and stored-vs-live screening evidence, without importing the
parallel PMS or finding disposition subsystem. Added link on piping register.
Other fixes: sargability fixtures now attach to a real project facility;
rule inserts use nested transaction/savepoint so database constraint failures
can be converted to validation errors without poisoning the tenant transaction;
P1 test now verifies missing corrosion allowance still blocks publish rather
than inventing it. CI validation of all these changes pending. PDF timeout and
MR quantity response mismatch are not yet resolved. Never claim all tests
pass until a complete run confirms it.

## 2026-10-13 run 38381333457: security finding

The HTTP fitting/material routes passed their previously missing-route tests;
five non-Laravel jobs passed. Laravel found a **real RLS leak**: a PH-14-bound
employer read its KISH-1 payment certificate because the generated policy
combined `scope AND own OR owner` without parenthesizing the owner branch.
Changed generator to `(scope) AND (membership body)`, affecting both migration
directions on a fresh install; the existing RLS test pins the isolation.
Other remaining failures: synthetic RLS fixture assumed a project facility
exists (now create an actual facility under tenant scope), JSON EXPLAIN result
was double-decoded as a string (now handles raw JSON), and invalid MR quantity
`' 1'` was silently trimmed to `'1'` by global middleware (MR quantity key now
excluded from TrimStrings, still strictly validated by service). CI pending.
This is not evidence of a successful full suite or of complete PMS authoring.

- Added an HTTP-level mirror for the newly restored fitting/material register:
  a nonparticipant must receive 404 on GET, create and submit, while a
  participant retains a 200 read. This closes the gap where DB/service tests
  alone could pass while the HTTP route is accidentally exposed. CI pending.

## 2026-10-13 run 38383865549: isolation passes; two fixture-count failures

For commit `b0ccbf2`, standards/rule engine, PCF, prototype, development image,
and compose all passed. Laravel ran to completion with exactly **two failures**,
both in `RlsSargabilityTest`: tests counted all visible punch rows as if the
demo seeder had none (10 instead of 1; 30009 instead of 30000). The tests now
count their own `PI-SHAPE-1` / `PI-%` generated rows while still separately
asserting no foreign `KI-%` rows leak; no RLS policy or seed was changed to
paper over the count. The previous PH-14/KISH-1 employer scope leak and the
new HTTP nonparticipant mirror did **not** recur in this run. CI recheck of
the revised assertions is pending. PMS author-policy nomination still does
not gate `PipingClassService` writes; full authoring protection remains open.

## 2026-10-13 CI baseline after selective integration

**Run 38386417769 for commit `d62b848`: ALL SIX CI JOBS PASSED.**
Laravel suite (PostgreSQL + RLS), standards packs/rule engine (including the
recovered material-screening CLI), pure PCF, HTML prototype, development
image and compose stack succeeded. The two sargability probe-count assertions
were the final failures in the preceding run; now they pass without weakening
RLS. Exact PHPUnit test/assertion counts were not available: `gh run view
--log` failed to fetch the hosted log (EOF), so no count is invented. The
successful CI run verifies only the committed scope: the independent PMS
nomination policy still does **not** gate PipingClassService writes, and the
partial stale-object state re-read is not an atomic publication lock. Next
step is a dedicated ADR/tested design for full PMS write-path enforcement and
concurrency protection; do not declare authoring protection shipped.

## 2026-10-13 PMS authorization design checkpoint

Commit `9c82a34` (documentation-only) completed all six CI jobs in run
38389653045. The code baseline is green, but the current author nomination
is not a write gate. Audited the six PipingClassService mutators and the
shared `piping_classes` identity with the legacy line register. ADR-027 is a
**PROPOSED** requirement/decision record: service-only `allows()` checks
would leave direct writes and mutation provenance unprotected; a blanket DB
class trigger would break legacy line entry. Recommend explicit activation
and policy-bound write provenance on the shared identity with transaction
locks and database backstops (option C), pending owner confirmation versus a
separate PMS class aggregate (option B). No authoring gate code or schema has
been added. Ask the owner to choose before enforcing it; never claim the
policy is already effective.

## 2026-10-13 owner correction: class before line

Owner explicitly requires piping classes to be registered before line-register
entry. Recorded in ADR-006 and ADR-027. Current PipingLineService still permits
nullable class references and tests create classes as fixtures; no runtime
constraint has been changed yet. Need owner decision on whether a class must
be PUBLISHED before line use and how to handle historical/imported lines with
no mapped class. Do not create placeholder classes or assume the line may
silently register its own class. Sandbox restored a base Git HEAD while keeping
worktree files; fetched the remote branch and realigned HEAD to remote tip
`38c8b8b` with `git reset --mixed FETCH_HEAD` (no worktree changes), then
continued on the same tracked branch.

## 2026-10-13 class-before-line decisions

Owner answered both open workflow questions: line entry requires an existing
**PUBLISHED same-project** class; historical/imported lines with no eligible
mapping are rejected from the line register (original tags can be preserved
after mapping). ADR-006 and ADR-027 updated. This does not select a separate
versus shared PMS aggregate architecture, nor authorize an incomplete
service-only author gate. Current code still allows nullable class IDs and
DRAFT classes. Audit found fixture shortcuts in PipingLineTest,
PipingConfigTest, ComponentModellingTest, JointTest, UnitPreferenceTest and
PipingLineHttpTest; flipping the runtime guard alone would leave CI red. Next
implementation slice: migration preflight/backstop + service/HTTP validation
and published-class fixtures, with PostgreSQL positive/negative tests. No
runtime change was made in this decision-recording step.

## 2026-10-13 correction: PMS is a document, not one class

Owner explicitly clarified PMS is an engineering specification document
containing one or more piping classes. ADR-028 records the hierarchy and the
missing document/revision links. Current P1 class/rule publication does not
prove a governing PMS document revision was issued/approved; previous
class-before-line decision remains, but document-state threshold and revision
pinning need confirmation. No schema or gate was invented in response. Audit
CDE documents/revisions before implementing the line prerequisite or authoring
policy. Recommendation: reuse CDE for document identity, pin class rule
snapshots to issued revisions and lines to the selected revision; never mutate
prior issue evidence. This is PROPOSED, not shipped.

## 2026-10-13 PMS document decisions reconciled with prior ADRs

Owner selected: only an APPROVED PMS document revision may govern a new line;
one class identity has one governing PMS document at a time (a document may
contain multiple classes). Existing `CdeState::isApproved` means PUBLISHED
with A-family suitability, not a B-family partial sign-off. Owner noted the
revision answer is already in project docs: ADR-008 §7 #4 and ADR-009 §4.4
require lines to remain on the class revision they were issued against;
revisions are immutable and impact/deviation reporting exposes old lines.
ADR-028 corrected to remove the duplicate question and explicitly tie the
pinned class revision to its immutable PMS document revision. Current code
still lacks document-to-class/version links and gate; no claim of enforcement.

## 2026-10-13 PMS CDE registration slice

Added `PMS` to the existing CDE document-type picklist and service-validated
PIPING discipline. A new PMS starts WIP/unapproved like every other CDE
revision; no class is auto-created, attached or approved. Focused
DocumentRegisterTest covers number, state and wrong discipline. ADR-028
updated. This is a real document identity but NOT the class-membership,
version-pinning or line admissibility gate; CI pending.

- **CI run 38443239928 for commit `186707a`: all six jobs green**, including
  Laravel/PostgreSQL/RLS and the new PMS CDE registration test. This verifies
  only typed PMS document registration/WIP state. No classes are yet linked to
  PMS revisions, no line eligibility based on document approval is enforced,
  and PMS author nomination still does not protect write paths.

## 2026-10-13 first class-to-PMS identity binding

Added migration `2026_10_13_100000_link_piping_classes_to_pms_documents.php`
and `PmsClassDocumentService`: a DRAFT class may be attached to one owned WIP
PIPING/PMS document in the same project under a current explicit author
nomination, serialized with policy replacement. PostgreSQL trigger forbids
wrong document type/project/state and reassignment. New
`PmsClassDocumentTest` checks two classes per document, default denial,
suspension, direct reparenting and non-PMS refusal. This is intentionally
**not** a class-to-issued-revision snapshot or a full direct-SQL author gate;
prior classes remain unbound. Do not enforce the line prerequisite on this
identity alone. CI pending.

- CI run 38448258557 for `0740657`: **all six jobs passed**, including the
  PostgreSQL/RLS Laravel suite and new PmsClassDocumentTest. Verified scope is
  WIP PMS document identity binding, not immutable class-specification
  revisions or approved-document line admission. Direct SQL attaching an
  otherwise valid unassigned class still bypasses the service's nomination
  check; full authoring protection remains explicitly unbuilt.

## 2026-10-13 PMS approved-revision snapshot slice

New `pms_class_revision_snapshots` ties each published class header, rule
bands and branch rules to its specific approved PMS document revision.
`DocumentRegister::transition` creates these atomically on A-family PMS
publication; zero classes, attached draft classes and classes without rules
block that approval. Document locks serialize CDE approval with class
attachment. Snapshot rows are RLS-scoped and database-immutable after insert.
Feature test covers rejected draft, snapshot at A publication, unaffected
stored values after live-rule edits and refused direct UPDATE. Not yet line
eligibility, class writer SQL protection or CDE nomination gate. CI pending.

- CI run 38453709184 for `1f9a943` **failed in Laravel migration setup**:
  PostgreSQL functions survive `migrate:fresh`, so `CREATE FUNCTION
  epcc_check_pms_snapshot()` collided on the second test (2482 downstream
  failures). Changed it to `CREATE OR REPLACE FUNCTION` for repeatability.
  Also added DB verification of the inserted JSONB against the live class and
  ordered rule arrays, so a direct INSERT cannot forge snapshot contents.
  Awaiting a new CI run; the failed run does not verify the feature tests.

- CI run 38456241655 for `f860fe6`: migration collision resolved;
  Laravel suite reported 3246 tests with zero assertion failures and one
  annotated `PdfExportTest::test_rendering_produces_a_real_pdf` Chromium render
  timeout (30 s); JUnit's nested suite totals show three errors. The other
  five jobs passed. Artifact retrieval and Actions log retrieval hit blocked
  external redirects/EOF; available check-run annotations show no PMS error.
  Added a direct forged-snapshot INSERT regression test for the trigger and
  scheduled another full run. Do not describe this run as green.

- CI run 38460152236 on `1af325a` **passed all six jobs**, including the
  PostgreSQL/RLS Laravel suite, approved PMS revision snapshot test and direct
  JSONB-forgery rejection regression. Earlier PDF timeout on 38456241655 did
  not reproduce; do not extrapolate line eligibility or full writer security.

## 2026-10-14 issue-time PMS line-pin foundation

Added nullable `piping_lines.pms_class_snapshot_id`, a FK and a trigger that
checks snapshot project/class, current A-family PMS approval for first pin and
immutable issue-time lineage. Added `PmsLineEligibility` resolver and
supersession regression in PmsClassDocumentTest. **Not wired into line
create/register/import/HTTP**; current register still admits missing classes
and null pins. Never present as strict line eligibility until every write
path and DB non-null admission backstop are complete. No old line receives an
invented assignment. CI pending.

## 2026-10-14 local PHP CLI in the repository workspace

Added reproducible `scripts/install-local-php.sh` and
`docs/LOCAL-PHP-CLI-EN.md`, with an ignored `.local/php-native/bin/php`
installation. NativePHP upstream commit and archive SHA-256 are pinned.
Installed native PHP 8.4.21; verified `php -v`, `php -l` for
PmsLineEligibility and the framework-free standards-engine conformance corpus
(**25 passed, 0 failed**). This binary has no pdo_pgsql/pgsql, so Laravel
PostgreSQL/RLS tests still run in CI; app/vendor also remains absent. Do not
claim a complete local Laravel environment. Laragon with PostgreSQL extensions
remains the primary Windows runtime. CI for the earlier line-pin commit
`f1d4ae5` completed successfully (all six jobs); the installer itself still
needs its own verification.

## 2026-10-14 repository-local Laravel install

Installed locked Laravel 13.31.0 production dependencies into ignored
`app/vendor/` with local native PHP 8.4.21 and Composer 2.6.5 PHAR pinned to a
third-party GitHub source (see trust warning in `docs/LOCAL-LARAVEL-EN.md`).
Added `scripts/install-local-laravel.sh`; it uses GitHub source clones in the
network-restricted sandbox, suppresses **only** XMLReader/XMLWriter platform
checks, disables Composer scripts/plugins, then runs Laravel package discovery.
Verified `artisan --version`, `package:discover`, `route:list`, autoload and
`/up` HTTP 200. Generated ignored `.env` with PostgreSQL configured rather
than SQLite. Local PHP still lacks pdo_pgsql/pgsql and XMLReader/XMLWriter,
`vendor/` is production-only (no PHPUnit); `/login` returned 500. Stopped
Laravel preview to avoid a broken live app; CI remains required for DB pages
and RLS tests. Full local environment requires different PHP build/Composer.

- CI for `a945088` (run 38508213581) did not start ANY job: GitHub check
  annotations state that account payments failed or the Actions spending limit
  needs increasing. This is a GitHub billing/execution block, not a test
  failure. Run 38508782336 for the Laravel installer commit `db0aa0e` was
  queued at last check; inspect its outcome before claiming CI success.
  Local Laravel CLI/package-discovery smoke checks succeeded, but no local
  PostgreSQL/PHPUnit runtime exists.

- Update: Laravel installer run 38508782336 (`db0aa0e`) also failed before
  starting any job with the same GitHub billing/spending-limit annotation.
  Its red status is infrastructure-only; no CI result for this installer.

## 2026-10-14 pdo_pgsql installation attempt — BLOCKED, not installed

Owner requested local `pdo_pgsql`. Confirmed the existing PHP 8.4.21 binary
has only PDO SQLite, no `pdo_pgsql` or `pgsql`; its configure command is
static musl with no PostgreSQL extensions. No PHPize/libpq headers; apt host
is inaccessible and GitHub release downloads redirect to inaccessible assets.
Do not copy a foreign .so or change DB_CONNECTION to SQLite. Existing
Laravel vendor works for CLI metadata but DB routes remain blocked. Full PHP
8.4 with pgsql/XML extensions (Laragon on Windows, or a trusted Linux build)
is required; `docs/LOCAL-LARAVEL-EN.md` records verification commands.
GitHub Actions is currently billing-blocked, so it cannot build a replacement.

## 2026-10-14 PMS-approved class picker

Manual line form now uses `PmsLineEligibility::eligibleClassIds` (same join as
snapshot resolver) to list only published classes in current A-approved PMS
revisions. Class selection is shown even when not a line-number token; if no
class qualifies it shows a bilingual explanation and disables the form
submit. Added HTTP regression for draft omission and expanded snapshot test
for eligibility before approval, after approval and after supersession.
**Not a service/DB write gate:** direct HTTP POST, service, import and SQL
remain permissive; strict line creation is next. Local PHP 8.4 syntax check
passed for changed PHP files, but no pdo_pgsql local and GitHub Actions is
currently billing-blocked; PostgreSQL feature assertions not yet executed.

- CI run 38515815314 on `1e38780` is red **without starting a single job**:
  GitHub Actions annotated account billing/spending-limit failure across the
  jobs. This is not a test result for the picker changes. PostgreSQL feature
  tests await restored CI or a complete local PHP/PostgreSQL runtime.

## 2026-10-14 visibility and CI recheck

Owner changed GitHub repository visibility to public. Verified using GitHub
repository API: `private=false`, `visibility=public` for
`iman-taheri59/epcc-platform`. The earlier runs remain pre-start failures;
`gh run rerun 38515847134` was refused ("workflow file may be broken").
This documentation push requests a fresh Actions run on standard
`ubuntu-24.04` runners, which GitHub documents as free for public repos.
Do not infer a green test outcome until that new run completes.

- Fresh public-repo run 38518232416 on `aa0369f` **started all six jobs**:
  five jobs succeeded. The Laravel/PostgreSQL suite collected 3249 tests,
  reported zero assertion failures and one annotated PDF export rendering
  timeout after 30 s (`PdfExportTest::test_rendering_produces_a_real_pdf`;
  JUnit nested totals show three errors). This is no longer the billing block;
  it does NOT establish a green full suite. No PMS picker failure appears in
  the check annotations, but that is not proof every picker assertion ran.
  Avoid changing production PDF limits just to hide a slow CI runner.

- Follow-up public-repo run 38520710949 on `f4b392b` **passed all six jobs**,
  including Laravel/PostgreSQL/RLS. The prior PDF timeout did not recur. This
  finally verifies the PMS picker slice against the full CI suite; the strict
  line admission service/DB write gate is still outstanding. Repository API
  again confirms `visibility=public`.

## 2026-10-14 external-number PMS admission

`PipingLineService::register` now calls `PmsLineEligibility::snapshotId`
within its write transaction and persists the exact snapshot on imported or
manually supplied-number lines. No class / draft / wrong-project /
superseded-revision class fails before insert; a valid but nonconforming tag
keeps its literal number only when an approved class was explicitly selected.
PipingLineTest's synthetic PMS fixture creates a real CDE doc/revision and
class snapshot; HTTP direct POST missing class refusal and supersession pin
tests added. `PipingLineService::create` and DB null-pin insertion remain open
for legacy fixtures; not the complete class-before-line rule. PHP 8.4 syntax
checks passed; CI pending.

- CI run 38525864378 on `78be477`: five jobs passed; Laravel suite red
  (3255 tests, zero assertion failures, two annotated errors counted three
  times by nested JUnit): the contractor-owned snapshot test tried to create
  owner-owned numbering config and was correctly refused by RLS; an old HTTP
  test still expected a classless external number to be admitted. Corrected
  the fixture to create config in the owner scope and updated the legacy
  expectation to explicit refusal. CI recheck pending; do not claim green.

- CI run 38528034166 on `2e21d16` **passed all six jobs**, including
  Laravel/PostgreSQL/RLS. Supplied-number/import registrations now reject a
  classless or unapproved line and pin an eligible approved PMS class snapshot
  when one is explicitly supplied; old imported tags remain verbatim. This
  verifies the import path only. Allocated-number `create` and DB null-pin
  inserts remain permissive, so the full owner requirement is not done.

## 2026-10-14 automatic line numbering PMS gate

`PipingLineService::create` now shares the approved PMS snapshot resolver with
`register` and writes a pinned snapshot ID on each new allocated-number line.
A missing/draft class fails before insert even if the numbering pattern omits
its class token. Updated PipingLine, PipingConfig, HTTP, Joint and Component
fixtures to create a real approved CDE PMS revision via a tests-only helper;
added rejection tests and pin assertions. Synthetic fixture intentionally
bypasses engineering publish completeness only inside tests; production
writer still uses published class + approved PMS snapshot. Direct SQL/new
unclassified insert remains possible because DB nullable column preserves
historical fixtures. PHP lint succeeded; PostgreSQL CI pending.

- CI run 38533755067 for `3c0cbe2`: five jobs green; Laravel suite red
  (3255 tests, zero assertion failures; annotated UnitPreferenceTest fixture
  errors, with two extra unannotated errors in the JUnit artifact). The unit
  preference fixture was still creating a draft A1 class, so the new service
  correctly refused those lines. It now uses the shared tests-only approved
  PMS fixture before creating lines. Recheck CI before claiming this slice.

- CI run 38536908956 for `1c60554`: five jobs green; Laravel reported
  3261 tests with three nested JUnit failures arising from one HTTP
  UnitPreferenceTest assertion. Its separate bad-unit form fixture still
  used a draft class; the new PMS gate correctly returned a class error
  before unit validation. Updated that fixture to an approved PMS class so
  the test exercises the intended unit validation. CI recheck pending.

- CI run 38540006442 on `7d30df6` **passed all six jobs**, including the
  Laravel/PostgreSQL/RLS suite after updating all known class fixtures.
  Allocated-number and supplied-number service paths now both require and
  persist the current approved PMS class snapshot. Remaining work: audit
  direct SQL/bulk writers and enforce non-null admission at the DB boundary
  while preserving legitimately historical unmapped rows without inventing
  classifications. Existing PR is still open; do not claim full gate yet.

## 2026-10-14 new-line DB backstop

New migration `2026_10_14_100000_require_approved_pms_pin_on_new_lines.php`
adds an INSERT-only trigger refusing new piping lines without BOTH class ID
and PMS snapshot ID. The existing trigger validates the exact current
approved document/class snapshot. A database NOT NULL would break historical
unmapped rows; the insert-only gate leaves them in place without assigning
invented classes, while all new direct SQL/bulk/service entries fail closed.
PipingLineTest now asserts SQLSTATE 23514 for class-without-pin raw insertion,
23505 for real duplicate number with valid pin, and pre-migration legacy row
survival after installing the gate. PHP lint passed; PostgreSQL CI pending.
PMS author write gates and historic-readiness reporting remain outstanding.

- CI run 38543947981 on `7bf732d` **passed all six jobs**, including
  Laravel/PostgreSQL/RLS and the new migration/legacy-preservation tests.
  New direct SQL and bulk inserts can no longer omit the approved PMS class
  pin. Old unmapped rows remain unchanged; no synthetic PMS was assigned.
  PMS author-write enforcement and visibility/reporting of unresolved
  historical records remain separate follow-up work.

## 2026-10-14 historical line classification backstop

Migration `2026_10_14_110000_require_pms_pin_when_classifying_historical_lines.php`
blocks SQL updates which change a historical null-pin line's class to a
non-null class without also assigning its approved PMS snapshot. Existing
rows remain editable for unrelated fields. PipingLineTest exercises both
rejection of bare class assignment and acceptance of an explicit joint
class+approved snapshot mapping after the previous insert-gate migration.
PHP lint and diff checks passed; CI pending. Reporting historical unresolved
rows and PMS authoring/lifecycle protection are still separate follow-ups.

- **CI blocked after repository became private:** run 38551878338 on
  `efd7b48` did not start test jobs. GitHub says "The job was not started
  because recent account payments have failed or your spending limit needs
  to be increased." This is a GitHub Actions billing/limit gate, not a test
  result. PHP lint and `git diff --check` passed locally; no PostgreSQL
  runtime or phpunit installation is present locally. The historical class
  amendment migration must be rerun once the owner's Actions billing/limits
  permit private-repository jobs. Do not claim the new slice is CI-green.

## Historical PMS review visibility / AFC service gate

The register now counts/labels null-pin historical lines as awaiting class
and PMS revision review; the workspace marks them blocked and removes them
from its ready count. `PipingLineService::confirmAfc` refuses null class or
snapshot with localized fa/en feedback, without requiring an old pinned
revision to remain the current document revision. The historical migration
fixture now asserts register/workspace labels and AFC refusal. PHP lint and
`git diff --check` pass. No PostgreSQL run yet: private-repository Actions
billing is still blocked; do not claim database/HTTP test success. A direct
SQL transition to AFC is not yet protected by this service-level change.
The owner explicitly plans to make the repository public again **after
several more steps** for database tests; do not change its visibility now.

## Database transition guard for unmapped historical lines

Migration `2026_10_14_120000_require_pms_pin_for_new_afc_transitions.php`
rejects direct SQL changes into AFC_CONFIRMED or RELEASED when either class or
PMS pin is null. It leaves unchanged issued historical rows untouched and
allows reversal to DRAFT. Regression adds an SQL AFC transition with complete
actor/timestamp to the historical-row migration test and expects SQLSTATE
23514; PHP lint and diff checks passed. Database tests deferred per owner's
plan to keep the repository private for several more steps. Full evidence
validation on a direct SQL AFC transition is **not** provided by this trigger.

## Published PMS class specification freeze

Migration `2026_10_14_130000_freeze_published_pms_class_specifications.php`
prevents SQL modifications/deletion of published class headers and all
insert/update/delete operations on their rule and branch-rule rows. Rules
acquire a share lock on their parent during state inspection. Both test
fixtures now add rules while the class is DRAFT, then publish before PMS
approval. PmsClassDocumentTest now expects 23514 on attempted SQL header
edit, rule edit/delete and branch insertion, rather than treating mutable
live rules as a normal way to prove snapshot immutability. PHP lint and diff
checks pass; PostgreSQL CI deferred until the owner restores public
visibility or provides private Actions billing. Do not claim tests pass.
A future requirement to revise a published class's contents needs an
explicit versioned authoring design; current service already treats
published classes as read-only.

## Same-identity PMS revision groundwork (owner accepted proposal)

`2026_10_14_140000_create_pms_class_revision_drafts.php` creates an isolated
per-revision/class JSONB working-copy table with project/company FKs, RLS,
unique pair, immutable identity and WIP-only write trigger. `DocumentRegister`
seeds new WIP revision drafts from the previous issued snapshots atomically
on `issueRevision`. The PmsClassDocumentTest regression checks copy/edit in
WIP, old snapshot unchanged, and rejection of edits after SHARED. PHP lint
and diff checks passed. These drafts are **not** yet used to publish PMS or
validate specification rules; no changed-content revision is usable for
line admission. Next steps: validated author workflow and issue-time capture
from the drafts, including range/material/branch checks, before claiming
same-identity class revision support. Postgres tests are deferred until the
owner returns the repo to public or enables private GitHub Actions billing.

## Narrow WIP PMS draft authoring service

`PmsRevisionDraftService::changePipeSchedule` lets a freshly nominated
PMS author change the schedule of one existing PIPE_SCHEDULE rule in the
current WIP revision's draft only. It serializes with nomination/suspension,
checks active nomination, archive state, ownership and CDE WIP status and
locks document/revision/draft. PmsClassDocumentTest now checks non-nominated
owner refusal, accepted author change, immutable prior snapshot, author
refusal after SHARED and database trigger rejection after SHARED. PHP lint
and diff checks passed. No HTTP editor yet; edited drafts **do not** become
approved snapshots and cannot authorize new lines. PostgreSQL CI deferred
while private Actions remains blocked by billing. Next: schema/engineering
validation and issue-time capture from drafts, then an authorized UI.

## Whitelisted PMS draft delta

`PmsRevisionDraftValidator` permits only an existing PIPE_SCHEDULE rule's
schedule value to differ from its prior approved snapshot. Strict structural
comparison rejects changed class/header, DN range, material or branch rules,
removed/added values and type substitutions. The nominated-author WIP edit
service validates the entire draft against the actual previous approved
snapshot before writing; tests cover pure deltas and an SQL-tampered DN
range before a service edit. PHP syntax checks and diff check passed. No
PostgreSQL CI while private Actions billing is blocked per owner's plan.
**Do not** treat this as a database-wide draft gate or publication support:
raw SQL WIP edits still bypass this service validation; approval capture
still ignores draft content. Next protect review/publication transaction.

## PMS WIP-to-SHARED working-copy review gate

`PmsRevisionDraftReview` checks that the next PMS revision's draft class set
exactly equals the preceding approved snapshot set and every draft passes
the schedule-only full-delta validator before `DocumentRegister::transition`
moves WIP to SHARED. The check runs under the locked revision in the same
transaction. PmsClassDocumentTest now forges a branch rule after a legitimate
schedule edit, expects a `specification` error and WIP rollback, then
restores the draft and shares successfully. PHP lint and diff checks pass.
PostgreSQL CI still deferred by the owner's private-repository plan.
**Remaining:** direct SQL CDE transitions are not protected by this
service check; snapshot capture still ignores drafts. Do not claim revised
schedules can authorize new lines.

## Engineering review of schedule-only PMS revision drafts

The WIP-to-SHARED gate now checks each proposed schedule against every DN in
its range using PipeReference's published wall-thickness table. It reruns the
existing B31.3 §304.3.3 pad gate using per-rule draft schedule overrides,
without editing the frozen published class/rules. A regression proposes SCH
40 over `[15,600)` and expects a DN550 rejection (NPS22 lacks SCH 40), then
uses STD, which the reference pack lists for that band. PHP lint and diff
checks passed; PostgreSQL CI remains deferred under private Actions billing.
No new PMS snapshot captures the edited schedule yet. Do not treat a
SHARED draft as approved or use it to authorize line registration.

## Fail-closed publication of revised PMS drafts

`DocumentRegister` now revalidates every draft and the engineering schedule
checks before an A-family PMS approval, then refuses any changed working
copy until the snapshot-capture path is capable of issuing that reviewed
copy. A valid SHARED STD revision cannot silently publish the old live class
rules as though they were the reviewed specification. PmsClassDocumentTest
asserts the refusal, rollback to SHARED and unchanged snapshot count. PHP
syntax and diff checks passed, PostgreSQL test execution deferred per owner.
Next: database provenance guard plus immutable capture of validated revision
copies; only then remove the temporary changed-draft publication block.

## Revision-specific PMS snapshot capture (PostgreSQL test pending)

Migration `2026_10_14_150000_capture_validated_pms_revision_drafts.php` adds
PostgreSQL full-JSONB schedule-only delta comparison and replaces the
snapshot trigger so an approved current PMS revision can capture precisely
its matching WIP draft, sourced from the immediately preceding approved
snapshot. No draft still means exact live-spec capture on first issue.
`PmsRevisionSnapshotService` now inserts reviewed draft specification and
checks complete class membership; `PmsRevisionDraftReview` repeats structural
and engineering validation immediately before approval. Regression issues a
STD revision after SCH 80, checks the old lines stay pinned to A and new
line pins B, and expects 23514 on a forged DN-range snapshot. PHP lint and
diff checks passed. **No PostgreSQL tests yet** while repository private
Actions billing is blocked. Raw SQL mutation of CDE state/drafts could
bypass engineering (reference-pack/pad) service checks: separately audit
DB-only approval/author boundaries before calling this a universal gate.

## Issue-time line PMS rule resolution

`PmsPinnedClassSpecification` now retrieves a line's immutable snapshot by
its pin, project and class and resolves exactly one PIPE_SCHEDULE for a DN.
It rejects null/unmapped historical lines, missing or structurally bad
snapshots and ambiguous/missing DN bands; it never falls back to the live
class. Regression in PmsClassDocumentTest contrasts an A-pinned line (SCH
80) with B-pinned line (STD) while the live published class still reads SCH
80. PHP lint and diff checks passed, PostgreSQL CI deferred while private.
Before any downstream line-based MTO, branch or engineering calculation is
built, route its class-rule reads through the pin. No current production
caller uses `PipingClassService::ruleFor` for a line; do not claim universal
revision-aware calculations yet. DB-only CDE approval/author integrity still
needs a separate boundary audit.

## 2026-10-14 repository public; CI recheck blocked

`gh repo view` reports `isPrivate=false`. The most recent Actions run
38583348269 on `17c77af` still has zero started steps and a GitHub billing
annotation (recent account payments failed or spending limit needs increase).
An attempted `gh run rerun` was refused; `gh workflow run CI --ref
arena/782120e4-epcc-platform` returned HTTP 403 (`Resource not accessible
by integration`). A harmless retry commit `d2b143a` was pushed after
visibility changed, but as of this check GitHub Actions has not produced a
run for that SHA and PR #7 still reports the previous head. Do not claim
Laravel/PostgreSQL/RLS CI passed. Owner must check GitHub Billing & plans,
Actions allowance and PR/workflow permissions; then retry latest-head CI.

As a partial local fallback, PostgreSQL 16.2 from the `pgserver` PyPI wheel
was started on port 55432. The actual SQL function definitions from migration
`2026_10_14_150000_capture_validated_pms_revision_drafts.php` were loaded
successfully; `epcc_pms_schedule_only_delta` returned true for a schedule
change and false for DN-range, material, branch and whitespace mutations.
This is **not** the full Laravel migration/RLS/engineering suite. The local
PHP build lacks `pdo_pgsql`, so those tests still require CI or Laragon.

## Commit-time direct SQL PMS approval completeness gate

`2026_10_14_160000_require_pms_snapshots_on_approved_revision.php` adds a
DEFERRABLE INITIALLY DEFERRED row constraint trigger to document_revisions.
For a current approved A-family PIPING/PMS revision it requires >=1 published
class, no draft governed classes, and exactly one approved immutable snapshot
per class at commit. This permits the existing service sequence (revision
UPDATE then snapshot INSERTs in one TX) but rejects bare SQL approval.
PmsClassDocumentTest now tests rejection with `SET CONSTRAINTS ... IMMEDIATE`
inside a savepoint before normal service publication. PHP lint and diff
checks passed. Local PostgreSQL 16.2 smoke test with a minimal schema parsed
the real trigger and verified success with snapshot and expected failure
`PMS_ISSUE_NEEDS_CLASS_SNAPSHOTS` without it. **Full Laravel/PostgreSQL/RLS
CI is still NOT run**: Actions billing/permissions block persists even though
repo is public. Forging both snapshots and document state using raw SQL could
still evade the service-only reference-pack/pad check. Do not call this a
universal engineering authorization gate.

- **Actions resumed after public visibility:** run 38585934338 on `24c6676`
  executed all jobs; five non-Laravel jobs passed, Laravel failed (3276 tests,
  3 failures and 6 errors). Annotated causes include a PostgreSQL transaction
  left aborted after an expected class-rule trigger refusal in
  `PmsClassDocumentTest` (SQLSTATE 25P02 instead of 23514 on the next
  assertion) and pure PHPUnit validator tests raising `ValidationException`
  without a booted Laravel facade. Expected failing SQL writes in the PMS
  feature test now use nested transactions/savepoints; the validator test
  extends the Laravel test base. The artifact download returned EOF, so
  remaining unannotated failures still need a fresh run/log. Run
  38590891134 for `a5f45b1` was in progress when checked and predates this
  fixture correction. Retest full PostgreSQL/RLS after push; no green claim.

- **Real PostgreSQL/RLS verification resumed:** run 38591064891 for
  `283c4ee` completed the Laravel suite **successfully** after fixing nested
  PostgreSQL test savepoints and booting the Laravel unit test harness. Image,
  PCF, standards and HTML jobs also succeeded. Overall workflow remains
  **red solely because the Compose stack job did not start**: GitHub check
  annotation says recent account payments failed or the spending limit must
  increase. `gh run rerun 38591064891 --failed` was refused ("workflow file
  may be broken"). This is a billing/scheduling failure, NOT a Compose
  test failure. Owner must resolve GitHub billing/Actions limits, then
  re-run the missed Compose job. Do not claim all six jobs green.

## Skip B-suitability revisions when selecting PMS class baseline

`PmsApprovedRevisionBaseline` selects the latest earlier A-family issued
snapshot set, not necessarily the immediately preceding document revision.
`DocumentRegister::issueRevision`, PMS draft review and nominated-author
schedule editing share it. Migration
`2026_10_14_170000_use_latest_approved_pms_revision_baseline.php` updates
the existing PostgreSQL snapshot trigger's prior-issue comparison while
preserving its strict JSONB schedule-only delta and current approved source
checks. PmsClassDocumentTest covers A80 -> A_STD -> B1(no snapshot) -> A_STD,
including the old line's unchanged issue-time pin. PHP lint and diff checks
passed; CI pending. The previous 283c4ee Laravel/PostgreSQL/RLS run was
successful, but this slice has NOT yet been verified against PostgreSQL.
Compose job remains subject to GitHub account billing/scheduling limits.

- CI run 38639634136 on `3fc043f` did **not start any test job**:
  GitHub annotated Laravel and the other jobs with failed account payments
  or spending-limit restrictions; Compose was skipped. The new B-coded
  baseline migration/regression is therefore PHP-linted but **not** yet
  PostgreSQL-verified. Run 38591064891 on `283c4ee` remains the last
  successful Laravel/PostgreSQL/RLS suite. Owner must resolve GitHub Actions
  billing/limits before treating this new slice as validated.

## Issue-time generic + branch PMS rule resolution

`PmsPinnedClassSpecification` now resolves arbitrary one-dimensional rule
values and branch cells from a line's frozen snapshot (rather than the live
class). Branch precedence is specificity, priority, creation time, with
explicit refusal of ambiguous/missing/reversed or malformed input. P2P kind
and pad data are preserved in the returned issued cell. Added pure unit
coverage for overlap/tie behaviour and a feature assertion for the
revision-B schedule via generic rule lookup. PHP lint and diff checks passed;
full CI pending given intermittent account billing failures. Raw-SQL CDE
writers remain a separate security/engineering audit item.

- CI 38640300534 for `9a000e3` did not start any test job: GitHub's Laravel
  check says recent account payments failed or the Actions spending limit
  needs increase. The pinned-branch resolver and B-baseline regression remain
  PHP-linted but unverified by current PostgreSQL CI. Do not interpret this
  scheduling failure as a test failure or a pass.

## Piping screens now show the issued PMS revision

`PmsClassRevisionSnapshot` is a read-only Eloquent model for immutable
issue-time class content; `PipingLine::pmsSnapshot()` and eager-loaded
revision/document relationships drive the piping register and task-first
workspace. Each mapped line shows its issued PMS document number and
revision, not the document's latest revision. Null-pin historical lines
continue to show the review warning. `PipingLineHttpTest` now asserts the
English register and workspace show a newly created line's synthetic PMS
number and A revision. PHP lint and diff checks passed; real PostgreSQL/RLS
HTTP verification pending. No direct SQL/CDE writer authorization claim.

- CI 38646018638 for `b7ac3eb` did not start its Laravel or other test
  jobs: GitHub annotated the run with account payment/spending-limit
  restrictions. The issued-revision UI regression is PHP-linted but not
  PostgreSQL/HTTP-verified in this run. Last successful Laravel/PostgreSQL/RLS
  check remains 38591064891 on older commit `283c4ee`.

## Offline Laragon PostgreSQL/RLS verification path

`scripts/verify-laragon-pms.php` is a new safe local verifier while GitHub
Actions is billing-blocked. Default mode is READ-ONLY: checks PHP >=8.4.1,
PDO/pgsql and other required extensions, Composer dev dependencies,
`app/phpunit.xml` epcc_test target, the real database connection, PostgreSQL
>=16, btree_gist and the connected role's non-superuser/NOBYPASSRLS status.
It refuses conflicting exported DB variables; it never prints credentials.
Explicit `--run` clears cached configuration and invokes the PMS feature
regression then all `php artisan test`; warns that the dedicated epcc_test
schema will be dropped/recreated, and that skipped PDF tests/Compose are not
validated by this runner. `docs/LARAGON-DEVELOPMENT-ENVIRONMENT.md` contains
commands. PHP lint passed; the sandbox PHP correctly fails preflight at its
missing `pdo_pgsql`, so success on Laragon is NOT claimed here. Owner can
send sanitized test output without sharing .env/passwords. This verifier is
not a replacement for the absent GitHub Compose job.

- CI 38647897238 on `2b03acd` did not start the Laravel or other test jobs:
  GitHub again reported account payment/spending-limit restrictions. The
  Laragon preflight is PHP-linted and intentionally fails on the sandbox's
  missing `pdo_pgsql`; it has not passed on a real Laragon/PgSQL workstation.

## User-supplied Linux PHP archive inspection (2026-10-15)

The uploaded `PHP-8.4-Linux-x86_64-PM5.tar.txt` is a 13,801,690-byte gzip
TAR (SHA-256 `5b9a1a8f103f7b91670336495b531d9a75c05cca3bd544251a7b63d2124bcc6c`).
Archive metadata was inspected without executing its binary or adding it to
Git. Its bundled `php-config` lists `--with-pdo-sqlite` and
`--with-pdo-mysql`, but **neither** `--with-pdo-pgsql` nor `--with-pgsql`.
The only packaged PHP extension modules are xdebug and opcache; no
`pdo_pgsql.so`, `pgsql.so` or libpq.so appears in the archive. It is a ZTS
PHP build with `--disable-session`, unlike the existing NTS CLI, so copying
extensions across builds would also be unsafe. This archive cannot run the
Laravel/PostgreSQL/RLS tests as-is. Keep it outside the repository. A
compatible Linux PHP 8.4 build with pgsql/PDO_PGSQL and session support, or
the owner's properly configured Laragon PHP, remains necessary.

## PHP/PostgreSQL sandbox feasibility check (2026-10-15)

Investigated building a Linux PHP 8.4 CLI with `pdo_pgsql` after the user's
request. The official static-php-cli source (GitHub) DOES support pdo_pgsql,
pgsql and session; however its release binary URL redirects to a host this
sandbox cannot reach (HEAD failed TLS EOF), and the sandbox lacks autoconf,
pkg-config and development headers for a from-source PHP build. The existing
NativePHP statically linked NTS CLI cannot load a ZTS extension from the
uploaded PM5 archive. The `pgserver` PyPI wheel IS reachable and was
installed to ignored `.cache/pgve`: PostgreSQL 16.2 including `libpq.so` and
`libpq-fe.h` is available, but that alone cannot add pdo_pgsql to PHP. No
Laravel/PostgreSQL tests have run in this sandbox. Next viable route is a
trusted ready-made Linux x86_64 PHP 8.4 CLI with pgsql, pdo_pgsql, session,
intl, zip, gd and XML, or tests on owner's Laragon; only then start isolated
PG 16 / epcc_test and run the preflight and suite. Do not describe this
investigation as passing DB tests.

## Piping incremental step: pinned schedule rule contract (2026-10-15)

`PmsPinnedClassSpecification::ruleValueFromSpecification()` now resolves
issue-time typed rule values without querying mutable live class rows, and
fails closed on invalid DN, malformed, missing or overlapping rules. The
line-bound `ruleValue()` delegates to it. Unit assertions added in
`PmsPinnedBranchResolutionTest`. Both PHP files passed lint and `git diff
--check` passed; the sandbox still has no `pdo_pgsql` or Composer vendor, so
this is NOT a passing PHPUnit/DB test result. Next: wire MTO/component
consumers to pinned specifications and run Laragon/PostgreSQL tests.
Historical cross-company classification workflow is still undecided; the
piping_lines RLS policy's WITH CHECK requires row.company_id == tenant,
so a project-owner actor cannot write another company's line by default.
Do not silently broaden this authorization.

## Incremental component pin consumption (2026-10-15)

`ComponentService::place()` now fills a missing PIPE schedule using
`PmsPinnedClassSpecification::pipeSchedule($line, $size->dn)` for pinned lines;
ports inherit the selected schedule. Explicit component schedule inputs and
unpinned legacy modelling behaviour are unchanged. The PMS revision feature
test now asserts an old line gets SCH 80 and a new line gets STD after an
approved schedule-only revision, even though live class remains SCH 80.
PHP lint and diff whitespace checks passed, not PHPUnit/PG (unavailable here).
Remaining: decide policy for explicit schedule override; manual MTO has no
universal line link, so do not impose a fake pin on all MTO rows.

## Piping model visibility step (2026-10-15)

Component modelling now eager-loads the line's pinned PMS document revision,
displays its issue-time document number/revision or a legacy-unmapped warning,
and shows each component's stored schedule in the model table (including
manual overrides; this is visibility, NOT engineering approval). HTTP
assertions added to ComponentModellingTest. PHP lint and diff check passed;
the DB-backed HTTP test has not run locally due missing pdo_pgsql/Composer.
Do not treat the displayed schedule as confirmation that an explicit override
matches the issued PMS rule.

## Read-only issued schedule comparison (2026-10-15)

On the model page each sized PIPE component with a pinned PMS line is compared
against its **issued** snapshot, using in-memory eager-loaded JSON (no live
class lookup or per-component DB queries). The screen shows a match, an
explicit difference plus expected schedule, or "cannot be checked" for a
missing/invalid DN or snapshot rule; it NEVER labels unknown as matching.
`pipeScheduleFromSpecification()` shares the production resolver logic with
`pipeSchedule()`; unit and HTTP regression assertions added. This is a
visual warning, not a rejection/authorization or full material conformity
check. PHP lint and diff check passed; DB-backed HTTP tests await Laragon or a
PostgreSQL-capable PHP runtime. Do not infer that overrides are approved.

## Schedule-exception owner decision / first stage (2026-10-15)

Owner explicitly chose an exception with reason, approver and traceable
history rather than an unconditional rejection of mismatched PIPE schedules.
ADR-029 records the staged contract. Migration `2026_10_15_100000` introduces
append-only request/decision evidence, one decision per request, immutable
reason and decision, actor separation, same-company/project/pin integrity,
RLS and project archive write protection. Test assertions were added for
immutable reason and blocked self-approval. **No request/review UI or
approval service exists yet; do not count any mismatch as approved.** The
next step is a transaction-safe service that derives expected schedule from
the pinned snapshot and authorizes the reviewer. Cross-company sign-off
requires a separate owner decision; existing RLS only writes own-company rows.
PHP lint and whitespace checks passed; DB tests still unavailable locally.

## Owner correction: global discrepancy triage (2026-10-15)

Owner clarified that **any** discrepancy can be accepted with documented,
fulfilled conditions of an applicable project standard or project
specification/procedure; alternatively issue a TQ for resolution; otherwise
issue NCR. Recorded in English ADR-030 and ADR-029 scope correction. Crucial
safety interpretation proposed (awaiting governance decisions): issuing a TQ
or NCR is not itself acceptance; TQ answer and NCR disposition need controlled
review/closure, and an incomplete or unsupported citation is not acceptance.
ADR-029's prior request/decision tables are only an unexposed audit skeleton:
no reference/clause, conditions, TQ/NCR link, reviewer workflow or downstream
holds exist. Do not treat an APPROVED row as effective approval. Pending owner
answers: authority across companies, TQ answer vs disposition, affected hold
gates, contractual reference precedence. No application code changed in this
step; PostgreSQL tests remain pending due local pdo_pgsql absence/Actions
billing block.

## Signature when responsible party has no paid login (2026-10-15)

Owner answered that the responsible line company MUST sign; depending on the
commercial package only employer/consultant/management contractor may have
system access. Owner also confirmed TQ answer needs a separate final
acceptance/disposition. ADR-030 now distinguishes contractual responsibility
from `piping_lines.company_id` (RLS recording tenant), human signatory,
uploader and independent verifier. Proposed routes: restricted external
signer, or project-permitted offline signed document with independently
verified authority, provenance/hash and scope. Without a verified signature
or formal contractual delegation, keep ON HOLD; do not impersonate an absent
contractor or silently waive a sign-off due to plan tier. ADR-029's same-
company decision table is insufficient and must not drive release. Questions
remain on whether offline signatures are contractually valid, guest-signing
commercial policy, project-specific authority matrix and blocked gates.
Documentation step only; no signature feature exists yet, no DB tests ran.

## Offline signature answer / first evidence slice (2026-10-15)

Owner confirmed offline signed documents may constitute a valid signature.
Migration `2026_10_15_110000` adds append-only, project/RLS-scoped candidate
metadata for schedule-exception external signature and independent verification
(signer organization/person/capacity vs licensed uploader, document number/
revision/SHA-256/date, verifier/decision/authority basis). PostgreSQL guards
reject uploader self-verification and mismatched request/project/tenant;
feature assertions added but have NOT run on PostgreSQL. The metadata is NOT
file-bound, the signer's contractual line responsibility and verifier's
project authority are NOT checked by an application service, and no approval
or gate is enabled. Never claim the rows alone are valid signatures. ADR-030,
ADR-029 and improvement proposals describe remaining steps.

## Two TQ/NCR provenance modes clarified (2026-10-15)

Owner requires BOTH full in-system creation/signing/issuance and registration
of already-issued/signed external TQ/NCR reports with **information only**.
Uploading a signed file is optional, not mandatory. ADR-031 records the two
modes, signatory/recorder/verifier distinction and current missing TQ/NCR
workflow. Corrected ADR-030 and improvement proposals to supersede the old
"must be file-bound" suggestion. New migration `2026_10_15_120000` allows
schedule-specific external-signature candidate metadata with NULL file hash
and revision (document number, signer, date remain required); feature test
adds a metadata-only row. SQL guard against self-verification remains. No
TQ/NCR register or in-system signature/issuance exists yet, no approval gate
uses these candidate rows. PHP lint/whitespace checked; PostgreSQL test still
pending. The existing `uploaded_by` column is a legacy name for metadata
recorder when no file exists and should be renamed in a future schema step.

## TQ/NCR two-mode register slice (2026-10-15)

New migration `2026_10_15_130000` adds a schedule-discrepancy-linked,
project/RLS-scoped, append-only TQ/NCR register. DB CHECK distinguishes
IN_SYSTEM/DRAFT (no purported signature or issue number) from
EXTERNAL_REGISTER/EXTERNAL_RECORDED (reported number, issuer, signer/capacity,
issue and sign dates, external register reference; no file or revision
required). The latter means information captured, NOT verified or approved.
A feature test inserts both modes and checks incomplete/forged shapes fail.
No HTTP workflow, internal TQ/NCR issuance or external verification exists yet;
no approval or release gate consumes these rows. PostgreSQL tests have not
run due missing local pdo_pgsql and billing-blocked CI. See ADR-031.

## Schedule TQ/NCR provenance capture service (2026-10-15)

`PipeScheduleReportService` now records only IN_SYSTEM/DRAFT or
EXTERNAL_REGISTER/EXTERNAL_RECORDED TQ/NCR rows. It validates project/PIPING
membership + `project.view`, the same-company schedule request, archive
status, and mandatory external metadata, then writes inside tenant context.
No caller can provide a state or issue/sign via this service. A feature test
checks both paths and rejects missing external register reference; PHP lint
and diff check passed but PostgreSQL tests remain unrun. No HTTP UI/routes,
issuer authorization, TQ response, NCR disposition or approval gate exist.
The `project.view` permission is an interim capture guard and must be
replaced with distinct report-capture capability before public exposure.

## Dedicated report-capture capability (2026-10-15)

`PipeScheduleReportService` no longer authorizes writes with `project.view`.
The authorization pipeline maps `engineering.*` to core; seeded demo roles
explicitly grant `engineering.report.capture` for capture only. Tests assert
PIPING scope denies the CIVIL-only engineer and a role reduced to
`project.view` cannot create a report. No report issue/signature/verification
capability is granted; no public HTTP routes exist yet. PHP lint and diff
check passed; PostgreSQL feature tests still unrun.

## Pipe-schedule discrepancy request service (2026-10-15)

New `PipeScheduleExceptionRequestService::submit()` runs under tenant/RLS and
`engineering.report.capture`, locks the pipe and its line, recomputes expected
schedule from the issue-time PMS pin at the actual pipe DN, and stores reason,
requester and actual value. It rejects matching/missing/unpinned pipes and
an identical unresolved request. Added feature assertions for matching,
new request provenance, and duplicate refusal. No public route or decision
service; a request alone never approves work. PHP lint/diff checks pass; DB
feature tests remain unrun. Before approval, a reviewer must recheck
component/snapshot freshness and project-specific authority (ADR-029/030).

## Model-screen discrepancy request entry (2026-10-15)

ComponentController/model view now expose a POST-only, CSRF-protected
`request-review` route and reason form for an own-company PIPE with a visible
issued-PMS schedule difference. Controller checks project/line/component URL
binding; `PipeScheduleExceptionRequestService` rechecks all source values,
RLS, ownership, permission, reason and pending duplicate. Model view queries
pending requests in one batched query and says "Review requested; not
approved" instead of implying clearance. Capture remains allowed on released
lines (late-discovered discrepancy) but blocked on archived projects. HTTP
feature assertions added; PHP lint and diff check passed, PostgreSQL tests
still not run. No TQ/NCR issue, signature or acceptance UI is present.

- Follow-up hardening: the pending-request badge is now keyed by the
  component's **current** schedule as well as its pinned PMS revision. A
  still-open request for an old component schedule cannot suppress a new
  review form after an edit; HTTP test covers 40 -> 60. Old request remains
  historical evidence and must fail reviewer freshness checks (not built).

## Owner question: pipe thicker than required (2026-10-15)

Analysed current behavior: model page flags schedule string mismatch only;
`PipeReference::wall` can resolve size-specific nominal wall, but no end-to-
end minimum-wall acceptance for schedule substitutions is connected. Greater
thickness can satisfy pressure thickness (subject to design P/T, material,
corrosion/mechanical allowances and 12.5% mill tolerance) yet still violate
an exact PMS schedule or introduce bore/fit-up, weld qualification, branch,
support and hydraulic issues. ADR-029 and improvement proposals recommend
separate PMS difference and engineering wall-adequacy statuses; PASS is not
approval under ADR-030. Asked owner whether the PMS schedule is an exact
mandatory value or a minimum wall. No code or DB tests in this analysis step.

## Owner clarification on thicker wall (2026-10-15)

Owner says ASME B31.3 permits thicker pipe/component via an internal 1:3
taper (grinding). ADR-029 records this as a conditional **joint transition**
route, not automatic schedule approval. For measured internal radial offset
Δ, provisional geometric reading is axial length >=3Δ, subject to the
project-adopted code edition/figure, WPS and engineering design. Must check
remaining minimum wall after machining, end fit-up, inspection, material,
branch/weight etc; line-owner signature and independent disposition still
apply. Source review found inconsistent secondary summaries of B31.3 328.4.3
versus other ASME code figures; do not hard-code 1:3 or cite a definitive
paragraph until owner provides adopted edition/figure (or authoritative pack
text is verified). No code changed and no test run for this clarification.

## Fit-up inspection boundary corrected (2026-10-15)

Owner clarified: remaining wall after internal grinding, taper geometry,
connection alignment and WPS are to be checked later at **Fit-up inspection**
by the parties specified in the project's ITP. Detailed stage requirements
will be discussed when development reaches Fit-up. ADR-029/030 and improvement
proposal corrected: current PMS discrepancy/request may record a proposed
taper and conditional engineering path without as-built fit-up evidence; it
must NOT show Fit-up accepted or use a future fit-up report as a prerequisite
for opening the discrepancy. Engineering disposition, responsible line-company
signature and ITP inspection/release remain distinct. No code or DB tests
changed in this clarification step.

## Proposed taper intent on schedule request (2026-10-15)

Migration `2026_10_15_140000` adds append-only `proposed_remedy` default
UNDETERMINED / INTERNAL_TAPER_PROPOSED to existing schedule requests.
`PipeScheduleExceptionRequestService` only accepts the taper proposal when
BOTH size-specific schedules exist and the proposed actual reference nominal
wall is greater than the issued PMS wall, never by comparing schedule labels.
Controller/view offer that option only for an eligible mismatch and label
pending intent "plan only; not Fit-up acceptance". Feature test covers
thinner refusal, thicker proposal and no decision event. Geometry, remaining
wall after grinding, WPS and ITP verification explicitly deferred (ADR-029/
030); no automatic approval/release. PHP lint/diff checked, DB tests unrun.

## Schedule discrepancy history visibility (2026-10-15)

The model screen now batches own-company request history and linked TQ/NCR
register rows for all visible components on a line. A collapsed history shows
captured schedules, reason/time, proposed taper intent, stale former values,
and report provenance: internal draft **not issued** vs external metadata
**not verified**. An ADR-029 raw decision is labelled only as a review event,
not engineering acceptance. Tests assert history survives a 40 -> 60 schedule
edit and both TQ draft/NCR external report labels. No release/approval gate is
connected. PHP lint and diff check passed; PostgreSQL HTTP tests still unrun.

## Report capture freshness split (2026-10-15)

`PipeScheduleReportService` now locks pipe/line and rechecks actual schedule,
issued PMS snapshot and recalculated expected schedule for a newly created
IN_SYSTEM TQ/NCR draft. It refuses stale component state and raw-SQL forged
expected values. EXTERNAL_REGISTER still permits retrospective metadata for
an already issued/signed report on an old request, but no verification or
approval results. Feature assertions cover forged expected value and 40->60
edit: internal draft rejected, historical external registration remains
EXTERNAL_RECORDED. PHP lint/diff checked, PostgreSQL tests still unrun.

## Model-page TQ/NCR capture (2026-10-15)

ComponentController now routes scoped POSTs for own-company schedule requests:
create an in-system unissued TQ/NCR draft (only current request), or register
already-issued external TQ/NCR metadata without file/revision. Both use the
existing `PipeScheduleReportService` after verifying request -> component ->
line URL binding, CSRF, capture capability and tenant scope. Internal draft
creation serializes on request row and refuses a duplicate of same kind.
Read-only history explicitly calls internal rows "not issued" and external
rows "not verified"; no signature/issue/approval/disposition route exists.
HTTP assertions cover both forms, cross-line refusal, duplicate draft and
stale internal draft refusal. PHP lint/diff checked; PostgreSQL tests unrun.

## Issue-time component size on schedule requests (2026-10-15)

Migration `2026_10_15_150000` adds nullable NPS/DN pair to append-only
schedule requests: null means legacy size unknown, NEVER backfilled from a
mutable component. Request service captures canonical NPS/DN and dedupes
per actual schedule **and size**. Model history shows the issued request
size; pending status also matches current size, and size-unknown/changed
entries are marked former/unverifiable. Internal TQ/NCR draft refuses a
request without size or whose NPS/DN no longer matches the current pipe.
Feature test changes NPS 6/DN150 to NPS 8/DN200 at unchanged schedule,
asserts new request can be made and old draft rejected. No Fit-up validation
or engineering acceptance is inferred. PHP lint/diff checks passed;
PostgreSQL tests still unrun.

## External report readback (2026-10-15)

The model's report history now has a collapsed details panel for each
external TQ/NCR: number/revision, claimed issuer/signatory/capacity, claimed
issue/signature dates, external register reference, and separate local
recorder ID/time. Everything remains visibly *unverified*, and Blade escapes
external free text. Feature HTTP assertions check readback. No verification,
issuance, disposition, signature or Fit-up acceptance is added.

## External metadata validation fix (2026-10-15)

`PipeScheduleReportService` trims claimed report fields before validating;
blank required text is a ValidationException and blank optional revision is
null. Service and HTTP tests cover whitespace-only fields, with no reliance
on a DB CHECK failure for user input. Lint/diff passed; PostgreSQL suite
remains unrun locally due to missing vendor/pdo_pgsql.

## Capture acknowledgement (2026-10-15)

The model shows a bilingual, mode-specific flash receipt following successful
TQ/NCR capture: internal draft not issued/approved, or external metadata not
verified. Validation failures do not receive a success receipt. The model
announces status/errors with appropriate accessibility roles; HTTP assertions
cover both receipts. No report issuance, acceptance or signature workflow.

## Pending request expected PMS hardening (2026-10-15)

A historical request whose claimed expected schedule differs from the
current DN's issue-time pinned PMS no longer suppresses a fresh request.
Model history warns of an unverified PMS claim and hides the internal draft
form; report service remains the final server-side freshness check. A DB
feature test inserts a false expected schedule by raw SQL and asserts a
legitimate request can follow. PHP lint/diff checked; PostgreSQL tests unrun.

## Verified degraded-environment run (2026-10-15)

Installed local ignored npm/jsdom and Python jsonschema environments and ran
`PATH="$PWD/.local/php-native/bin:$PATH" bash scripts/run-tests.sh` successfully:
standards-pack validation, PHP rules conformance/material screening (including
60 screening assertions), and five jsdom prototype suites (render: 324
render combinations; sidebar: 19; piping workspace: 16; MTO: 15; order gap:
19). **One suite skipped:** Laravel/PHPUnit/PostgreSQL RLS because `app/vendor`
and `pdo_pgsql` are absent. These green results do NOT validate the recent
schedule-request/report services, migrations, routes, or database RLS. The
zero-dependency Node prototype server was started on `0.0.0.0:8080` as a
live preview. It serves prototype screens, **not** the Laravel model page;
run the latter with Laragon PHP 8.4 + PostgreSQL on a suitable workstation
following `docs/LARAGON-DEVELOPMENT-ENVIRONMENT.md`. Do not claim DB tests
passed based on the prototype preview.


## 2026-10-18 — Executable baseline restoration and targeted defect repair

- Installed official Debian PHP 8.4.26 + required extensions, Composer, PostgreSQL 17 and PDF tools; dependency installation and initial migration/seed passed. Role epcc is not superuser and cannot bypass RLS. Historical statements that PHP acquisition is impossible do not apply to this environment. Recreation guide and FA companion added.
- Work remains on local `arena/baseline-verification-2026-10-18`; no commit, push or PR made.
- Reproduced repeated fresh failure independently after discarding overlapping test runs. Three schedule trigger functions now use CREATE OR REPLACE with unchanged bodies. New rebuild regression verifies two fresh runs and five forced-RLS tables/guard triggers.
- Fixed PmsClassRevisionSnapshot's integer-default key metadata: nonincrementing string UUID; existing HTTP test now reaches rendering instead of SQL uuid=integer/HTTP 500. Added key regression and replaced one obsolete exact-HTML assertion with a PIPE-row-specific DOM value/status check. Positive validator test now has explicit assertions.
- Final targeted PHP run: 56 tests, 271 assertions, zero errors/failures/skips. Conformance/screening/standards/prototypes and frontend build passed separately. No complete full-suite pass is claimed; next step is serial full suite with SESSION_URL_FALLBACK=false and failure triage. Do not run root run-tests.sh concurrently because it also launches Laravel tests.
- Real Laravel server at 0.0.0.0:8000; synthetic EPC browser login and portfolio/documents/piping-workspace/order-gap in FA/EN returned 200 (eight checks), no page-level JS exceptions. Mobile FA documents at 430px has scrollWidth=430. This is smoke evidence only, not full workflow acceptance. Ignored preview .env enables host-gated URL session fallback; customer deployment must disable it. Tests can purge demo attachment files; restore a disposable demo only after test runs if needed.
- Current implementation ledger supersedes conflicting old status prose without changing ADR decisions. Full raw evidence under /home/user/epcc-evidence; compact successful evidence under docs/evidence/2026-10-18.
- Better alternatives recorded: separate current evidence from history (BUILT), PostgreSQL-safe trigger recreation (BUILT), UUID metadata fix (BUILT), app npm lockfile (OPEN), tenant-context exception masking (OPEN). No new business workflow, MTO permission or engineering approval rule was added.


## 2026-10-18 — Complete serial PHPUnit run and sole failure repaired

- Session-start recovery found incomplete vendor, absent local branch and missing uncommitted prior fixes/regression. Recreated the branch, reinstalled locked dependencies behind app/vendor -> ../.cache/vendor, reapplied documented trigger-function/UUID metadata/DOM assertion fixes and rebuild regression, restored Git-recorded executable bits. No remote operations or dependency version edits. Source-only recovery bundle under /home/user/epcc-recovery; not a database backup.
- Full configured Unit+Feature suite completed serially with SESSION_URL_FALLBACK=false: **1083 tests / 16380 assertions / 1 failure / 0 errors / 0 skipped**, approx. 24m40s. No overlapping DB runner. All 1082 other cases passed.
- Only failure: PdfExportTest::test_an_issued_certificate_does_not_rewrite_its_own_evidence. 34mm summary label wrapped the English category-A caption and interleaved its count in pdftotext. Added punch-summary class on MCC summary table plus scoped 48mm/nowrap label CSS. Existing failing test unchanged; snapshot/lifecycle/authorization not modified.
- Post-repair PdfExportTest + CertificateScreenTest: **29 tests / 108 assertions / 0 failures/errors/skips**; frozen-count and live-draft assertions execute successfully. Synthetic EN/FA Chromium print probe confirms single-line label; English crop visually checked. Full final-source rerun remains the next gate; do not merge counts into a fictitious single green full run.
- Independent packs/conformance/screening/five prototype suites passed. Composer validate/platform checks passed. PHP lint:359 files passed. Browser smoke:8 actual FA/EN app routes returned200, no page exceptions; FA mobile documents scrollWidth430 at viewport430. These are bounded checks, not product/production certification.
- Full verification EN/FA report and compact raw JUnit/logs added under docs/evidence/2026-10-18-full. Implementation ledger/current notices updated. No commit/push/PR or new business requirements.
- Better alternatives recorded: targeted print-summary sizing (BUILT), generated vendor cache layout and portable source-only recovery bundle (BUILT); final-source full CI rerun still required. Existing open app npm-lockfile and security-critical TenantContext exception-observability proposals remain open.


## 2026-10-18 — Final-source gate closed; piping pilot matrix prepared

- Recreated ignored runtime packages/dependencies/assets after restoration. All443 source/test/template/reference hashes matched the previous repaired-source manifest; executable modes restored where Git records100755. No application, migration, template or test-source content changed in this session.
- Ran the entire configured Unit+Feature suite serially with DB_PORT=5433 and SESSION_URL_FALLBACK=false: **1083 tests /16385 assertions /0 failures /0 errors /0 skipped; exit0;17m59s**. The original MCC immutable-evidence PDF test passes in the complete run. This is a real final-source green local result, not combined partial-run counts. No GitHub Actions/production/Docker/backup-recovery success is claimed.
- Isolated PG17.11 test cluster at /tmp/epcc-final-pg on tmpfs, loopback5433, SCRAM TCP, local admin socket. App role epcc has no superuser/BYPASSRLS/CREATEDB. fsync/synchronous_commit/full_page_writes stayed ON; WAL bounds128/32MB to fit the ephemeral cluster. This is functional verification, not crash durability. Demo environment remains on5432. No concurrent DB suite; independent commands used instead of root runner, which would invoke another full Laravel run.
- Standards/reference packs, PHP conformance/screening, five prototype suites, Composer validation/platform requirements, frontend build and359 PHP lints passed. Reinitialized the separate synthetic demo only after tests purged seeded blobs;8 companies/3 projects. Actual Laravel8000 browser smoke:8 FA/EN authenticated pages200, no page exceptions; FA mobile documents430px has no whole-page overflow.
- Added FINAL-SOURCE-VERIFICATION EN/FA and compact JUnit/log/manifests under docs/evidence/2026-10-18-final. Prior reports remain historical with current-result pointers.
- Added21-case PIPING-PILOT-ACCEPTANCE-MATRIX EN/FA: synthetic values and exact source/test links, not an executed E2E pilot. Identified G01(all accepted MTO revisions/scope aggregation, already ADR-024), G02(RECEIVED disappears from order coverage), G03(receipt does not populate PO-item FK), G04(legacy item-code/site rollup), G05(mixed-unit/all-item receipt progress), G06(usable policy deferred), G07(PO/inspection/receipt human entry surfaces not found). G02–G07 are source-reviewed findings, not new runtime reproductions or direct release-bypass claims.
- ADR-032 EN/FA is PROPOSED only; no new permission/schema/receipt gate/signature policy approved or implemented. Preserve advisory inspection, deferred MTO permissions and paused ITP/Fit-up scope. First recommended development slice is deterministic append-only effective MTO selection/additivity design/regression under existing ADR-024 principles.
- Better alternatives recorded: isolated disposable test cluster with integrity settings ON(BUILT); readiness matrix separating component green from operational gaps(BUILT as planning); G01 selection remains OPEN implementation; received-order/physical-attribution proposals remain unapproved. Source-only final recovery bundle outside clone verified against clean baseline, excludes secrets/dependencies/database. No commit/push/PR.
