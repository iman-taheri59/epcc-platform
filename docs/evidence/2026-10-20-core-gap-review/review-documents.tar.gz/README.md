> **Current review / user deferral — 2026-10-20:** [core gaps and priorities](docs/CORE-GAP-REVIEW-2026-10-20-EN.md) / [فارسی](docs/CORE-GAP-REVIEW-2026-10-20-FA.md). Structured prerequisite item design AND implementation explicitly deferred; free text retained. Source/document review, not a test run or new authority/schema approval. Recommended next: focused document allocation review, then warehouse provenance/arithmetic diagnostics; next user-visible target is exact-line PO receipt after needed decisions. Conflicting older status/“current full source green” statements below are historical evidence, not this review’s current verification.

> **Approved PDF continuation — 2026-10-20:** [current prerequisite appendix](docs/INSPECTION-PREREQUISITE-PDF-EN.md) / [فارسی](docs/INSPECTION-PREREQUISITE-PDF-FA.md). Selected prerequisite_pdf implemented: all records/full history/retained stage, separate from issuance snapshot; same scope, no new schema/authority/writes.409 on changes during render.20/1102 + separate4/60 PASS; not full-suite/current-CI/deployed. Only prerequisite-PDF deferral and contradictory historical prose below are superseded; other decisions retained.

> **Current delivery — 2026-10-20:** [original-notice status filter for prerequisites](docs/INSPECTION-PREREQUISITE-ACTIVE-NOTICE-FILTER-EN.md) / [فارسی](docs/INSPECTION-PREREQUISITE-ACTIVE-NOTICE-FILTER-FA.md). User-selected active_notice_filter: All default, not-cancelled/cancelled, independent of prerequisite state; no writes/authority/schema/PDF. Company-picker/count scope retained;36/2008 PASS. Seven prior source hashes matched, no recovery needed; vendor remains excluded-cache symlink. Not full-suite/current-CI/browser/deployed/committed/pushed; private DB stopped after checks.

> **Current delivery — 2026-10-20:** [readable prerequisite company picker](docs/INSPECTION-PREREQUISITE-COMPANY-PICKER-EN.md) / [فارسی](docs/INSPECTION-PREREQUISITE-COMPANY-PICKER-FA.md). User-selected company_picker: captured name/code from visible declaring companies only, literal search/25-option pages, pinned selection/independent pages. No new directory/access/schema/write/PDF.56/1793 PASS; not full-suite/current-CI/browser/deployed/committed/pushed.16 prior sources restored from checked archive with differences preserved; new bundle in evidence; private DB stopped after checks.

> **Current delivery — 2026-10-20:** [project prerequisite tracking](docs/INSPECTION-PREREQUISITE-REGISTER-EN.md) / [فارسی](docs/INSPECTION-PREREQUISITE-REGISTER-FA.md). Selected tracking_register: status/declaring-company identity/literal notice filters,25-row pages and visible-only counts, cancelled-original label; no new writes/authority/schema/PDF. Missing inherited-stage workspace source restored/verified; recovery report/source archive in evidence. Final47/1051 + separate legacy1/12 PASS; earlier runs overlap. Not full-suite/current-CI/browser/deployed/committed/pushed; private DB stopped after checks.

> **Current delivery — 2026-10-20:** [exact inherited ITP context for prerequisites](docs/INSPECTION-PREREQUISITE-ITP-LINK-REVIEW-EN.md) / [فارسی](docs/INSPECTION-PREREQUISITE-ITP-LINK-REVIEW-FA.md). User-selected inherited_stage implemented: retained notice snapshot only in create/current/history context; no live sources, new schema/access/backfill, structured sub-items or PDF changes.54/807 + separate legacy1/12 PASS; not full-suite/browser/current-CI/deployed/committed/pushed. Private DB stopped after checks.

> **Current delivery — 2026-10-20:** [recipient prerequisites](docs/INSPECTION-NOTIFICATION-PREREQUISITES-EN.md) / [فارسی](docs/INSPECTION-NOTIFICATION-PREREQUISITES-FA.md), [ADR-045](docs/ADR-045-INSPECTION-NOTIFICATION-PREREQUISITES-EN.md). Explicit any_reader_company_scope / report_and_recipient_confirm / all_notice_readers implemented. Multiple item-text requirements, reasoned edits/withdrawals, sender live-issuer reports, recipient confirmation/rejection and immutable history. No automatic gate, technical acceptance or source/stock authority; original/PDF unchanged.81/1290 + separate upgrade1/5 PASS; not full-suite/current-CI/deployed/committed/pushed; private DB stopped after checks. Earlier current notices below are historical.

> **Current delivery — 2026-10-20:** [company acknowledgment](docs/INSPECTION-NOTIFICATION-ACKNOWLEDGMENT-EN.md) / [فارسی](docs/INSPECTION-NOTIFICATION-ACKNOWLEDGMENT-FA.md), [ADR-044](docs/ADR-044-INSPECTION-NOTIFICATION-ACKNOWLEDGMENT-EN.md). Explicit any_authorized_company_reader / issue_and_cancellation_separate / all_authorized_notice_readers / detail_and_current_pdf implemented. First immutable company/event receipt, no late original receipt after cancel; scoped company/person/time and current PDF with409 on receipt changes during render. No automatic read tracker, transport/signature/approval or doc/MTO/MR/PO/stock authority. Final61/1040 + separate upgrade1/5 PASS; overlapping final PDF1/22 PASS. Not full-suite/current CI/deployed/committed/pushed; private DB stopped.

> **Current delivery — 2026-10-20:** [independent issued cancellation](docs/INSPECTION-NOTIFICATION-CANCELLATION-EN.md) / [فارسی](docs/INSPECTION-NOTIFICATION-CANCELLATION-FA.md), [ADR-043](docs/ADR-043-INSPECTION-NOTIFICATION-CANCELLATION-EN.md). Explicit current_issue_grant/cancel_only/status_reason_scoped_replacement implemented: separate append-only event, immutable original number/version/body/snapshot, effective CANCELLED, scoped reason/actor/time without private-history disclosure. Current PDF banner/status and409 on cancellation during render. Final59/884 + separate upgrade1/5 PASS; overlapping PDF1/22 PASS. Only cancellation deferral superseded; replacement/undo/acknowledgment deferred. Not90-case/full-suite/production/current-CI certification; no commit/push/deploy. Private DB stopped.

> **Latest continuation — 2026-10-20:** [optional filter time UI](docs/INSPECTION-NOTIFICATION-FILTER-TIME-UI-EN.md) / [فارسی](docs/INSPECTION-NOTIFICATION-FILTER-TIME-UI-FA.md), user-selected `filter_usability` delivered.26 tests/404 assertions and7 Chromium groups/147 checks PASS (separate/nonadditive). Partial helper blocks submit; fully empty omits bound; no assumed offset/new authority/schema. Current synthetic rendered Chromium fixtures, not production/live-auth/full suite; private DB stopped.

> **Current delivery — 2026-10-20:** [notification register filters](docs/INSPECTION-NOTIFICATION-REGISTER-FILTERS-EN.md) / [فارسی](docs/INSPECTION-NOTIFICATION-REGISTER-FILTERS-FA.md). User-selected `register_filters`: literal number/current-reference search, state, inclusive offset-aware overlap, authorized counts/pages and language/context preservation. No inferred legacy window, history search, new authority/schema/endpoint/write. **58 tests /640 assertions PASS, zero skipped**, not full suite/production/current CI/performance certification. Earlier counts historical; ADR-042/MTO/private-history boundaries retained.

> **Current delivery — 2026-10-20:** [notification draft edit history](docs/INSPECTION-NOTIFICATION-DRAFT-HISTORY-EN.md) / [فارسی](docs/INSPECTION-NOTIFICATION-DRAFT-HISTORY-FA.md). User-selected `draft_history`: atomic DB before/after/version + captured editor name/UUID/time/settings, append-only/FORCE RLS, originating-company readers only, no recipient/PDF history.25-row pages, no-op saves retained, no pre-install backfill. Migration120000; **87 tests /1139 assertions PASS, zero skipped**, not full suite/production/current CI. Earlier totals historical; authority/ADR-042/MTO boundaries retained, issued cancellation/rescheduling deferred.

> **Current delivery — 2026-10-20:** [notification date/time UI](docs/INSPECTION-NOTIFICATION-TIME-UI-EN.md) / [فارسی](docs/INSPECTION-NOTIFICATION-TIME-UI-FA.md). User-selected `date_time_ui`: native date/time + explicit offset, visible exact/direct/no-JS entry and readable display; no inferred timezone/API/schema/authority change. Related53/740 and final4/81 subset PASS; separate18 browser scenarios/149 checks PASS, nonadditive. Not full suite/production/current CI/E2E/all-browser acceptance. History and replace_time/ADR-042/MTO boundaries retained.

> **Current delivery — 2026-10-20:** [notification activity window](docs/INSPECTION-NOTIFICATION-ACTIVITY-WINDOW-EN.md) / [فارسی](docs/INSPECTION-NOTIFICATION-ACTIVITY-WINDOW-FA.md). User-selected `replace_time`: required planned start/end replace single time, preserve offsets and compare instants; EN/FA forms/register/detail/PDF. Legacy issued times explicitly labelled, no backfill; legacy drafts must explicitly convert before issue. Migration110000; **71 tests /802 assertions PASS, zero skipped**, not full suite/production/current CI; earlier counts/single-time contract are historical. Same authority/ADR-042/MTO boundaries; no issued rescheduling.

> **Current delivery — 2026-10-20:** [bounded notification draft editing](docs/INSPECTION-NOTIFICATION-DRAFT-EDIT-EN.md) / [فارسی](docs/INSPECTION-NOTIFICATION-DRAFT-EDIT-FA.md). User-approved `draft_only`; same current draft grant/company, optimistic version, fixed source/creation evidence; latest-edit metadata, not full draft history. Issued/PDF immutability retained; issued cancellation/rescheduling deferred. **58 tests /631 assertions PASS, zero skipped**; not full suite/production/current CI. Earlier create-only limits/counts are historical; ADR-042/MTO boundaries unchanged.

> **Current delivery — 2026-10-20:** [issued-notification PDF](docs/INSPECTION-NOTIFICATION-WORKFLOW-EN.md) / [فارسی](docs/INSPECTION-NOTIFICATION-WORKFLOW-FA.md): actual EN/FA output from immutable history, same readers and post-render visibility recheck; no record mutation/signature/transport/source-read delegation. Project metadata captured only on new issues; no legacy backfill. **42/501 + separate21/85 PASS =63 tests /586 assertions across two commands, no skips**, not full suite/production/current CI. Earlier PDF deferrals and46/250 counts are historical; five ADR-042 choices and MTO boundary retained.

> **Current delivery — 2026-10-19:** [operational ITP notifications](docs/INSPECTION-NOTIFICATION-WORKFLOW-EN.md) / [فارسی](docs/INSPECTION-NOTIFICATION-WORKFLOW-FA.md). Explicit main contractor, authorized-admin draft/issue permission assignment, document-revision stages, drafts, atomic issue/immutable snapshot and purpose-limited recipient inbox are implemented. **Two final commands:46 tests /250 assertions PASS**, not full regression. Notice is not inspection result/signature/external delivery/usable stock. Earlier contract-only status below is historical; five ADR-042 choices and ADR-041/MTO boundaries retained. No production/current-CI claim.

> **New requirement/status — 2026-10-19:** [ADR-042: ITP inspection notifications](docs/ADR-042-ITP-INSPECTION-NOTIFICATIONS-EN.md). Five owner choices retained: all stages, separately delegated contractor permission, explicit authorized project recipients, document-revision/stage host, main contractor only. **Input contract only:7 unit tests/24 assertions PASS; no operational draft/issue UI/service yet.** Notification is not ADR-041 inspection result; earlier evidence does not certify this feature.

> **Current delivery — 2026-10-19:** [independent inspection entry](docs/INSPECTION-ENTRY-EN.md) / [فارسی](docs/INSPECTION-ENTRY-FA.md), [ADR-041](docs/ADR-041-INDEPENDENT-INSPECTION-ENTRY-EN.md). **46 affected tests /558 assertions PASS**,14 new cases. Owner versioned nominations/suspension, create-only original-visible PO form, server attribution and immutable new evidence. Existing TPI/PMC/MC/OWN independence, non-PASS findings and IRN numbering retained; no default/inherited writer, PO read delegation, source/lot/financial/receipt/usable/MTO mutation. Migration190000 privately verified only; no full-suite/production claim. Older current notices/counts below are historical and nonadditive.

> **Current delivery — 2026-10-19:** [independent inspection pagination](docs/INSPECTION-REGISTER-PAGINATION-EN.md) / [فارسی](docs/INSPECTION-REGISTER-PAGINATION-FA.md). **40 affected tests /556 assertions PASS**, four new cases. Inspection25-row pages, independent three-way navigation/true totals, explicit project + unchanged participant-visible quality RLS, unused PO eager load removed; advisory receipt semantics unchanged. Supersedes the earlier inspection-pagination deferral only. No new role/schema/endpoint/write or full-suite/production claim; older evidence/notices below are historical.

> **Current delivery — 2026-10-19:** [exact money + independent register pagination](docs/REGISTER-PAGINATION-MONEY-EN.md) / [فارسی](docs/REGISTER-PAGINATION-MONEY-FA.md). **41 affected tests /499 assertions PASS**, eight new cases. Exact stored decimal money/null≠zero; independent25-row MR/PO pages, filtered totals/late count, stable ordering and preserved filters/original caller RLS. This closes the two earlier recommended increments, not indexed/load-certified search or inspection pagination. No new endpoint/schema/role/action or full-suite/production claim. Prior evidence retained; older current/follow-up notices below are historical.

> **Current feature — 2026-10-19:** [independent MR/PO register search + states](docs/PROCUREMENT-REGISTER-FILTERS-EN.md) / [فارسی](docs/PROCUREMENT-REGISTER-FILTERS-FA.md). **33 affected tests /310 assertions PASS**, eight new cases. Bound literal header search, category/state intersection, unchanged original caller RLS, scoped counts and inspections unchanged. No new role/schema/endpoint/action or full-suite/production claim. Server pagination/indexing and preexisting register float/integer money formatting remain explicit follow-up recommendations. Prior evidence retained; older current notices below are historical.

> **Current correction — 2026-10-19:** [safe pricing-form recovery](docs/PO-PRICING-FORM-RECOVERY-EN.md) / [فارسی](docs/PO-PRICING-FORM-RECOVERY-FA.md). **42 affected tests /465 assertions PASS**, nine new cases. Recover input only for the same current PO hash and complete active UUID set; blank≠zero, stale/malformed input not rebased, original write/grant/source checks unchanged. No new role/schema/endpoint or full-suite/production claim. Prior evidence preserved; older current notices below are historical.

> **Current read-only feature — 2026-10-19:** [structured retained pricing comparison](docs/PO-PRICE-HISTORY-COMPARISON-EN.md) / [فارسی](docs/PO-PRICE-HISTORY-COMPARISON-FA.md). **33 affected tests / 359 assertions PASS**, eight new cases. Exact text money, UUID-matched before/after prices/currency/totals, unknown≠zero, raw snapshots retained and latest20 only. Existing buyer/project RLS unchanged; no new writer/role/schema/approval or full-suite/production claim. Prior evidence unchanged; older current/next notices below are historical.

> **Current workflow addition — 2026-10-19:** [PO draft directly from MR details](docs/MR-TO-PO-CONTEXT-ACTION-EN.md) / [فارسی](docs/MR-TO-PO-CONTEXT-ACTION-FA.md). **43 affected tests / 340 assertions PASS**, five new cases. Eligible own-buyer/current independently nominated authors reuse the existing full-copy POST; live source/grant/archive rechecks, safe validation return, no source consumption/reservation/issue. GET stays nonmutating; the optional action deliberately creates a DRAFT PO. No new endpoint/role/schema or full-suite/production claim. Prior evidence unchanged; older current/next notices below are historical.

> **Current feature — 2026-10-19:** [read-only MR detail sheet](docs/MATERIAL-REQUISITION-DETAILS-EN.md) / [فارسی](docs/MATERIAL-REQUISITION-DETAILS-FA.md). **30 affected tests / 240 assertions PASS**, ten new cases. Exact stored source lines/original quantity spelling, recorded approval/rejection metadata and bounded visible related POs, under original caller RLS/current membership/discipline/plan. No journal delegation, mixed-unit sum, official remaining quantity, new role/schema/write gate. Prior evidence unchanged; no full-suite/production claim. Evidence: `docs/evidence/2026-10-19-mr-details/summary.json`. Older current/next notices below are historical.

> **Current targeted verification — 2026-10-19:** [PO rollback / nomination-suspension contention](docs/PO-ROLLBACK-REVOCATION-EN.md) / [فارسی](docs/PO-ROLLBACK-REVOCATION-FA.md). **38 affected tests / 328 assertions PASS**, including four new two-connection schedules (issue rollback, suspension commit/rollback, issue-before-suspension). Runtime code unchanged; no authority/workflow/schema changes. These are bounded timeout-and-fresh-retry schedules, not comprehensive crash/revocation certification. Prior evidence remains unchanged; totals are not cumulative. Older current/next notices below are historical.

> **Current boundary repair — 2026-10-19:** [human OrderGap source protection](docs/ORDER-GAP-HUMAN-BOUNDARY-EN.md) / [فارسی](docs/ORDER-GAP-HUMAN-BOUNDARY-FA.md). Confirmed HTTP quantity-amendment escape for controlled MR copies closed; human attribution/amendment now use fresh locked source markers and protected forms are hidden. Trusted/legacy lineage and accepted complete pricing retained. **77 affected tests / 764 assertions PASS**, six new cases. No new roles/MTO policy/schema migration or full-suite/production claim. Evidence: `docs/evidence/2026-10-19-order-gap-human-boundary/summary.json`. Legacy/manual authority redesign remains deferred. Older current/next notices below are historical.

> **Current security correction — 2026-10-19:** [PO issued-guard RLS isolation](docs/PO-GUARD-ISOLATION-EN.md) / [فارسی](docs/PO-GUARD-ISOLATION-FA.md). Confirmed hidden-journal line-mutation bypass repaired with a trigger-only, visible-parent-capped integrity lookup; caller settings restored and ordinary journal RLS unchanged. **71 affected tests / 658 assertions PASS**, six new cases including archived populated upgrade. Forward-only function migration180000; no historical row rewrite/new roles/MTO rights/production application/full-suite claim. Evidence: `docs/evidence/2026-10-19-po-guard-isolation/summary.json`. Older current/next notices below are historical.

> **Current increment — 2026-10-19:** [OrderGap mutation lock alignment](docs/ORDER-GAP-LOCKING-EN.md) / [فارسی](docs/ORDER-GAP-LOCKING-FA.md). **65 affected tests / 552 assertions PASS**, six new cases, including two real issue-versus-amend connection schedules. Project advisory → project → PO → item locks; fresh-state/lineage rechecks; legacy rules retained and controlled issued-content freeze unchanged. No new roles/MTO authority/reconciliation writer or full-suite/production claim. Evidence: `docs/evidence/2026-10-19-order-gap-locking/summary.json`. Next recommendations are design/review, not enabled post-issue amendment or capacity release. Older current/next notices below are historical.

> **Current increment — 2026-10-19:** [read-only MR source commitment review](docs/PO-SOURCE-REVIEW-EN.md) / [بررسی فقط‌خواندنی تعهدات منبع](docs/PO-SOURCE-REVIEW-FA.md). **57 related tests/502 assertions PASS**,12 new cases. Existing caller-RLS/discipline visibility only; no buyer impersonation/new roles/schema/write actions. Visible cancelled/headerless legacy commitments and recorded allocations are distinguished; hidden buyer evidence is UNKNOWN, not missing/zero; quantities retain historical units and no official remaining balance is inferred. ADR-036/038/039 authority/atomic issuance retained; prior108/746 evidence unchanged. No full/recovery/production claim. Next: lock-order alignment and controlled resolution/post-issue design; write-based legacy resolution/release remains NOT implemented. Older current/next statements below are historical.

# EPCC Suite — Project Workspace

Bilingual (EN/FA) modular platform for large industrial EPCC projects — oil, gas, petrochemical, power.

> **Latest feature:** [Purchase order details](docs/PURCHASE-ORDER-DETAILS-EN.md) ([فارسی](docs/PURCHASE-ORDER-DETAILS-FA.md)) — click an order number in Procurement for lines/amendments, delivery dates, lots and inspections. **54 targeted tests/227 assertions PASS**. Full suite is not rerun/scheduled per change under the latest user instruction; previous1169/17146 is historical pre-feature proof. No new role/schema/write authority.

> **Faster delivery cadence:** bundle useful feature work, run affected tests, keep essential docs short; full suite/recovery packaging only when justified by milestones/risk/release, not every continuation.


## Contents

> **Market decision: Iran-first.** On-premise/air-gapped deployment, Persian-default UI, Jalali calendar and IRR billing are constraints, not options. See `docs/Iran-First-Market-Addendum.md` — it supersedes conflicting statements elsewhere.

| Path | What it is |
|---|---|
| `HANDOFF.md` | **START HERE.** Living handoff — what works today, the architecture rules you must not break, the preview-iframe traps, testing discipline, next steps, and a session log. Updated every session. |
| `docs/SRS-EPCC-Platform.md` | Software Requirements Specification (SRS-EPCC-001) — scope, personas, access model, 13 module groups, 18 disciplines, NFRs, licensing, roadmap, risks |
| `docs/Architecture-and-Data-Model.md` | Architecture (ARC-EPCC-001) — module manifest contract, standards engine resolution, 6-gate authorization pipeline, canonical data model, offline sync, RTL architecture, event catalogue, tech selection |
| `app/` | **The Laravel 13 application** — real code. **Authentication + ARC §5 six-gate authorization**, **project setup** (create a project, choose its standards pack, invite companies, staff people), **multi-project** portfolio + per-project workspaces, tenant isolation enforced by PostgreSQL RLS, bilingual FA/EN, real Jalali dates. `php artisan serve` |
| `compose.yaml` + `scripts/dev-*.sh` | **One-command development environment** — PostgreSQL 17 and PHP 8.4 with Composer, Node 22, headless Chromium, poppler and Vazirmatn, all in containers. `scripts/dev-up.sh`, then sign in at <http://localhost:8000>. No PHP, Composer, Node or PostgreSQL needed on the host |
| `scripts/run-tests.sh` | **Degraded-environment test runner** — for sandboxes without Docker/PHP: runs the standards-pack validator (auto-venv) and all five jsdom prototype suites, and reports loudly what it skipped and why. `bash scripts/run-tests.sh` |
| `scripts/sandbox-pg.sh` | **Real PostgreSQL inside a Docker-less sandbox** — provisions PG 16.2 from the `pgserver` wheel with a non-superuser `epcc` role, `epcc`/`epcc_test` databases and a source-compiled `btree_gist`. `bash scripts/sandbox-pg.sh start\|status\|stop`. The PHP tier still requires the Docker image (see `docs/IMPROVEMENT-PROPOSALS-EN.md` P-19). |
| `scripts/preview-server.mjs` | **Zero-dependency live preview server** for the air-gap-safe prototype (no CDN, no build step). `node scripts/preview-server.mjs` → <http://localhost:8080> (`/` main prototype, `/piping-workspace.html`, `/healthz`) |
| `docs/DEVELOPMENT-ENVIRONMENT.md` | **How to run everything locally** — the container stack, what the first boot does, the four `scripts/dev-*.sh` commands, CI, troubleshooting, and the two traps that break the suite silently: exporting a Laravel variable into the container, and letting the application role be a PostgreSQL superuser |
| `docs/LARAGON-DEVELOPMENT-ENVIRONMENT.md` | **Windows / Laragon setup (no Docker)** — PHP 8.4 in Laragon, the non-superuser `epcc` role, the forbidden-SQLite rule, `filament:assets`, demo accounts, and the P-20 note that PDF export needs POSIX tools |
| `packages/standards-engine/` | **Framework-free PHP rule engine** (`epcc/standards-engine`). Zero Laravel dependency by design — ADR-003 Annex A §6. Evaluates pack release gates |
| `packages/standards-engine/conformance/` | **Language-neutral conformance corpus** (25 cases, v1.2.0) + runner + mutation-testing record. The contract that lets the PHP server and the future TS offline app provably agree |
| `docs/Spike-RLS-Results.md` | **P0 spike result** — Eloquent + PostgreSQL RLS. PASS, with five defects found and fixed (empty-GUC cast, audit actor vs subject, non-singleton context, company-only predicate ignoring project participation, nested-scope leak). §8 multi-project, **§9 Octane — CLOSED (0 leaks / 640 requests, 2.8× p50)**, **§10 PgBouncer transaction pooling — CLOSED (safe; a plain `SET` leaks across client connections)** |
| `docs/Infra-Cost-Model-Iran.md` | **Server cost model in تومان** — per-stack RAM footprint, Iranian cloud/dedicated/hardware price anchors (Sep 2026), three sizing scenarios, and what actually reduces the bill |
| `docs/ADR-003-Annex-A-Laravel-Evaluation.md` | **Annex to ADR-003** — Laravel/Filament assessed as the backend. Makes Laravel the primary alternative to TypeScript, overturns the ADR-003 §3.1 argument, and ties the choice to the team's actual language |
| `docs/ADR-003-Technology-Stack.md` | **Decision record** — TypeScript end-to-end (NestJS + React + PostgreSQL 18), why not .NET, the five P0 spikes that must pass, and the reversal conditions |
| `docs/Prototype-Coverage-Map.md` | **Read before demoing** — module-by-module map of what the prototype shows vs what the system specifies, and what is deliberately absent |
| `docs/MTO-REQUIREMENTS-FA.md` / `docs/MTO-REQUIREMENTS-EN.md` | **Piping MTO Foundation requirements** — reconciled from the uploaded 2026-10-06 MTO docs package against the actual current branch. Material Library, MTO document/revision/staging, Slice 4 immutable accepted snapshots, and Slice 5 gross/net comparison are implemented; PO order gap and usable-material decision remain later slices. |
| `docs/ADR-002-Defer-AWP.md` | **Decision record** — AWP methodology deferred to the international phase; the two architectural seams that keep revival at ~6–10 weeks instead of a rewrite |
| `docs/ADR-001-AWP-Packaging.md` | **Decision record** — how AWP is decomposed and licensed: constraint engine in core, AWP methodology as a project-level add-on, model-based scoping with the BIM viewer. Includes the falsifiers that would reverse it. |
| `docs/ADR-015-PO-Attribution-and-Order-Gap.md` | **Requirements record (IMPLEMENTED — awaiting runtime verification)** — MTO Slice 6: PO line material attribution, effective issued/in-force quantities, amendment lineage, explicit no-proration scope allocation, and the order-gap board. All open questions closed 2026-10-11; code + screen + `OrderGapTest` landed the same day (§9). |
| `docs/IMPROVEMENT-PROPOSALS-EN.md` | **Living improvement-proposals register** — standing rule 5: better alternatives for requirements/code/capabilities, each with a status (OPEN / ACCEPTED / REJECTED / BUILT). |
| `docs/Iran-First-Market-Addendum.md` | **Decision record (MKT-EPCC-001)** — dependency substitution table, air-gap requirements, Jalali/Nowruz calendar rules, IPS pack scope, revised commercial model and roadmap |
| `standards-packs/schema/standards-pack.schema.json` | JSON Schema (Draft 2020-12) defining what a standards pack may contain |
| `standards-packs/ips-iran.pack.json` | **IPS / Iran Pack v1.0.0** — IPS standards, شرایط عمومی پیمان (۴۳۱۱), تعدیل, صورت‌وضعیت, تحویل موقت/قطعی, HSE-MS. Launch default. |
| `standards-packs/iso.pack.json` | ISO Framework Pack v1.0.0 — ISO 21502, 19650, 9001, 31000, 45001, 15926/CFIHOS |
| `standards-packs/awp.pack.json` | AWP / WFP Pack v1.0.0 — **deferred to the international phase but kept in CI** as a genericity guard (ADR-002) |
| `standards-packs/validate_packs.py` | CI gate — schema validation, bilingual-parity enforcement, progress-weight checks, and the ADR-002 seam guards |
| `prototype/index.html` | Clickable bilingual prototype — 9 screens, live language / company-role / standards-pack switching, collapsible sidebar with mobile drawer. Links to the newer Piping Workspace preview. |
| `prototype/piping-workspace.html` | **Synthetic-data Piping Workspace preview** — task-first UI concept for the piping-first strategy: summary cards, blocker-first filters, readiness bars, deviation inbox, test-pack board and line detail drawer. Self-contained and air-gap safe. |
| `prototype/test/sidebar.test.js` | jsdom behaviour test — 19 assertions covering the sidebar rail/drawer, RTL, keyboard and navigation behaviour |
| `prototype/test/piping-workspace.test.js` | jsdom behaviour test — 16 assertions pinning Piping Workspace localisation, mobile filter layout, card rows, drawer behaviour and air-gap safety |

## Prototype — scope warning

The prototype is **9 screens covering ~15–20% of the specified system** (12 module groups, ~101 functional areas, 176 requirements). It is a static HTML mock-up: **no database, no backend, no authentication, nothing persists.** It exists to prove four hard architectural ideas — the standards pack engine, bilingual RTL, cross-company permissions, and hard release gates — not to preview the product. Full breakdown in `docs/Prototype-Coverage-Map.md`.

## Prototype — what to try

Open `prototype/index.html`. It boots **Persian-first with the IPS / Iran pack active**, as an Iranian customer would see it. Three switches in the header change everything:

1. **English / فارسی** — full RTL mirroring, not just text direction.
2. **Company** — EPC, Owner, PMC, TPI, MC, Subcontractor. Permissions change live: release buttons, punch-close buttons and payment-certificate actions enable or disable, and the access matrix highlights your column.
3. **Standard** — IPS / Iran, ISO, or AWP. KPIs, terminology, document lifecycle, numbering rule and available modules all change. Under IPS and ISO the AWP screens correctly report the module as inactive.

Key screens for a demo:
- **Piping Workspace preview** — open `prototype/piping-workspace.html` directly, or use the Piping Workspace link in the prototype sidebar. Shows the new task-first UX with synthetic PH-14 data.
- **Order Gap Board preview** — `prototype/order-gap-board.html` (or the sidebar link). The Slice 6 screen language validated before build: accepted gross vs effective ordered per material, shortage / covered / over-plan / unmatched states, draft-PO exclusion, no proration — bilingual FA/EN, 19 jsdom assertions.
- **Laravel Piping Workspace** — after `./restore.sh` and login, open `/projects/PH-14/piping/workspace?lang=en` (or `lang=fa`). It is the first task-first workspace in the real app, derived from project line/evidence/joint/test-pack data; hydrotest packs can now be created and lines assigned there.
- **صورت‌وضعیت / Payment Certificate** — the Iranian payment build-up with تعدیل, حسن انجام کار and advance recovery, plus an authority-limit escalation. IPS pack only.
- **IWP Release Gate** — AWP constraint hard-block in action. AWP pack only.
- **Quality & Punch** — MC certificate blocked by failed guards.
- **Access Matrix** — the commercial confidentiality firewall.

**Sidebar:** the ☰ button collapses the sidebar to a 56px icon rail on desktop, and turns it into an off-canvas drawer below 820px — opening from the right in Persian/RTL and the left in English/LTR. The drawer closes on navigation, on scrim tap, and on Escape.

Tested: 324 render combinations (3 packs × 2 languages × 6 company roles × 9 pages), 19 sidebar jsdom assertions, and 16 Piping Workspace jsdom assertions:

```bash
npm install
npm run test:prototype      # jsdom prototype suites
bash scripts/run-tests.sh   # every suite this machine can run (+ loud skip report)
npm run preview             # live preview of the prototype on :8080
```

## Validating the packs

```bash
pip install jsonschema
python3 standards-packs/validate_packs.py
```

This is the CI gate, not just a schema check. It enforces four things:

1. **Schema validity** of all three packs.
2. **Bilingual parity** — any user-facing string with `en` but no `fa` fails the build.
3. **Progress-weight integrity** — rule-of-credit weights must sum to 100, or progress reporting silently lies.
4. **ADR-002 seam guards** — the deferred AWP pack must stay loadable, `IWP mustBelongTo CWP` must stay expressible as pack data, the launch packs must keep AWP structures disabled, and the IPS pack must keep using the constraint engine.

Point 4 is the mechanism that makes deferring AWP safe. If someone bakes Iran-specific assumptions into the standards engine, the AWP pack stops resolving and the build breaks that day — instead of the problem surfacing three years later when the international release needs it.

Verified: all four erosion scenarios (disabled IWP, stripped constraint engine, English-only label, broken weights) are caught by the gate.



## MTO requirements note — 2026-10-06

The uploaded package `epcc-platform-mto-docs-changes-2026-10-06.txt` was analyzed as a requirements source, not applied as a direct replacement. It contains complete replacement documents from a different baseline and mentions several MTO/PMS/MR capabilities that are **not implemented** in this branch. The reconciled, branch-safe requirements are in `docs/MTO-REQUIREMENTS-FA.md` and `docs/MTO-REQUIREMENTS-EN.md`.

Current implementation status: Material Library foundation is built with a two-level catalogue shape, project overlays, synthetic PH-14 piping catalogue, RLS isolation and tests. MTO document/revision/staging is built as DRAFT-only rows with material validation. Slice 4 creates immutable accepted MTO batches and row snapshots atomically. Slice 5 records provenance-bearing net estimates and reports exact gross/net shortages or deltas without tolerance. Next implementation direction: PO attribution/order gap, and only after a user decision, usable-material gap.

## Decisions — closed and open

**Closed:** Technology stack — **Laravel 13 + Filament v4 + PHP 8.4** (user decision; ADR-003 superseded by its Annex A). Rule engine kept framework-free per Annex A §6, with a conformance corpus so the offline TS app can be proven to agree · Iran-first launch market · AWP split three ways with the methodology as a **project-level** add-on (ADR-001) · AWP methodology **deferred to the international phase**, constraint engine / lookahead / package-based field execution stay in core (ADR-002) · on-premise primary with no foreign cloud dependency · modular monolith · RabbitMQ default with Kafka optional.

**Open, and now blocking P0:**
1. **Pilot clients** — which NOC or affiliate, and which private EPC? Everything sharpens once these are named.
2. **Contract forms beyond شرایط عمومی پیمان** — do target clients use bespoke NOC forms (POGC, PEDEC) needing preload?
3. **Which NOC numbering scheme to build first** — the first one shapes the engine's flexibility.
4. **GPU budget** — determines whether self-hosted AI ships in P4 or slips.
5. **MTO acceptance UI/workflow** — the service-only all-or-nothing accepted snapshot slice is built; decide when the first user-facing workspace should expose it.
6. **Usable-material definition** — decide which warehouse/inspection/reservation states count as usable for the future physical material gap.
7. **On-premise support staffing** — the top margin risk, and a headcount question rather than an engineering one.
