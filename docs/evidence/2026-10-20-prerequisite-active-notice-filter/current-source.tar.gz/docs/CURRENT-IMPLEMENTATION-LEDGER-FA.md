> **تحویل جاری — ۲۰۲۶-۱۰-۲۰:** [فیلتر وضعیت اصل اعلان در پیش‌نیازها](INSPECTION-PREREQUISITE-ACTIVE-NOTICE-FILTER-FA.md) / [English](INSPECTION-PREREQUISITE-ACTIVE-NOTICE-FILTER-EN.md). active_notice_filter مصوب: همه پیش‌فرض، باطل‌نشده/باطل‌شده؛ مستقل از وضعیت شرط و بدون نوشتن/اختیار/schema/PDF. گزینهٔ شرکت و scope تعدادها محفوظ؛۳۶/۲۰۰۸ موفق. هفت hash قبلی برابر، بازیابی لازم نشد؛ vendor در cache مستثنا باقی است. نه full-suite/CI/مرورگر/استقرار/commit/push؛ DB خصوصی پس از بررسی خاموش.

> **تحویل جاری — ۲۰۲۶-۱۰-۲۰:** [انتخابگر خوانای شرکت پیش‌نیاز](INSPECTION-PREREQUISITE-COMPANY-PICKER-FA.md) / [English](INSPECTION-PREREQUISITE-COMPANY-PICKER-EN.md). company_picker مصوب اجرا شد: نام/کد snapshot فقط شرکت‌های اعلام‌کنندهٔ قابل‌رؤیت، جست‌وجوی literal و۲۵ گزینهٔ صفحه‌دار، حفظ انتخاب و صفحه‌های مستقل. بدون directory/دسترسی/schema/نوشتن/PDF تازه.۵۶/۱۷۹۳ موفق؛ نه full-suite/CI/مرورگر/استقرار/commit/push.۱۶ سورس قبلی از آرشیو کنترل‌شده با حفظ تفاوت‌ها بازیابی؛ bundle جدید در شواهد؛ DB خصوصی پس از بررسی خاموش.

> **تحویل جاری — ۲۰۲۶-۱۰-۲۰:** [فهرست پیگیری پیش‌نیازها](INSPECTION-PREREQUISITE-REGISTER-FA.md) / [English](INSPECTION-PREREQUISITE-REGISTER-EN.md). tracking_register مصوب: فیلتر وضعیت/هویت شرکت اعلام‌کننده/شمارهٔ اعلان،۲۵ ردیف و تعداد فقط قابل‌رؤیت، برچسب اصل باطل، بدون نوشتن/اختیار/schema/PDF تازه. بخش مرحلهٔ موروثیِ باقی‌نمانده در workspace بازیابی و آزموده شد؛ گزارش/آرشیو سورس در شواهد.۴۷/۱۰۵۱ نهایی + اعلان قدیمی جدا۱/۱۲ موفق؛ اجراهای قبلی هم‌پوشان‌اند. نه full-suite/CI/مرورگر/استقرار/commit/push؛ DB خصوصی پس از بررسی خاموش.

> **تحویل جاری — ۲۰۲۶-۱۰-۲۰:** [زمینهٔ دقیق مرحلهٔ ITP برای پیش‌نیاز](INSPECTION-PREREQUISITE-ITP-LINK-REVIEW-FA.md) / [English](INSPECTION-PREREQUISITE-ITP-LINK-REVIEW-EN.md). انتخاب inherited_stage اجرا شد: فقط snapshot محفوظ همان اعلان در فرم/جزئیات/سابقه؛ نه منبع زنده، schema/دسترسی تازه، backfill، آیتم جزئی ساختاریافته یا تغییر PDF.۵۴/۸۰۷ + اعلان قدیمی جدا۱/۱۲ موفق؛ نه full-suite/مرورگر/CI/استقرار/commit/push. DB خصوصی پس از بررسی خاموش شد.

> **تحویل جاری — ۲۰۲۶-۱۰-۲۰:** [پیش‌نیاز گیرندگان](INSPECTION-NOTIFICATION-PREREQUISITES-FA.md) / [English](INSPECTION-NOTIFICATION-PREREQUISITES-EN.md)، [ADR-045](ADR-045-INSPECTION-NOTIFICATION-PREREQUISITES-FA.md). any_reader_company_scope / report_and_recipient_confirm / all_notice_readers مصوب اجرا شد. چند شرط متنی مستقل، اصلاح/پس‌گرفتن با دلیل، گزارش مجوزدار جاری فرستنده، تأیید/رد گیرنده و سابقهٔ ثابت. نه gate خودکار، پذیرش فنی یا اختیار منبع/موجودی؛ اصل و PDF محفوظ.۸۱/۱۲۹۰ + ارتقای جدا۱/۵ موفق؛ نه full-suite/CI/استقرار/commit/push؛ DB خصوصی پس از بررسی خاموش. موارد قبلی زیر این یادداشت تاریخی‌اند.

> **تحویل جاری — ۲۰۲۶-۱۰-۲۰:** [دریافت شرکت‌ها](INSPECTION-NOTIFICATION-ACKNOWLEDGMENT-FA.md) / [English](INSPECTION-NOTIFICATION-ACKNOWLEDGMENT-EN.md)، [ADR-044](ADR-044-INSPECTION-NOTIFICATION-ACKNOWLEDGMENT-FA.md). انتخاب صریح any_authorized_company_reader / issue_and_cancellation_separate / all_authorized_notice_readers / detail_and_current_pdf اجرا شد. اولین دریافت ثابت هر شرکت/رویداد؛ اصل پس از ابطال دریافت نمی‌شود؛ دید شرکت/شخص/زمان در scope اصل و PDF جاری، کنترل۴۰۹ تغییر حین render. نه tracker/ارسال/امضا/تصویب یا اختیار سند/MTO/MR/PO/موجودی.۶۱/۱۰۴۰ + ارتقای جدا۱/۵ موفق؛ PDF نهایی۱/۲۲ هم‌پوشان. بدون full-suite/CI جاری/استقرار/commit/push؛ DB خصوصی خاموش شد.

> **تحویل جاری — ۲۰۲۶-۱۰-۲۰:** [ابطال مستقل صادرشده](INSPECTION-NOTIFICATION-CANCELLATION-FA.md) / [English](INSPECTION-NOTIFICATION-CANCELLATION-EN.md)، [ADR-043](ADR-043-INSPECTION-NOTIFICATION-CANCELLATION-FA.md). انتخاب صریح current_issue_grant/cancel_only/status_reason_scoped_replacement اجرا شد؛ رویداد append-only جدا، اصل/شماره/نسخه/snapshot ثابت و وضعیت مؤثر CANCELLED؛ دید دلیل/شخص/زمان در همان scope، بدون افشای تاریخچهٔ خصوصی. PDF جاری و کنترل۴۰۹ ابطال حین render. نهایی۵۹/۸۸۴ + ارتقای جدا۱/۵ موفق؛ PDF۱/۲۲ هم‌پوشان. فقط تعویق ابطال جایگزین؛ جایگزینی/undo/تأیید دریافت معوق. نه موفقیت۹۰موردی/full-suite/تولید/CI؛ بدون commit/push/deploy. DB خصوصی خاموش شد.

> **آخرین ادامه — ۲۰۲۶-۱۰-۲۰:** [UI اختیاری زمان فیلتر](INSPECTION-NOTIFICATION-FILTER-TIME-UI-FA.md) / [English](INSPECTION-NOTIFICATION-FILTER-TIME-UI-EN.md)، انتخاب `filter_usability` اجرا شد. ۲۶ آزمون/۴۰۴ assertion و۷ گروه مرورگر/۱۴۷ بررسی موفق؛ جدا و غیرقابل‌جمع. helper ناقص ارسال را مسدود، کاملاً خالی مرز را حذف می‌کند؛ بدون offset حدسی/اختیار/schema تازه. بررسی Chromium روی صفحات مصنوعیِ جاری، نه production/live-auth/full-suite؛ DB خصوصی خاموش شد.

> **تحویل جاری — ۲۰۲۶-۱۰-۲۰:** [جست‌وجو/فیلتر نوتیفیکیشن](INSPECTION-NOTIFICATION-REGISTER-FILTERS-FA.md) / [English](INSPECTION-NOTIFICATION-REGISTER-FILTERS-EN.md). انتخاب `register_filters`: literal شماره/مرجع فعلی، وضعیت، هم‌پوشانی شاملِ offsetدار، آمار/صفحهٔ مجاز و حفظ زبان/context. زمان تکی قدیمی بازه فرض نمی‌شود؛ بدون جست‌وجوی تاریخچه، اختیار/schema/endpoint/نوشتن تازه. **۵۸ آزمون /۶۴۰ assertion موفق، بدون skip**؛ نه full-suite/تولید/CI/کارایی. آمار قبلی تاریخی؛ ADR-042/MTO و محرمانگی سابقه ثابت‌اند.

> **تحویل جاری — ۲۰۲۶-۱۰-۲۰:** [تاریخچهٔ اصلاح پیش‌نویس نوتیفیکیشن](INSPECTION-NOTIFICATION-DRAFT-HISTORY-FA.md) / [English](INSPECTION-NOTIFICATION-DRAFT-HISTORY-EN.md). انتخاب `draft_history`: قبل/بعد نسخه‌دار + شخص/نام/زمان/مجوز، ثبت اتمیک DB و append-only/FORCE RLS؛ فقط شرکت ثبت‌کننده، نه سابقهٔ گیرنده/PDF. صفحه‌بندی۲۵ردیفی، حفظ ذخیرهٔ یکسان، بدون backfill قدیمی. migration120000؛ **۸۷ آزمون /۱۱۳۹ assertion موفق، بدون skip**، نه full-suite/تولید/CI. آمار قبلی تاریخی؛ اختیارها و مرز ADR-042/MTO ثابت، ابطال/تغییر زمان صادرشده معوق.

> **تحویل جاری — ۲۰۲۶-۱۰-۲۰:** [بهبود فرم تاریخ/ساعت نوتیفیکیشن](INSPECTION-NOTIFICATION-TIME-UI-FA.md) / [English](INSPECTION-NOTIFICATION-TIME-UI-EN.md). انتخاب `date_time_ui`: کنترل تاریخ/ساعت + offset صریح، مقدار دقیق/ورود مستقیم/بدون JS و نمایش خوانا؛ بدون حدس منطقهٔ زمانی یا تغییر API/schema/اختیار.۵۳/۷۴۰ آزمون مرتبط و زیرمجموعهٔ نهایی۴/۸۱ موفق؛ مرورگر۱۸ سناریو/۱۴۹ بررسی موفق، غیرقابل‌جمع. نه full-suite/تولید/CI/E2E/همهٔ مرورگرها؛ سابقه و تصمیم replace_time/ADR-042/MTO ثابت‌اند.

> **تحویل جاری — ۲۰۲۶-۱۰-۲۰:** [بازهٔ فعالیت در نوتیفیکیشن](INSPECTION-NOTIFICATION-ACTIVITY-WINDOW-FA.md) / [English](INSPECTION-NOTIFICATION-ACTIVITY-WINDOW-EN.md). انتخاب `replace_time`: شروع/پایان الزامی جای وقت تکی، حفظ offset و کنترل زمان مطلق؛ فرم/فهرست/جزئیات/PDF دو‌زبانه. صادرشدهٔ قدیمی بدون بازنویسی و با برچسب تک‌زمانی؛ پیش‌نویس قدیمی پیش از صدور نیازمند تبدیل صریح. migration110000؛ **۷۱ آزمون /۸۰۲ assertion موفق، بدون skip**، نه full-suite/تولید/CI جاری؛ آمار/قرارداد قبلی تاریخی‌اند. اختیار/مرز ADR-042/MTO ثابت؛ تغییر زمان صادرشده اضافه نشد.

> **تحویل جاری — ۲۰۲۶-۱۰-۲۰:** [ویرایش محدود پیش‌نویس نوتیفیکیشن](INSPECTION-NOTIFICATION-DRAFT-EDIT-FA.md) / [English](INSPECTION-NOTIFICATION-DRAFT-EDIT-EN.md). انتخاب `draft_only` اجرا شد؛ همان مجوز مستقل ثبت/شرکت، کنترل نسخه و مرجع ثابت؛ آخرین ویرایشگر/زمان ثبت می‌شود، نه تاریخچهٔ کامل. صادرشده/PDF تغییرناپذیر؛ ابطال/تغییر زمان صادرشده معوق. **۵۸ آزمون /۶۳۱ assertion موفق، بدون skip**؛ نه full-suite/تولید/CI جاری. محدودیت create-only و شمارش‌های قبلی تاریخی‌اند؛ مرز ADR-042/MTO ثابت است.

> **تحویل جاری — ۲۰۲۶-۱۰-۲۰:** [PDF نوتیفیکیشن صادرشده](INSPECTION-NOTIFICATION-WORKFLOW-FA.md) / [English](INSPECTION-NOTIFICATION-WORKFLOW-EN.md): فارسی/انگلیسی از سابقهٔ صدور، همان دسترسی و کنترل پس از تولید؛ بدون تغییر رکورد/امضا/ارسال/حق خواندن مرجع. متادیتای پروژه فقط در صدور جدید، بدون backfill قدیمی. **۴۲/۵۰۱ +۲۱/۸۵ موفق؛۶۳ آزمون /۵۸۶ assertion در دو فرمان مستقل، بدون skip**؛ نه full-suite/تولید/CI جاری. متن‌های قبلیِ تعویق PDF و آمار۴۶/۲۵۰ تاریخی‌اند؛ پنج انتخاب ADR-042 و مرز MTO ثابت‌اند.

> **تحویل جاری — ۲۰۲۶-۱۰-۱۹:** [نوتیفیکیشن عملیاتی مراحل ITP](INSPECTION-NOTIFICATION-WORKFLOW-FA.md) / [English](INSPECTION-NOTIFICATION-WORKFLOW-EN.md). تعیین صریح پیمانکار اصلی، واگذاری مجوز ثبت/صدور توسط مدیر مجاز، مراحل نسخهٔ سند، پیش‌نویس و صدور اتمیک/snapshot و inbox هدفمند ساخته شدند. **دو اجرای نهایی۴۶ آزمون /۲۵۰ assertion موفق**؛ نه اجرای کامل. نوتیفیکیشن، نتیجه/امضا/تحویل خارجی/usable نیست. وضعیت «فقط قرارداد ورودی» قبلی تاریخی شد؛ تصمیم‌های پنج‌گانهٔ ADR-042، مرز نتیجهٔ ADR-041 و MTO محفوظ‌اند. تولید/CI جاری ادعا نمی‌شود.

> **نیازمندی جدید و وضعیت — ۲۰۲۶-۱۰-۱۹:** [ADR-042: نوتیفیکیشن مراحل ITP](ADR-042-ITP-INSPECTION-NOTIFICATIONS-FA.md). پنج انتخاب کاربر ثبت شد: همهٔ مراحل، مجوز مستقل پیمانکار با واگذاری مدیر مجاز، گیرندگان صریح پروژه، نسخهٔ سند+فهرست مراحل و فقط پیمانکار اصلی. **فقط قرارداد ورودی پیاده شد:۷ unit/۲۴ assertion موفق؛ گردش عملیاتی/فرم/صدور هنوز ساخته نشده است.** این نوتیفیکیشن است نه نتیجهٔ بازرسی ADR-041؛ آمارهای قبلی شواهد این قابلیت نیستند.

> **تحویل جاری — ۲۰۲۶-۱۰-۱۹:** [صفحه‌بندی مستقل بازرسی](INSPECTION-REGISTER-PAGINATION-FA.md) / [English](INSPECTION-REGISTER-PAGINATION-EN.md). **۴۰ آزمون / ۵۵۶ assertion موفق**؛ چهار مورد جدید. صفحه‌های۲۵تایی، پیمایش مستقل سه فهرست/کل واقعی، قید پروژه و RLS قبلی کیفیتِ مشارکت‌کنندگان، حذف eager load بلااستفادهٔ PO؛ بازرسی مشورتی باقی ماند. فقط تعویق قبلی صفحه‌بندی بازرسی بسته شد؛ بدون نقش/schema/endpoint/نوشتن یا ادعای اجرای کامل/تولید. شواهد/وضعیت‌های پایین تاریخی‌اند.

> **تحویل جاری — ۲۰۲۶-۱۰-۱۹:** [مبلغ دقیق و صفحه‌بندی مستقل فهرست](REGISTER-PAGINATION-MONEY-FA.md) / [English](REGISTER-PAGINATION-MONEY-EN.md). **۴۱ آزمون / ۴۹۹ assertion موفق**؛ هشت مورد جدید. مبلغ رشته‌ای دقیق و null≠صفر، صفحه‌های مستقل۲۵تایی، کل نتایج/دیرکرد فیلترشده، ترتیب ثابت و حفظ فیلتر/RLS اصلی. دو پیشنهاد قبلی انجام شدند؛ ایندکس/تأیید عملکرد بار و صفحه‌بندی بازرسی‌ها هنوز انجام نشده‌اند. بدون endpoint/schema/نقش/اقدام جدید یا ادعای اجرای کامل/تولید. شواهد قبلی محفوظ و وضعیت‌های پایین تاریخی‌اند.

> **قابلیت جاری — ۲۰۲۶-۱۰-۱۹:** [جست‌وجو و وضعیت مستقل فهرست MR/PO](PROCUREMENT-REGISTER-FILTERS-FA.md) / [English](PROCUREMENT-REGISTER-FILTERS-EN.md). **۳۳ آزمون / ۳۱۰ assertion موفق**؛ هشت مورد جدید. جست‌وجوی سربرگ با پارامتر bindشده، اشتراک دسته/وضعیت، حفظ RLS فراخوان، شمارش نتایج سرور و بازرسی بدون تغییر. بدون نقش/schema/endpoint/اقدام جدید یا ادعای اجرای کامل/تولید. صفحه‌بندی/ایندکس و formatter قدیمی float/بدون اعشارِ مبلغ، پیشنهاد بعدی‌اند. شواهد قبلی محفوظ و وضعیت‌های پایین تاریخی‌اند.

> **اصلاح جاری — ۲۰۲۶-۱۰-۱۹:** [بازیابی ایمن فرم قیمت](PO-PRICING-FORM-RECOVERY-FA.md) / [English](PO-PRICING-FORM-RECOVERY-EN.md). **۴۲ آزمون / ۴۶۵ assertion موفق**؛ ۹ مورد جدید. بازیابی فقط با هش جاری PO و تمام UUIDهای فعال؛ خالی≠صفر، ورودی قدیمی/نامعتبر منتقل نمی‌شود و کنترل نوشتن/اختیار/منبع حفظ شده است. بدون نقش/schema/endpoint جدید یا ادعای اجرای کامل/تولید. شواهد قبلی محفوظ و وضعیت‌های پایین تاریخی‌اند.

> **قابلیت فقط‌خواندنی جاری — ۲۰۲۶-۱۰-۱۹:** [مقایسهٔ تاریخچهٔ قیمت](PO-PRICE-HISTORY-COMPARISON-FA.md) / [English](PO-PRICE-HISTORY-COMPARISON-EN.md). **۳۳ آزمون / ۳۵۹ assertion موفق**؛ هشت مورد جدید. مبلغ رشته‌ای دقیق، تطبیق UUID، قیمت/ارز/جمع قبل‌وبعد، تفکیک صفر و نامشخص، حفظ snapshot خام و نمایش۲۰ سابقه. RLS خریدار/پروژه حفظ شده؛ بدون اختیار/نقش/schema/تأیید جدید یا ادعای اجرای کامل/تولید. شواهد قبلی محفوظ و وضعیت‌های پایین تاریخی‌اند.

> **گردش‌کار جاری — ۲۰۲۶-۱۰-۱۹:** [پیش‌نویس PO از جزئیات MR](MR-TO-PO-CONTEXT-ACTION-FA.md) / [English](MR-TO-PO-CONTEXT-ACTION-EN.md). **۴۳ آزمون / ۳۴۰ assertion موفق**؛ پنج مورد جدید. نویسندهٔ مجاز مستقلِ همان خریدار از POST موجود کپی کامل استفاده می‌کند؛ منبع/مجوز/آرشیو دوباره کنترل می‌شوند. GET بدون تغییر است و اقدام اختیاری عمداً PO پیش‌نویس می‌سازد؛ نه رزرو/مصرف/صدور. بدون endpoint/نقش/schema یا ادعای اجرای کامل/تولید. شواهد قبلی حفظ و وضعیت‌های قبلی پایین تاریخی‌اند.

> **قابلیت جاری — ۲۰۲۶-۱۰-۱۹:** [جزئیات فقط‌خواندنی MR](MATERIAL-REQUISITION-DETAILS-FA.md) / [English](MATERIAL-REQUISITION-DETAILS-EN.md). **۳۰ آزمون / ۲۴۰ assertion موفق**؛ ده مورد جدید. اقلام دقیق/نمایش اولیهٔ مقدار، اطلاعات ثبت‌شدهٔ تأیید/رد و سفارش مرتبط با صفحه‌بندی، زیر RLS اصلی و عضویت/رشته/plan جاری. بدون بازکردن دفتر، جمع واحد ناهمگون، ماندهٔ رسمی، نقش/schema/درگاه نوشتن جدید. شواهد قبلی دست‌نخورده‌اند؛ ادعای اجرای کامل/تولید نیست. وضعیت‌های قبلی پایین تاریخی‌اند.

> **بررسی هدفمند جاری — ۲۰۲۶-۱۰-۱۹:** [رقابت rollback و تعلیق نامزدی](PO-ROLLBACK-REVOCATION-FA.md) / [English](PO-ROLLBACK-REVOCATION-EN.md). **۳۸ آزمون / ۳۲۸ assertion موفق**؛ شامل چهار سناریوی جدید دو اتصال. کد اجرایی، اختیار، گردش‌کار و schema تغییر نکرده‌اند. شواهد محدود به timeout و retry در تراکنش تازه‌اند، نه تأیید جامع crash/لغو اختیار. شواهد قبلی دست‌نخورده و اعداد غیرتجمعی‌اند؛ وضعیت‌های قدیمی پایین تاریخی هستند.

> **اصلاح مرز جاری — ۲۰۲۶-۱۰-۱۹:** [حفاظت منبع در OrderGap انسانی](ORDER-GAP-HUMAN-BOUNDARY-FA.md) / [English](ORDER-GAP-HUMAN-BOUNDARY-EN.md). مسیر تأییدشدهٔ تغییر مقدار کپی MR از HTTP بسته شد؛ انتساب/اصلاحیهٔ انسانی بر نشانگر تازهٔ قفل‌شده کنترل و فرم حفاظت‌شده پنهان می‌شود. زنجیرهٔ داخلی/قدیمی و قیمت‌گذاری مجاز حفظ شدند. **۷۷ آزمون / ۷۶۴ assertion موفق**؛ شش مورد جدید. بدون نقش/سیاست MTO/مهاجرت تازه یا ادعای اجرای کامل/تولید. بازطراحی اختیار قدیمی/دستی معوق است؛ وضعیت‌های قبلی پایین تاریخی‌اند.

> **اصلاح امنیتی جاری — ۲۰۲۶-۱۰-۱۹:** [جداسازی محافظ صدور از دید دفتر](PO-GUARD-ISOLATION-FA.md) / [English](PO-GUARD-ISOLATION-EN.md). نقص تأییدشدهٔ تغییر خط هنگام پنهان‌بودن دفتر با جست‌وجوی داخلیِ فقط‌تریگر و محدود به والد قابل‌مشاهده اصلاح شد؛ زمینه بازگردانده و RLS عادی دفتر حفظ شد. **۷۱ آزمون / ۶۵۸ assertion موفق**؛ شش مورد جدید شامل ارتقای پایگاه آرشیوشده. مهاجرت روبه‌جلوی تابعی180000؛ بدون بازنویسی تاریخچه، نقش/اختیار MTO یا اجرای تولید/مجموعهٔ کامل. وضعیت‌های قدیمی پایین تاریخی‌اند.

> **گام جاری — ۲۰۲۶-۱۰-۱۹:** [هماهنگی قفل‌های OrderGap](ORDER-GAP-LOCKING-FA.md) / [English](ORDER-GAP-LOCKING-EN.md). **۶۵ آزمون مرتبط / ۵۵۲ assertion موفق**؛ شش مورد جدید شامل دو رقابت واقعی صدور/اصلاحیه. ترتیب قفل پروژه→سفارش→خط و کنترل وضعیت تازه؛ قواعد قدیمی و انجماد محتوای صادرشده حفظ شدند. اختیار جدید MTO، تعیین تکلیف نوشتنی، آزادسازی ظرفیت، اجرای کامل یا استقرار تولید ایجاد/ادعا نشده است. پیشنهادهای ادامه صرفاً طراحی/بررسی‌اند. وضعیت‌های قدیمی پایین، تاریخی هستند.

> **Current increment — 2026-10-19:** [read-only MR source commitment review](PO-SOURCE-REVIEW-EN.md) / [بررسی فقط‌خواندنی تعهدات منبع](PO-SOURCE-REVIEW-FA.md). **57 related tests/502 assertions PASS**,12 new cases. Existing caller-RLS/discipline visibility only; no buyer impersonation/new roles/schema/write actions. Visible cancelled/headerless legacy commitments and recorded allocations are distinguished; hidden buyer evidence is UNKNOWN, not missing/zero; quantities retain historical units and no official remaining balance is inferred. ADR-036/038/039 authority/atomic issuance retained; prior108/746 evidence unchanged. No full/recovery/production claim. Next: lock-order alignment and controlled resolution/post-issue design; write-based legacy resolution/release remains NOT implemented. Older current/next statements below are historical.

> **Latest functional delivery — 2026-10-19:** [PO DRAFT entry](PURCHASE-ORDER-ENTRY-EN.md) / [ثبت پیش‌نویس سفارش خرید](PURCHASE-ORDER-ENTRY-FA.md). Accepted independent owner-configured PO author nomination, no default/MR inheritance; manual 1–20-line DRAFT only, exact pricing and project-wide counter. **92 related tests/613 assertions + separate MR upgrade1/57 PASS**; new PO entry+upgrade14/133 included. No issuance, spending approval or MR consumption. Direct detail proc/pack entitlement gap closed. Full suite/recovery not repeated; older latest/full-gate headers below are historical, not current certification or mandatory next steps. Evidence: `docs/evidence/2026-10-19-po-entry/summary.json`.

> **جدیدترین قابلیت:** [جزئیات سفارش خرید](PURCHASE-ORDER-DETAILS-FA.md) / [EN](PURCHASE-ORDER-DETAILS-EN.md)، از شمارهٔ سفارش در فهرست خرید؛۵۴ تست هدفمند/۲۲۷ assertion موفق. دستور جدید کاربر: قابلیت‌های اصلی سریع‌تر، تست مرتبط در هر مرحله؛ تست کامل فقط نقاط عطف/ریسک/انتشار، بدون archive/report تکراری. منبع تغییر کرده و full-greenهای پایین تاریخی‌اند؛ برای این تغییر gate کامل pending تعریف نشده است. نقص شماره‌گذاری قبلی و مرز اختیار MTO بدون تغییرند.

# وضعیت واقعی پیاده‌سازی و ترتیب تکمیل پروژه

> گام فعلی بسته و سبز شد: اجرای کامل منبع journal با۱۰۹۸ تست/۱۶٬۴۲۹ assertion، صفر failure/error/skip و خروج۰؛۴۴۶ hash بدون تغییر. سند `G01-JOURNAL-FULL-SUITE-VERIFICATION-FA.md`. وضعیت‌های pending پایین تاریخی‌اند؛ journal همچنان UNRESOLVED و گام بعد پذیرش scope/topology معتبر و انتخاب مؤثر است، نه تکرار مبنای بدون تغییر.

> **گام تاریخی پیش از journal بسته شد:** یک اجرای کامل روی کد نهایی با۱۰۸۳ تست و۱۶٬۳۸۵ assertion بدون failure/error/skip موفق شد. گزارش `FINAL-SOURCE-VERIFICATION-2026-10-18-FA.md` مرجع فعلی است. ماتریس۲۱موردی پایلوت هنوز E2E اجرا نشده؛ اولویت بعد انتخاب MTO مؤثر طبق ADR-024 است. ADR-032 صرفاً پیشنهادی است.

> به‌روزرسانی G01: نمونهٔ مستقل با۳۳ سناریوی موفق و تشخیص۳ جهش عمدی آماده است؛ سند `ADR-024-EFFECTIVE-MTO-SELECTION-DESIGN-FA.md`. گزارش اصلی و schema/مجوز تغییر نکرده‌اند؛ G01 باز است. گام بعد مشخصات migration/backfill قابل‌بازبینی است.


تاریخ: 2026-10-18 — مبنا: `main` در commit `0c54c7f` به‌علاوهٔ اصلاحات محلی تثبیت محیط.

نسخهٔ انگلیسی و جدول جزئی نگاشت کد و تست: [CURRENT-IMPLEMENTATION-LEDGER-EN.md](CURRENT-IMPLEMENTATION-LEDGER-EN.md).

این سند وضعیت فعلی را از یادداشت‌های تاریخی TODO و Handoff جدا می‌کند؛ نیازمندی‌ها و تصمیم‌های مصوب ADR را تغییر نمی‌دهد. وجود کد، وجود تست و نتیجهٔ اجرای تست سه موضوع متفاوت هستند. درصد کلی تکمیل پروژه اعلام نمی‌شود.

| حوزه | وضعیت فعلی و مرز قابلیت |
|---|---|
| هویت، پروژه و RLS | هسته ساخته شده و اجرای کامل محلی سبز است؛ ارزیابی عملیاتی امنیت تولید همچنان لازم است. |
| مدارک و transmittal | برش‌های واقعی ثبت مدرک، بازنگری، بررسی و فایل وجود دارد؛ کل مدیریت اطلاعات مهندسی کامل نیست. |
| مدل پایپینگ و PMS | خطوط، اجزا، اتصالات و کلاس‌ها وجود دارند؛ snapshot مصوب و pin زمان صدور و تغییر محدود schedule ساخته شده‌اند، نه همهٔ نویسندگی PMS. |
| مغایرت schedule و TQ/NCR | درخواست و تاریخچه، پیش‌نویس داخلی و ثبت اطلاعات خارجی تأییدنشده وجود دارند؛ گردش صدور، اختیار امضا، راستی‌آزمایی و disposition/release کامل نیستند. |
| متریال و MTO | کاتالوگ، staging و پذیرش تغییرناپذیر ساخته شده‌اند؛ طراحی جدید مجوزهای MTO همچنان معوق است. |
| مقدار مهندسی و کسری سفارش | مقایسهٔ gross/net و Order Gap وجود دارند؛ کسری متریال فیزیکی قابل‌استفاده جداست و کامل نیست. |
| ورود MR | سیاست نویسندهٔ معرفی‌شده، مقدار دقیق منبع و انتساب سیاست وجود دارد؛ این به معنی کامل‌بودن زنجیرهٔ خرید نیست. |
| خرید و انبار | پایه ساخته شده؛ RFQ، مقایسهٔ پیشنهادها، لجستیک/گمرک و تمام خروجی‌های رسمی کامل نیستند. |
| PCF | parser و پذیرش/طبقه‌بندی read-only وجود دارد؛ import مبنای مهندسی و reconciliation کامل محسوب نمی‌شود. |
| کیفیت و commissioning | Punch/MC و بخش‌هایی از test pack وجود دارند؛ welding/NDT، ITP/ITR کامل، RFSU/PAC/FAC و dossier باقی‌اند. |
| نوتیفیکیشن مراحل ITP (ADR-042) | مرحلهٔ نسخهٔ سند، پیمانکار اصلی/مجوزهای مستقل، پیش‌نویس و صدور اتمیک/snapshot/inbox با آزمون هدفمند ساخته شد؛ تصویب کامل ITP، ماتریس طرف‌ها، ویرایش/ابطال/صدور مجدد، transport و release معوق‌اند. |
| تحویل بازار ایران | بومی‌سازی و کنترل‌هایی برای air-gap وجود دارد؛ بستهٔ نصب آفلاین، لایسنس، عملیات پشتیبانی و پذیرش کامل میدانی هنوز تأیید نشده‌اند. |
| سایر حوزه‌های EPCC | همه در دامنهٔ محصول می‌مانند؛ HSE، برنامه‌ریزی، اپ آفلاین و دامنهٔ کامل تجاری/هزینه در مراحل بعد هستند. |

## ترتیب کار

۱. تکمیل اجرای سریالی کل تست‌ها روی PostgreSQL با نقش غیرـsuperuser و تحلیل تمام شکست‌ها.
۲. تعریف سناریوی پایلوت با دادهٔ مصنوعی: PMS مصوب ← خط و جزء ← مغایرت مهندسی ← MTO پذیرفته‌شده ← MR/PO ← کسری سفارش ← دریافت و وضعیت متریال قابل‌استفاده.
۳. تصویب نیازمندی‌های حل‌نشدهٔ اختیار امضا، راستی‌آزمایی TQ/NCR، disposition و gateها در ADR؛ ثبت اطلاعات معادل تأیید نیست. جزئیات Fit-up در مرحلهٔ ITP تعیین می‌شود.
۴. تکمیل یک شکاف محدود همراه با تست دیتابیس، دسترسی، rollback و هم‌زمانی در صورت نیاز، رابط دوزبانه و به‌روزرسانی مستندات.
۵. آزمایش restore، نصب آفلاین، تنظیمات امن، PDF، مرورگر و موبایل و diagnostics.

اصلاح بازسازی دیتابیس و UUID مدل PMS در [گزارش تثبیت](BASELINE-VERIFICATION-2026-10-18-FA.md) آمده است. تست‌های هدفمند جایگزین تأیید کامل محصول یا مهندسی نیستند. شاخهٔ pre-work نباید یک‌جا ادغام شود.
